# NEURAL

NEURAL studies small, specialized neural networks through controlled, reproducible engineering experiments. Its first focus is game-engine spatial computation. No accuracy, performance, compression or generalization advantage is assumed.

## Mission and status

The [Repository Initialization Mission](docs/REPOSITORY_INITIALIZATION_MISSION.md) governs this work. Phase 0 through [B1-R](docs/P001_B1_R_IMPLEMENTATION.md) are accepted and merged through `cdfd03a2afaad5488485e78e6e694b5a1627ef00`. The owner accepted the [Gate 2 packet](docs/P001_B1_GATE2_WORK_PACKET.md) and authorized [G2-1 implementation](docs/P001_G2_1_IMPLEMENTATION.md) with reduced synthetic verification. Production requires protected external deployment and one-generation authority; test/caller objects cannot supply it. No real datasets, final-input exposure, neural candidate or A/B results exist. G2-2 deployment, G2-3 execution, P001-B2, P001-C and merge remain closed. Power-loss availability is optional production work, not a P001 requirement.

## Research documents

- [THESIS.md](THESIS.md): hypotheses, falsification and claim boundaries.
- [Architecture](docs/ARCHITECTURE.md): independent A/B execution and authoritative geometry.
- [Experiment protocol](docs/EXPERIMENT_PROTOCOL.md): correctness, reproducibility, performance, memory and statistics.
- [Research roadmap](docs/RESEARCH_ROADMAP.md): phase order and advancement gates.
- [Phase 0 verification](docs/PHASE0_VERIFICATION.md): checks and their limits.

## System index

- [NeuralField](systems/NeuralField/README.md): cover, navigation and shooting-lane queries in tactical environments. [P001 specification](systems/NeuralField/P001_SPEC.md) defines the fixed 16 × 16 metre first experiment and its complete contracts.

Future systems can coexist under `systems/` with independent contracts; NeuralField assumptions are system-specific. [Results policy](results/README.md) establishes evidence storage without inventing experiment output.

## Agent workflow

Start with [AGENTS.md](AGENTS.md), then read the governing documents and assigned system specification. [Plan.md](Plan.md) records execution and completion; [Handover.md](Handover.md) records committed context and the next gate. The current next action is **independent G2-1 implementation review**. Conventional query runners are documented in [NeuralField](systems/NeuralField/README.md).
