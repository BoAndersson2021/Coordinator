#!/usr/bin/env python3
"""Read-only staged document/schema contracts; no datasets, tactical or model execution."""
from __future__ import annotations

import copy
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys
from urllib.parse import unquote, urlsplit

try:
    from jsonschema import Draft202012Validator
except ImportError:
    sys.exit("FAIL: existing jsonschema draft-2020-12 support is required; nothing was installed")

ROOT = Path(__file__).resolve().parents[1]
SYSTEM = ROOT / "systems/NeuralField"
REQUIRED = [
    "AGENTS.md", "README.md", "THESIS.md", "Plan.md", "Handover.md",
    "docs/REPOSITORY_INITIALIZATION_MISSION.md", "docs/ARCHITECTURE.md",
    "docs/EXPERIMENT_PROTOCOL.md", "docs/RESEARCH_ROADMAP.md",
    "docs/PHASE0_VERIFICATION.md", "systems/NeuralField/README.md",
    "systems/NeuralField/P001_SPEC.md", "systems/NeuralField/src/common/README.md",
    "systems/NeuralField/src/common/query.schema.json",
    "systems/NeuralField/src/common/response.schema.json",
    "systems/NeuralField/src/conventional/README.md",
    "systems/NeuralField/src/neural/README.md", "systems/NeuralField/tests/README.md",
    "systems/NeuralField/benchmarks/README.md",
    "systems/NeuralField/experiments/P001/README.md",
    "systems/NeuralField/experiments/P001/geometry.v1.json",
    "systems/NeuralField/experiments/P001/preregistration.v1.json",
    "results/README.md", "tools/validate_phase0.py",
]
P001_A_FILES = [
    ".gitignore", ".github/workflows/reference.yml", "requirements-reference.txt",
    "docs/P001_A_WORK_PACKET.md", "docs/P001_A_VERIFICATION.md",
    "systems/NeuralField/src/common/contract.py",
    "systems/NeuralField/src/conventional/geometry.py",
    "systems/NeuralField/src/conventional/reference.py",
    "systems/NeuralField/src/conventional/navigation.py",
    "systems/NeuralField/src/conventional/run.py",
    "systems/NeuralField/tests/independent_oracle.py",
    "systems/NeuralField/tests/test_reference.py",
]
P001_B1_C_FILES = [
    "docs/P001_B1_CONTRACT.md", "docs/P001_B1_C_VERIFICATION.md",
    "systems/NeuralField/experiments/P001/public-fixtures.v1.json",
    "systems/NeuralField/experiments/P001/custody.v1.json",
    "tools/test_b1_contract.py",
]
P001_B1_I_FILES = [
    "requirements-dataset.txt", "docs/P001_B1_I_WORK_PACKET.md", "docs/P001_B1_I_VERIFICATION.md",
    "docs/evidence/P001_B1_I_GATE1_LOCAL.json", "systems/NeuralField/src/dataset/README.md",
    "systems/NeuralField/tests/test_dataset.py", "tools/verify_gate1.py", "tools/gate1-receipt.schema.json",
] + ["systems/NeuralField/src/dataset/"+name for name in (
    "authority.py", "codec.py", "recipe.py", "labeling.py", "audit.py", "artifacts.py", "pipeline.py",
    "storage.py", "custody.py", "custody_worker.py", "consumer_probe.py", "run.py",
    "manifest.schema.json", "provenance.schema.json", "completion.schema.json", "failure.schema.json",
    "launch-profile.schema.json", "qualification.schema.json",
)]

P001_B1_P_FILES = ["tools/verify_qualification_evidence.py"] + [
    "docs/evidence/P001_B1_P/v1/" + name for name in (
        "README.md", "MANIFEST.json", "REPORT.json", "LAUNCH_PROFILE.json",
        "IDENTITY_NAMESPACE.json", "IDENTITY_DAC_ENVIRONMENT.json", "NATIVE_NOOVERWRITE.json",
        "NATIVE_TEST_SUMMARY.json", "GATE1_NATIVE_TESTS.json", "DEPLOYMENT_PROVENANCE.json",
        "SANITIZATION.json", "REFERENCE_DATASET_TESTS.log", "CONTRACT_TESTS.log",
        "procedures/qualification.py", "procedures/environment_dac.py", "procedures/synthetic_tests.py",
        "procedures/final_report.py", "procedures/native_nooverwrite.py",
    )
]

P001_B1_D_FILES = [
    "docs/P001_B1_D_INTEGRITY_CONTRACT.md", "docs/P001_B1_D_RECOVERY_PLAN.md",
    "docs/evidence/P001_B1_D/v1/TOPOLOGY.json", "docs/evidence/P001_B1_D/v1/SOURCES.json",
    "systems/NeuralField/experiments/P001/integrity.v1.json",
    "systems/NeuralField/experiments/P001/custody.v2.json",
]


P001_B1_R_FILES = [
    "docs/P001_B1_R_IMPLEMENTATION.md", "systems/NeuralField/tests/test_runtime_v2.py", "tools/b1r-execution.schema.json",
    "tools/verify_b1r_evidence.py",
] + ["docs/evidence/P001_B1_R/v1/"+name for name in (
    "README.md", "MANIFEST.json", "NATIVE_TESTS.json", "NATIVE_FAULTS.json", "ENVIRONMENT.json",
)] + ["systems/NeuralField/src/dataset/"+name for name in (
    "trust.py", "catalog.schema.json", "registration.schema.json", "loss.schema.json",
    "manifest.v2.schema.json", "provenance.v2.schema.json", "completion.v2.schema.json",
)]


P001_G2_1_FILES = [
    "docs/P001_B1_GATE2_WORK_PACKET.md", "docs/P001_G2_1_IMPLEMENTATION.md",
    "systems/NeuralField/tests/test_gate2.py", "tools/g2-execution.schema.json",
] + ["systems/NeuralField/src/dataset/"+name for name in ('complete_recipe.py', 'custody_artifacts.py', 'generation_authority.py', 'real_store.py', 'production_profile.py', 'public_receipt.py', 'preflight.py', 'custody_worker_v2.py', 'consumer_probe_v2.py', 'custody-audit.schema.json', 'custody-catalog.schema.json', 'custody-claim.schema.json', 'custody-completion.schema.json', 'custody-failure.schema.json', 'custody-loss.schema.json', 'custody-manifest.schema.json', 'custody-provenance.schema.json', 'custody-registration.schema.json', 'deployment.schema.json', 'deployment-qualification.schema.json', 'generation-grant.schema.json', 'production-launch-profile.schema.json')]


def check_g2_scope(root: Path) -> None:
    import ast
    package=root/'systems/NeuralField/src/dataset'
    for name in ('generation-grant','deployment','deployment-qualification','production-launch-profile',
                 'custody-manifest','custody-provenance','custody-audit','custody-catalog','custody-claim',
                 'custody-completion','custody-registration','custody-loss','custody-failure'):
        schema=read_json(package/(name+'.schema.json'))
        Draft202012Validator.check_schema(schema)
        require(schema['additionalProperties'] is False,'Closed G2 schema: '+name)
    check_generation_grant_schema(read_json(package/'generation-grant.schema.json'))
    schema=read_json(package/'production-launch-profile.schema.json')
    require(schema['properties']['final_input_release']=={'const':False},'Profile cannot release final inputs')
    namespace=ast.parse((package/'generation_authority.py').read_text())
    anchor=next(n.value for n in namespace.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ANCHOR' for t in n.targets))
    require(isinstance(anchor,ast.Call) and ast.literal_eval(anchor.args[0])=='/etc/neuralfield/P001/generation-authority.v1.json','Fixed external authority anchor')
    print('PASS: G2 real/test namespace separation, protected external authority and one-generation/final-release boundaries')


def check_generation_grant_schema(schema: dict) -> None:
    fields=schema['properties']
    require(fields['max_generations']=={'const':1},'Exactly one generation per external grant')
    for name in ('automatic_retry','automatic_regeneration','final_input_release','neural_execution','benchmark_execution'):
        require(fields[name]=={'const':False},'Independent closed authority: '+name)
    require(fields['root']=={'const':'/var/lib/neuralfield/P001'},'Native designated custody store')
    require(fields['kind']=={'const':'external_operator_grant'},'Caller objects cannot self-certify authority')
    require(fields['execution_stage']=={'const':'G2-3'} and fields['deployment_stage']=={'const':'G2-2-reviewed'},'Deployment and execution separate from source authorization')


def check_runtime_v2_scope(root: Path) -> None:
    import ast
    package=root/"systems/NeuralField/src/dataset"
    tree=ast.parse((package/"recipe.py").read_text())
    hashes=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign)
                              and any(isinstance(t,ast.Name) and t.id=='HASHES' for t in n.targets)))
    check_runtime_v2_bindings(hashes)
    for name in ('manifest','provenance','completion'):
        schema=read_json(package/(name+'.v2.schema.json'))
        require(schema['properties']['artifact_version']=={'const':'p001-dataset-artifacts.v2'},'Current artifact version')
        require(schema['additionalProperties'] is False,'Closed current artifact schema')
    require(read_json(package/'completion.v2.schema.json')['properties']['contract_versions']==
            {'const':['p001-custody.v2','p001-integrity.v1']},'Current completion authority')
    for name in ('catalog','registration','loss'):
        schema=read_json(package/(name+'.schema.json'))
        require(schema['additionalProperties'] is False,'Closed private trust schema')
    print('PASS: runtime v2 hashes, private trust schemas and retained independent authority guards')


def check_runtime_v2_bindings(hashes: dict) -> None:
    for name in ('custody.v1.json','custody.v2.json','integrity.v1.json'):
        require(hashes[name]==hashlib.sha256((SYSTEM/'experiments/P001'/name).read_bytes()).hexdigest(),
                'Runtime active contract hash: '+name)

def check_custody_v2(c: dict, previous: dict) -> None:
    check_custody_contract(previous)
    expected = copy.deepcopy(previous)
    expected["contract_version"] = "p001-custody.v2"
    expected["publish_requires"][-1] = "synced_verified_completion_receipt"
    parent_hash = hashlib.sha256((json.dumps(previous, sort_keys=True, separators=(",", ":")) + "\n").encode()).hexdigest()
    expected.update({
        "supersedes": {"contract_version":"p001-custody.v1", "sha256":parent_hash,
                       "changed_policy":"P001_research_integrity_and_regeneration_instead_of_universal_write_survival"},
        "integrity_contract":"p001-integrity.v1",
        "publication_acknowledgment":"verified_local_publication_with_checked_fsync_no_power_loss_survival_promise",
        "acknowledged_write_survival_required":False,
        "host_power_loss_tests_required":False,
        "full_disk_image_sync_required":False,
        "recovered_generation_requires_independent_validation":True,
        "trusted_registration_separate_from_candidate":True,
        "loss_recovery":{"classification":"recoverable_loss", "record_loss":True,
                         "invalidate_old_identity":True, "regenerate_from_frozen_inputs":True,
                         "fresh_generation_identity_required":True, "complete_independent_verification_required":True,
                         "republish_atomically":True, "resurrect_invalidated_identity":False,
                         "private_loss_and_lineage_records":True},
        "corruption_recovery":{"classification":"unacceptable_corruption", "close_consumption":True,
                               "preserve_private_diagnostics":True, "silent_repair":False,
                               "changed_data_under_trusted_identity":False},
        "power_loss_survival_profile":"optional_production_only_not_selected",
    })
    require(c == expected, "Explicit custody v2 successor/isolation/integrity policy drift")


def check_research_integrity(c: dict) -> None:
    require(c["contract_version"] == "p001-integrity.v1" and c["status"] == "specification_only_pending_review", "Integrity specification authority")
    require(c["authority"] == {"gate2":"CLOSED", "dataset_generation_authorized":False,
            "disruptive_tests_authorized":False, "merge_authorized":False}, "No generation or advancement authority")
    require(c["custody_contract"] == "p001-custody.v2" and c["storage_root"] == "/var/lib/neuralfield/P001", "Integrity/custody authority agreement")
    require(set(c["mandatory"]) == {"deterministic_scientific_content", "actual_hashes_and_provenance",
            "independent_A0_A1_and_label_checks", "train_final_inference_isolation",
            "same_filesystem_atomic_no_overwrite_publication", "checked_file_and_directory_fsync",
            "complete_synced_verified_completion_receipt", "independent_recovered_generation_validation",
            "normal_process_crash_recovery", "detect_and_reject_recovered_corruption",
            "loss_record_invalidation_and_fresh_identity_regeneration"}, "Mandatory scientific integrity gates")
    ack = c["acknowledgment"]
    require(ack == {"meaning":"verified_local_publication_not_host_power_survival",
            "receipt_existence_or_rename_alone_is_success":False, "required_operation_error_returns_success":False,
            "independent_power_proof_witness_required":False}, "No premature ACK or hidden storage gate")
    matrix = c["failure_matrix"]
    require([case["id"] for case in matrix] == ["F1","F2","F3","F4","F5","F6"], "Complete failure classification")
    require([case["rule"] for case in matrix] == ["no_success_quarantine_unpublished_staging",
            "complete_survivor_independently_reverified_or_loss_recorded_or_invalid_state_rejected",
            *["valid_complete_survivor_or_recorded_loss_or_fail_closed_corruption"]*3,
            "reject_mismatch_or_ambiguity_preserve_evidence_no_silent_repair"], "Integrity-first failure matrix")
    require(c["loss_policy"] == {"acknowledged_loss_is_recoverable":True,
            "old_identity_invalidation_required":True, "new_generation_identity_required":True,
            "frozen_content_must_reproduce":True, "copy_old_receipt_or_hash":False,
            "missing_registration_allows_admission":False, "invalidated_identity_can_reappear_as_valid":False,
            "loss_record_and_replacement_lineage_private":True}, "Loss is recorded/invalidation required/no identity reuse")
    recovery = c["recovery"]
    require(recovery == {"before_any_consumption":"independent_complete_identity_provenance_schema_hash_label_split_and_permission_validation",
            "candidate_self_manifest_is_trust_anchor":False, "unpublished_staging":"quarantine_never_auto_publish",
            "corrupt_or_ambiguous_state":"close_consumption_and_preserve_private_diagnostics",
            "normal_process_recovery_required":True, "final_exposure_history_must_be_preserved":True,
            "regeneration_authorizes_tuning_or_final_rerun":False}, "Fail-closed admission and final exposure history")
    require(c["acceptance"] == {"unsafe_admissions_max":0, "final_label_leaks_max":0,
            "success_after_required_operation_error_max":0, "generation_loss_disqualifies_P001_environment":False,
            "real_dataset_execution_evidence_present":False}, "Scientific integrity acceptance, no fabricated execution")
    environment = c["current_environment"]
    require(environment == {"native_ext4_Colima_retained":True, "accepted_synthetic_evidence_reusable_with_original_bindings":True,
            "power_loss_durability":"NOT PROVEN_NOT_A_P001_GATE", "additional_physical_storage_qualification_required":False,
            "full_image_sync_replacement_required":False, "custody_v2_runtime_alignment_implemented":False}, "No physical-storage prerequisite or false v2 runtime claim")
    require(c["optional_production_profile"] == {"profile_id":"acknowledged_write_power_loss_survival",
            "required_for_P001":False, "selected":False, "qualified":False,
            "separate_contract_evidence_and_execution_authorization_required":True}, "Strong survival profile optional only")


def check_integrity_contract() -> None:
    previous = read_json(SYSTEM/"experiments/P001/custody.v1.json")
    successor = read_json(SYSTEM/"experiments/P001/custody.v2.json")
    check_custody_v2(successor, previous)
    c = read_json(SYSTEM/"experiments/P001/integrity.v1.json")
    check_research_integrity(c)
    for name, field in (("TOPOLOGY.json","topology_sha256"), ("SOURCES.json","primary_source_index_sha256")):
        path = ROOT/"docs/evidence/P001_B1_D/v1"/name
        require(hashlib.sha256(path.read_bytes()).hexdigest() == c["inspection_bindings"][field], "Historical inspection binding: " + name)
    topology = json.loads((ROOT/"docs/evidence/P001_B1_D/v1/TOPOLOGY.json").read_bytes())
    require(topology["baseline"] == c["baseline"] and not topology["failure_tests_executed"]
            and not topology["production_qualified"] and not topology["host_backing_file"]["contents_read_or_hashed"], "Historical read-only evidence scope")
    for relative in ("docs/P001_B1_D_INTEGRITY_CONTRACT.md", "docs/P001_B1_D_RECOVERY_PLAN.md",
                     "docs/P001_B1_CONTRACT.md", "docs/EXPERIMENT_PROTOCOL.md", "systems/NeuralField/P001_SPEC.md"):
        text = (ROOT/relative).read_text()
        require("custody.v2.json" in text and "Gate 2" in text, "Current custody/gate document agreement: " + relative)


def check_gate1_scope(root: Path) -> None:
    import ast
    package=root/"systems/NeuralField/src/dataset"
    authority=ast.parse((package/"authority.py").read_text())
    function=next(n for n in authority.body if isinstance(n,ast.FunctionDef) and n.name=="require_gate2")
    require(len(function.body)==1 and isinstance(function.body[0],ast.Raise), "Gate 2 must unconditionally reject")
    require((root/"requirements-dataset.txt").read_text().splitlines()[-1]=="numpy==1.26.4", "Pinned PCG64 implementation")
    for area in ("common","conventional","neural"):
        for path in (root/"systems/NeuralField/src"/area).glob("*.py"):
            tree=ast.parse(path.read_text())
            require(not any(isinstance(n,ast.ImportFrom) and (n.module or '').startswith('dataset') for n in ast.walk(tree)),
                    f"Dataset custody cannot enter runtime/common: {path}")
    for path in package.glob("*.py"):
        tree=ast.parse(path.read_text())
        require(not any(isinstance(n,ast.ImportFrom) and (n.module or '').startswith(('torch','neural')) for n in ast.walk(tree)),"No neural imports")
    receipt=read_json(root/"docs/evidence/P001_B1_I_GATE1_LOCAL.json")
    schema=read_json(root/"tools/gate1-receipt.schema.json")
    Draft202012Validator.check_schema(schema);Draft202012Validator(schema).validate(receipt)
    require(receipt['passed'] and not receipt['production_qualified'] and receipt['failures']==receipt['errors']==0,"Synthetic test receipt cannot claim production proof")
    require(len(receipt['records'])==receipt['tests_run'],"Complete test receipt")
    for path in package.glob("*.schema.json"):
        Draft202012Validator.check_schema(read_json(path))

# Accepted e77d048 contracts; a B1-C correction cannot change these bytes.
FROZEN_HASHES = {
    "THESIS.md": "d82f6fe717d03be80fa08d7a05b4a2b5fe3d29b31f0b0665920c5eedd65b62df",
    "systems/NeuralField/experiments/P001/geometry.v1.json": "37759af786f658d89eef887add98ce47d95d0c450a877a70a0c3002addb68f1b",
    "systems/NeuralField/experiments/P001/preregistration.v1.json": "f2168acf7d80c6c38136417988e5c17608575bfe4c8b2909ae9956616dd72d96",
    "systems/NeuralField/src/common/query.schema.json": "fb721a9eebdb30a5c63d82d798e15c11e1ac02077870aa78b283961cf2364381",
    "systems/NeuralField/src/common/response.schema.json": "80d57a3537e29160f4bc1a0e4e3a1923f78465c40a12adf591675e15858832a2",
}
FROZEN_SECTION_HASHES = {2: '8b27f33f42a166cbd49087643ea84ba90b66b5eb019838a4396e588ba1b7973a', 3: '0c3c55f038833728102699342123d558b4111a7d2cdb28eba2de62d2c2796696', 6: '3b173fd4e74f323143f00c0b587d642f9593b5c2e21f1d35e2dd0197777d13c9', 7: '9e92be6128955db9fe23f498e6c434b83956cc6624c887398f73e4e8172d2ff8'}
RECIPE_HASHES = [
    "79381f9c31023529f27a9135147b032ad815f2f0141ee4a2d757460574a20e76",
    "783dd65c794ff736975c0d08f08cdfab1c35ebc2b22cf4b799561b08d61213dc",
    "7c9ff96311289ab2abcf9adbef94e72bf4e372cb0979c1a62d87ba94c8eaa242",
    "7385e27ef423665761be4a4ab363c6b6a5ebb3d1d64aa29051457b6e01c7f3c5",
    "f0ff534b1191d0aa789fd6a59cd66c594477a034c95866ee7e293a8ebd1dd84a",
]


def check_fixture_registry(registry: dict, query: dict, spec: str) -> None:
    expected = []
    for name, node in (("passage", [7,29]), ("destination", [55,29]),
                       ("pocket", [47,11]), ("blocked", [29,11])):
        expected.append({"fixture_id": "nav-"+name, "domain": "navigation", "input": {
            "start_node": node, "destination_node": [55,29], "actor": {"half_extent_m": 0.25}}})
    for name, target in (("passage", [14,7.5]), ("wall", [14,6]),
                         ("gap-endpoint", [7,7.5]), ("corner-endpoint", [7,7])):
        expected.append({"fixture_id": "shoot-"+name, "domain": "shooting", "input": {
            "firing_m": [2,7.5], "target_m": target, "firing_geometry": {"projectile_radius_m": 0}}})
    for name, candidate in (("exposed", [10,7.5]), ("protected", [10,6]), ("blocked", [7.5,3])):
        expected.append({"fixture_id": "cover-"+name, "domain": "cover", "input": {
            "candidate_m": candidate, "threat_m": [2,7.5], "actor": {"half_extent_m": 0.25}}})
    require(registry == {
        "registry_version": "p001-public-fixtures.v1", "schema_version": "p001.v1",
        "snapshot_id": "p001-static-v1", "class": "declared_public_fixture",
        "source": "../../P001_SPEC.md#4-conventional-variants-and-label-checks",
        "exclude_from": ["training","validation","final"],
        "identity_fields": ["schema_version","snapshot_id","domain","input"],
        "reference_workload_implies_exclusion": False, "fixtures": expected,
    }, "Declared public registry drift: exactly 11 P001 examples, four navigation exclusions")
    validator = Draft202012Validator(query)
    keys = set()
    for fixture in registry["fixtures"]:
        request = envelope(fixture["domain"], fixture["input"])
        validator.validate(request)
        request.pop("query_id")
        key = json.dumps(request, sort_keys=True, separators=(",", ":"))
        require(key not in keys, "Duplicate public semantic request")
        keys.add(key)
    actual = re.findall(r"^\| (Nav \[[^]]+\]|Shoot target \([^)]+\)|Cover centre \([^)]+\)) \|", spec, re.M)
    require(actual == ["Nav [7,29]", "Nav [55,29]", "Nav [47,11]", "Nav [29,11]",
        "Shoot target (14,7.5)", "Shoot target (14,6)", "Shoot target (7,7.5)",
        "Shoot target (7,7)", "Cover centre (10,7.5)", "Cover centre (10,6)",
        "Cover centre (7.5,3)"], "P001 public table/registry disagreement")


def check_recipe_text(spec: str) -> None:
    section = spec.split("## 5. Dataset construction and custody\n\n")[1].split("\n## 6.")[0]
    paragraphs = section.split("\n\n")[:5]
    require([hashlib.sha256(p.encode()).hexdigest() for p in paragraphs] == RECIPE_HASHES,
            "Frozen P001 split/challenge recipe changed")


def check_frozen_sections(spec: str) -> None:
    for number, expected in FROZEN_SECTION_HASHES.items():
        section = spec.split(f"## {number}.",1)[1].split(f"\n## {number+1}.",1)[0]
        require(hashlib.sha256(section.encode()).hexdigest()==expected,
                f"Frozen P001 geometry/query/model/quality prose changed: section {number}")


def audit_navigation_classification(registry: dict, prereg: dict) -> dict:
    """Read-only contract arithmetic; no requests, labels or dataset files."""
    d = prereg["datasets"]
    require(d["tile_counts"] == {"training":160,"validation":32,"final":64}, "Frozen tile allocation")
    require(d["tile_assignment_prefix"] == "p001.v1:tiles:20261011", "Frozen tile hash prefix")
    ranked = sorted((hashlib.sha256(f'{d["tile_assignment_prefix"]}:{tx}:{ty}'.encode()).hexdigest(), tx, ty)
                    for tx in range(16) for ty in range(16))
    tiles = {(tx,ty): "training" if index < 160 else "validation" if index < 192 else "final"
             for index, (_,tx,ty) in enumerate(ranked)}
    public = {tuple(f["input"]["start_node"]) for f in registry["fixtures"] if f["domain"]=="navigation"}
    require(public == {(7,29),(55,29),(47,11),(29,11)}, "Only four public navigation exclusions")
    counts = dict(public=0,challenge=0,training=0,validation=0,final=0)
    # Quarter-metre integer coordinates: distance <= .5 m means squared distance <= 4.
    for i in range(63):
        for j in range(63):
            x,y = i+1,j+1
            reserved = any(max(xmin-x,0,x-xmax)**2 + max(ymin-y,0,y-ymax)**2 <= 4
                           for xmin,xmax,ymin,ymax in ((28,32,28,32),(44,52,8,16)))
            assigned = "public" if (i,j) in public else "challenge" if reserved else tiles[min(15,x//4),min(15,y//4)]
            require(not (reserved and (i,j) not in public and assigned in ("training","validation")),
                    "Reserved navigation exposed to training/validation")
            counts[assigned] += 1
    require(sum(counts.values()) == 3969 and counts["public"] == 4, "Exhaustive navigation classification")
    require(all(counts[k] > 0 for k in ("challenge","training","validation","final")),
            "Reference verification must not consume navigation dataset")
    return counts


def check_custody_contract(c: dict) -> None:
    # Exact invariants: contract revisions must be reviewed, never weakened through a status edit.
    expected = {
        "contract_version":"p001-custody.v1", "status":"specification_only_not_enforced",
        "mechanism":"linux_distinct_uid_gid_mount_pid_namespaces",
        "identities":{"custodian":"nf-custodian","training":"nf-train","inference":"nf-infer"},
        "root":"/var/lib/neuralfield/P001", "same_filesystem_required":True,
        "owner":"nf-custodian", "private_directory_mode":"0700", "private_file_mode":"0600",
        "generation_directory_mode":"0711", "training_directory_mode":"0750", "training_file_mode":"0640",
        "training_group":"nf-train", "consumer_capabilities":[], "consumer_no_new_privileges":True,
        "consumer_private_pid_namespace":True, "consumer_private_mount_namespace":True, "consumer_read_only_mounts":True,
        "final_inputs_owner":"nf-custodian", "final_labels_owner":"nf-custodian",
        "final_labels_reader":"custodian_comparator_only", "final_inputs_release":"reviewed_final_freeze_only",
        "denied_read_identities":["nf-train","nf-infer"], "tests_use_actual_launch_profile":True,
        "manifest_public_fields":["generation_id","contract_versions","source_revision","artifact_hashes","counts",
                                  "verification_pass","custody_pass","receipt_hash"],
        "manifest_sealed_records_allowed":False,
        "states":["GENERATING","VERIFYING","VERIFIED","PUBLISHED / SEALED","QUARANTINED"],
        "transitions":[["GENERATING","VERIFYING"],["VERIFYING","VERIFIED"],["VERIFIED","PUBLISHED / SEALED"],
                       ["GENERATING","QUARANTINED"],["VERIFYING","QUARANTINED"],["VERIFIED","QUARANTINED"]],
        "publish_requires":["all_labels_verified","all_hashes_verified","split_audit_pass","independent_checks_pass",
                            "custody_tests_pass","durable_completion_receipt"],
        "publish_primitive":"renameat2_RENAME_NOREPLACE", "fsync_files_and_directories":True,
        "receipt_required_for_consumption":True, "recovery":"quarantine_uncommitted_generation_never_auto_publish",
        "symlinks_allowed":False, "external_hardlinks_allowed":False, "b1c_artifact_creation_authorized":False,
    }
    require(c == expected, "Custody isolation/publication contract drift")


def check_b1_documents(root: Path) -> None:
    paths = ("systems/NeuralField/P001_SPEC.md", "docs/EXPERIMENT_PROTOCOL.md",
             "docs/P001_A_VERIFICATION.md", "systems/NeuralField/tests/README.md", "docs/P001_B1_CONTRACT.md")
    for name in paths:
        text = (root/name).read_text()
        require("public-fixtures.v1.json" in text, f"Missing exclusion authority: {name}")
        require("Reference verification workloads do not automatically exclude their queries".lower() in text.lower(),
                f"Missing verification/exclusion distinction: {name}")
        require("Registered unit fixtures are public verification inputs" not in text
                and "exclude their semantic requests" not in text, f"Stale blanket fixture exclusion: {name}")
    contract = (root/"docs/P001_B1_CONTRACT.md").read_text()
    for phrase in ("nf-custodian", "nf-train", "nf-infer", "actual dedicated UID/GID", "no-new-privileges",
                   "private mount and PID namespaces", "same filesystem", "RENAME_NOREPLACE", "fsync",
                   "durable completion receipt", "quarantine", "No datasets, new labels", "not this verified Linux boundary"):
        require(phrase in contract, f"Missing executable custody/publication law: {phrase}")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def read_json(path: Path) -> dict:
    def reject_constant(value: str):
        raise ValueError(f"Non-finite JSON constant: {value}")
    raw = path.read_text(encoding="utf-8")
    value = json.loads(raw, parse_constant=reject_constant)
    canonical = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n"
    require(raw == canonical, f"Noncanonical JSON: {path.relative_to(ROOT)}")
    return value


def anchor_ids(path: Path) -> set[str]:
    ids, duplicates = set(), {}
    for heading in re.findall(r"^#{1,6}\s+(.+)$", path.read_text(), re.M):
        slug = re.sub(r"[^\w\- ]", "", heading.lower()).replace(" ", "-")
        n = duplicates.get(slug, 0)
        duplicates[slug] = n + 1
        ids.add(slug if n == 0 else f"{slug}-{n}")
    return ids


def check_links() -> int:
    total = 0
    for path in repository_files():
        if path.suffix != ".md":continue
        for raw in re.findall(r"\[[^\]]+\]\(([^)]+)\)", path.read_text()):
            link = urlsplit(raw)
            if link.scheme or link.netloc:
                continue
            target = (path.parent / unquote(link.path)).resolve() if link.path else path
            require(target.is_relative_to(ROOT), f"Link escapes repository: {path}: {raw}")
            require(target.is_file(), f"Missing link: {path}: {raw}")
            if link.fragment:
                require(unquote(link.fragment) in anchor_ids(target), f"Missing anchor: {path}: {raw}")
            total += 1
    return total


def repository_files():
    for directory, folders, files in os.walk(ROOT):
        folders[:] = [name for name in folders if name not in (".git", ".venv", "__pycache__")]
        for name in files:
            if name.endswith((".pyc", ".pyo")):continue
            yield Path(directory)/name


def envelope(domain: str, input_value: dict) -> dict:
    return {"schema_version": "p001.v1", "snapshot_id": "p001-static-v1",
            "query_id": "contract-example", "domain": domain, "input": input_value}


def response(domain: str, output: dict | None, status: str = "ok") -> dict:
    return {"schema_version": "p001.v1", "snapshot_id": "p001-static-v1",
            "query_id": "contract-example", "domain": domain, "implementation": "B",
            "status": status, "output": output}


def check_schemas(query: dict, result: dict) -> int:
    for schema in (query, result):
        Draft202012Validator.check_schema(schema)
    qv, rv = Draft202012Validator(query), Draft202012Validator(result)
    actor = {"half_extent_m": 0.25}
    requests = [
        envelope("cover", {"candidate_m": [10, 7.5], "threat_m": [2, 7.5], "actor": actor}),
        envelope("navigation", {"start_node": [7, 29], "destination_node": [55, 29], "actor": actor}),
        envelope("shooting", {"firing_m": [2, 7.5], "target_m": [14, 6],
                              "firing_geometry": {"projectile_radius_m": 0}}),
    ]
    outputs = [
        response("cover", {"candidate_traversable": True, "exposure_fraction": 1,
                           "protection_fraction": 0}),
        response("cover", {"candidate_traversable": False, "exposure_fraction": None,
                           "protection_fraction": None}),
        response("navigation", {"start_traversable": True, "destination_traversable": True,
                                "reachable": True, "route_cost_m": 12}),
        response("navigation", {"start_traversable": True, "destination_traversable": True,
                                "reachable": False, "route_cost_m": None}),
        response("navigation", {"start_traversable": False, "destination_traversable": True,
                                "reachable": False, "route_cost_m": None}),
        response("shooting", {"line_clear": True, "first_hit_t": None,
                              "first_hit_obstacle_id": None}),
        response("shooting", {"line_clear": False, "first_hit_t": 5 / 12,
                              "first_hit_obstacle_id": "W0"}),
        response("cover", None, "invalid_input"),
        response("navigation", None, "out_of_domain"),
        response("shooting", None, "model_failure"),
    ]
    unsupported = response("cover", None, "out_of_domain")
    unsupported.update(schema_version="future.v2", snapshot_id="unknown-world")
    outputs.append(unsupported)
    unsupported_domain = response("future-domain", None, "out_of_domain")
    outputs.append(unsupported_domain)
    for item in requests:
        qv.validate(item)
    for item in outputs:
        rv.validate(item)
    invalid_requests = []
    for field, value in (("schema_version", "future.v2"), ("snapshot_id", "unknown"),
                         ("extra", 1)):
        item = copy.deepcopy(requests[0]); item[field] = value; invalid_requests.append(item)
    item = copy.deepcopy(requests[1]); item["input"]["start_node"] = [True, 29]; invalid_requests.append(item)
    item = copy.deepcopy(requests[1]); item["input"]["start_node"] = [63, 29]; invalid_requests.append(item)
    item = copy.deepcopy(requests[2]); item["input"]["target_m"] = [17, 6]; invalid_requests.append(item)
    invalid_outputs = []
    for index, field, value in ((0, "candidate_traversable", False), (2, "start_traversable", False),
                              (3, "route_cost_m", 3), (5, "first_hit_t", 0.5),
                              (6, "first_hit_obstacle_id", "unknown")):
        item = copy.deepcopy(outputs[index]); item["output"][field] = value; invalid_outputs.append(item)
    item = copy.deepcopy(outputs[0]); item["status"] = "model_failure"; invalid_outputs.append(item)
    item = copy.deepcopy(outputs[0]); item["snapshot_id"] = "unknown"; invalid_outputs.append(item)
    item = copy.deepcopy(outputs[0]); item["domain"] = "future-domain"; invalid_outputs.append(item)
    for item in invalid_requests:
        require(not qv.is_valid(item), f"Invalid accepted query: {item}")
    for item in invalid_outputs:
        require(not rv.is_valid(item), f"Invalid accepted response: {item}")
    return len(requests) + len(outputs) + len(invalid_requests) + len(invalid_outputs)


def check_geometry_and_config(g: dict, p: dict, query: dict, result: dict) -> None:
    spec = (SYSTEM / "P001_SPEC.md").read_text()
    table = {}
    for oid, xmin, xmax, ymin, ymax in re.findall(
            r"^\| (W[01]|C[01]|P[0-3]) \| ([\d.]+) \| ([\d.]+) \| ([\d.]+) \| ([\d.]+) \|", spec, re.M):
        table[oid] = ([float(xmin), float(ymin)], [float(xmax), float(ymax)])
    actual = {o["id"]: (o["min"], o["max"]) for o in g["obstacles"]}
    require(table == actual and len(actual) == 8, "Geometry table/JSON disagreement")
    require(g["world"] == {"min": [0, 0], "max": [16, 16], "closed": True}, "World law")
    require(g["obstacles_closed"] is True, "Closed obstacles")
    require(g["actor"]["half_extent_m"] == 0.25, "Actor size")
    require(not g["actor"]["obstacle_contact_allowed"] and g["actor"]["world_contact_allowed"], "Contact laws")
    require(g["threat_m"] == g["firing_m"] == [2, 7.5], "Origin law")
    nav = g["navigation"]
    require(nav["node_count_per_axis"] == 63 and nav["spacing_m"] == nav["edge_cost_m"] == 0.25, "Lattice law")
    require(nav["destination_node"] == [55, 29], "Destination node")
    require([0.25 + i * 0.25 for i in nav["destination_node"]] == g["destination_m"], "Destination mapping")
    require(g["snapshot_id"] == p["snapshot_id"] == query["properties"]["snapshot_id"]["const"], "Snapshot law")
    require(p["schema_version"] == query["properties"]["schema_version"]["const"] == "p001.v1", "Schema version")
    require(query["$defs"]["cover"]["properties"]["threat_m"]["const"] == g["threat_m"], "Cover origin schema")
    require(query["$defs"]["navigation"]["properties"]["destination_node"]["const"] == nav["destination_node"], "Nav schema")
    require(query["$defs"]["shooting"]["properties"]["firing_m"]["const"] == g["firing_m"], "Shooting schema")
    for domain in ("cover", "navigation"):
        require(query["$defs"][domain]["properties"]["actor"]["const"] == {"half_extent_m": 0.25}, "Actor schema")
    ids = sorted(actual)
    require(result["$defs"]["shooting"]["properties"]["first_hit_obstacle_id"]["enum"] == [None] + ids, "Obstruction ID law")
    shared = p["model"]["shared"]
    layers = shared["layers"]
    require(layers == [5, 64, 64, 15] and shared["hidden_activation"] == "relu", "Reviewed candidate must remain unchanged")
    params = sum(a * b + b for a, b in zip(layers, layers[1:]))
    require(params == shared["parameter_count"] == 5519 and params * 4 == shared["parameter_bytes"] == 22076, "Shared parameter arithmetic")
    separate = p["model"]["separate"]
    counts = [2 * 64 + 64 + 64 * 64 + 64 + 64 * n + n for n in separate["output_widths"]]
    require(counts == separate["parameter_counts"] and sum(counts) == separate["combined_parameter_count"] == 14031, "Separate arithmetic")
    for value in ("5,519", "22,076", "14,031", "0.25", "1/17", "1/34", "0.01", "0.005"):
        require(value in spec, f"Missing prose contract constant: {value}")
    require(p["cover_rays"] == 17 and p["model"]["boolean_threshold"] == 0.5, "Cover/decode contract")
    require(p["model"]["training_seeds"] == [2101, 2102, 2103, 2104, 2105], "Training seeds")
    require(p["datasets"]["cover"] == {"counts": [15000, 3000, 6000], "seeds": [1101, 1102, 1103]}, "Cover splits")
    require(p["datasets"]["shooting"] == {"counts": [15000, 3000, 6000], "seeds": [1201, 1202, 1203]}, "Shooting splits")
    require(sum(p["datasets"]["tile_counts"].values()) == 256, "Tile partition total")
    require(p["datasets"]["navigation"]["all_nodes"] == 63 ** 2, "Navigation count")
    quality = p["quality"]
    require(quality["false_positives_max"] == quality["obstruction_id_errors_max"] == 0, "Exact-class gates")
    require(quality["false_negative_fraction_max"] == 0.01 and quality["non_finite_or_missing_responses_max"] == 0, "Reviewed quality gates must remain unchanged")
    require(quality["cover_max_error"] == 1/17 and quality["cover_mean_error"] == 1/34, "Cover budgets")
    require((quality["route_cost_max_error_m"], quality["route_cost_mean_error_m"]) == (0.25, 0.125), "Nav budgets")
    require((quality["hit_distance_max_error_m"], quality["hit_distance_mean_error_m"]) == (0.01, 0.005), "Hit budgets")
    b = p["benchmark"]
    require(b["batches"] == [1, 32, 256] and b["primary_batch_size"] == 32, "Batch protocol")
    require(b["paired_process_trials"] == 30 and b["bootstrap_resamples"] == 10000 and b["primary_confidence"] == 0.9875, "Statistics protocol")
    require([b[k] for k in ("workload_seed", "order_seed", "bootstrap_seed")] == [3101, 3102, 3103], "Benchmark seeds")
    check_review_contract(p, spec)
    for doc in (ROOT/"AGENTS.md", ROOT/"README.md", SYSTEM/"README.md", ROOT/"Handover.md"):
        require("independent" in doc.read_text().lower(), f"Missing review gate: {doc}")


def check_review_contract(p: dict, spec: str) -> None:
    protocol = (ROOT/"docs/EXPERIMENT_PROTOCOL.md").read_text()
    thesis = (ROOT/"THESIS.md").read_text()
    model = p["model"]
    require(model["representation_guarantee"] == "none" and model["sampled_pass_certifies_universal_correctness"] is False,
            "Sampled success cannot certify universal geometric safety")
    for phrase in ("continuous logits", "does not guarantee alignment", "not proof of universal correctness", "not a reason to relax gates"):
        require(phrase in spec, f"Missing discontinuity/unchanged-gate boundary: {phrase}")
    freeze = p["final_evaluation"]
    require(freeze["campaigns_per_revision"] == 1 and freeze["freeze_before"] == "final_input_exposure", "Final-input exposure freeze")
    require(freeze["warmup_pool"] == "validation_only" and freeze["final_labels_access"] == "comparator_only", "Final custody")
    require(freeze["allow_adaptive_reruns"] is False, "No adaptive final reruns")
    require(freeze["post_exposure_change"] == {"requires_new_revision": True, "requires_new_sealed_test_set": True}, "Post-exposure revision and test-set replacement")
    require(set(freeze["freeze_artifacts"]) == {
        "all_variant_code", "timing_memory_harness", "analysis_code", "dependency_build_runtime_settings",
        "weights", "decoders", "performance_trace", "trial_order", "warmup_cold_warm_procedures",
        "variant_selection_policy", "failure_policy", "quality_gates"}, "Complete final-freeze artifact contract")
    for phrase in ("Before final inputs are released", "final-freeze manifest", "one registered final-evaluation campaign",
                   "30 paired trials", "new experiment revision and a new sealed final set"):
        require(phrase in protocol, f"Missing measurement custody law: {phrase}")
    require("one registered final-evaluation campaign" in spec and "final-freeze manifest" in spec, "P001/protocol freeze agreement")
    stats = p["benchmark"]["statistics"]
    classes = {"H1": "deterministic_bytes", "H2": "inferential_latency",
               "H3": "deterministic_bytes_and_inferential_latency", "H4": "descriptive_finite_sample_acceptance"}
    require(stats["hypothesis_classes"] == classes and stats["H4_inferential_test"] is False, "Inferential versus deterministic/descriptive allocation")
    expected = [
        {"id": "H2_B_vs_A0", "hypothesis": "H2", "numerator": "shared_B", "denominator": "A0"},
        {"id": "H2_B_vs_A1", "hypothesis": "H2", "numerator": "shared_B", "denominator": "A1"},
        {"id": "H2_B_vs_A2", "hypothesis": "H2", "numerator": "shared_B", "denominator": "A2"},
        {"id": "H3_shared_vs_separate", "hypothesis": "H3", "numerator": "shared_B", "denominator": "combined_separate_B"},
    ]
    require(stats["primary_contrasts"] == expected and stats["correction"] == "bonferroni", "Explicit primary inferential family")
    alpha = stats["family_error_budget"] / len(expected)
    require(stats["family_error_budget"] == 0.05 and stats["alpha_per_contrast"] == alpha == 0.0125, "Contrast-only alpha allocation")
    require(p["benchmark"]["primary_confidence"] == 1 - alpha, "Corrected interval level from inferential contrast count")
    require(stats["interval"] == "two_sided_percentile_bootstrap" and stats["quantile_interpolation"] == "linear", "Interval convention")
    require(stats["quantiles"] == [alpha/2, 1-alpha/2], "Two-sided bootstrap quantiles")
    require(stats["support_if"] == "interval_upper_bound_below_1", "Lower-latency support threshold")
    require(stats["missing_contrast"] == "incomplete_no_support_no_budget_reallocation", "Incomplete contrasts cannot gain significance")
    require(stats["H2_requires_all_three_A_contrasts"] is True and stats["H3_requires_byte_and_latency_benefit"] is True, "Compound claim gates")
    for item in expected:
        require(item["id"] in protocol and item["id"] in spec, f"Missing named contrast: {item['id']}")
    for phrase in ("H1 is a deterministic byte comparison", "H4 is descriptive finite-sample acceptance"):
        require(phrase in thesis, f"Thesis claim classification: {phrase}")
    require("across H1-H4" not in protocol, "Stale hypothesis-based Bonferroni allocation")
    require("interval including 1 is inconclusive" in protocol and "missing trials/contrasts" in protocol, "Inconclusive/incomplete reporting")


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage",choices=("Phase0","P001-A","P001-B1-C","P001-B1-I","P001-B1-P","P001-B1-D","P001-B1-R","P001-G2-1"),default="Phase0")
    args=parser.parse_args()
    required=REQUIRED+(P001_A_FILES if args.stage!="Phase0" else [])
    if args.stage in ("P001-B1-C","P001-B1-I","P001-B1-P","P001-B1-D","P001-B1-R","P001-G2-1"):
        required += P001_B1_C_FILES
    if args.stage in ("P001-B1-I","P001-B1-P","P001-B1-D","P001-B1-R","P001-G2-1"):required += P001_B1_I_FILES
    if args.stage in ("P001-B1-P","P001-B1-D","P001-B1-R","P001-G2-1"):required += P001_B1_P_FILES
    if args.stage in ("P001-B1-D","P001-B1-R","P001-G2-1"):required += P001_B1_D_FILES
    if args.stage in ("P001-B1-R","P001-G2-1"):required += P001_B1_R_FILES
    if args.stage=="P001-G2-1":required += P001_G2_1_FILES
    for name in required:
        path = ROOT / name
        require(path.is_file() and path.stat().st_size > 0, f"Missing/empty deliverable: {name}")
    links = check_links()
    files = sorted(repository_files())
    for path in files:
        rel = path.relative_to(ROOT).as_posix()
        require(rel in required, f"Unexpected {args.stage} artifact: {rel}")
    query = read_json(SYSTEM/"src/common/query.schema.json")
    result = read_json(SYSTEM/"src/common/response.schema.json")
    geometry = read_json(SYSTEM/"experiments/P001/geometry.v1.json")
    prereg = read_json(SYSTEM/"experiments/P001/preregistration.v1.json")
    cases = check_schemas(query, result)
    check_geometry_and_config(geometry, prereg, query, result)
    json_contracts=4
    if args.stage in ("P001-B1-C","P001-B1-I","P001-B1-P","P001-B1-D","P001-B1-R","P001-G2-1"):
        spec=(SYSTEM/"P001_SPEC.md").read_text()
        for name, expected in FROZEN_HASHES.items():
            require(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected, f"Frozen contract changed: {name}")
        check_recipe_text(spec)
        check_frozen_sections(spec)
        registry=read_json(SYSTEM/"experiments/P001/public-fixtures.v1.json")
        custody=read_json(SYSTEM/"experiments/P001/custody.v1.json")
        check_fixture_registry(registry,query,spec)
        check_custody_contract(custody)
        check_b1_documents(ROOT)
        counts=audit_navigation_classification(registry,prereg)
        print("PASS: all 3969 navigation nodes classified under unchanged recipe (no labels): " + json.dumps(counts,sort_keys=True))
        print("PASS: 11 public fixtures/four navigation exclusions; custody/publication specification invariants (enforcement untested)")
        json_contracts += 2
    if args.stage in ("P001-B1-I","P001-B1-P","P001-B1-D","P001-B1-R","P001-G2-1"):
        check_gate1_scope(ROOT)
        json_contracts += 8
        print("PASS: historical Gate 1 receipt/schemas and unconditional separate-authority guard; no new production qualification")
    if args.stage in ("P001-B1-P","P001-B1-D","P001-B1-R","P001-G2-1"):
        from verify_qualification_evidence import validate_package
        validate_package()
    if args.stage in ("P001-B1-D","P001-B1-R","P001-G2-1"):
        check_integrity_contract()
        json_contracts += 2
        print("PASS: explicit custody v2, integrity/regeneration, fail-closed recovery; power survival optional; Gate 2 CLOSED")
    if args.stage in ("P001-B1-R","P001-G2-1"):
        check_runtime_v2_scope(ROOT);json_contracts += 6
        from verify_b1r_evidence import validate_package as validate_b1r_package
        validate_b1r_package(check_current_runtime=args.stage!="P001-G2-1")
    if args.stage=="P001-G2-1":
        check_g2_scope(ROOT);json_contracts += 13
    print(f"PASS {args.stage}: {len(required)} nonempty files; {links} local links; {json_contracts} canonical JSON contracts; {cases} schema cases")
    print("PASS: geometry/prose/schema constants, parameter arithmetic, split budgets, seeds, gates and scope")
    print("PASS: review corrections — unchanged model/gates, final-exposure freeze, one campaign, four inferential contrasts")
    for path in (SYSTEM/"experiments/P001/geometry.v1.json", SYSTEM/"experiments/P001/preregistration.v1.json"):
        print(f"SHA256 {path.relative_to(ROOT)} {hashlib.sha256(path.read_bytes()).hexdigest()}")
    print("LIMIT: this validator does not execute tactical runtime, neural models, benchmarks or independent review")


if __name__ == "__main__":
    try:
        main()
    except (AssertionError, ValueError, KeyError, OSError) as error:
        sys.exit(f"FAIL: {error}")
