#!/usr/bin/env python3
"""Read-only sanitized B1-R execution inventory and retained source verification."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from jsonschema import Draft202012Validator

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'systems/NeuralField/src'))
from dataset.codec import decode,digest

EVIDENCE=ROOT/'docs/evidence/P001_B1_R/v1'
SOURCE='7a8fa2296263d1cace617bd374b25bd92ad0bb84'
MANIFEST_SHA256='4135a11d45294f940dd4958bf15e0551b879a049499c0c5d505cefc8e4024440'


def validate_package(*,check_current_runtime=True):
    raw_manifest=(EVIDENCE/'MANIFEST.json').read_bytes()
    if digest(raw_manifest)!=MANIFEST_SHA256:raise ValueError('immutable evidence manifest')
    if set(p.name for p in EVIDENCE.iterdir())!={'README.md','MANIFEST.json','NATIVE_TESTS.json','NATIVE_FAULTS.json','ENVIRONMENT.json'}:raise ValueError('package closure')
    manifest=decode(raw_manifest)
    if manifest['source_revision']!=SOURCE or manifest['kind']!='synthetic_test_evidence':raise ValueError('source/kind binding')
    expected={'NATIVE_TESTS.json','NATIVE_FAULTS.json','ENVIRONMENT.json'}
    if set(manifest['files'])!=expected:raise ValueError('evidence inventory')
    for name,sha in manifest['files'].items():
        if digest((EVIDENCE/name).read_bytes())!=sha:raise ValueError('evidence hash: '+name)
    tests=decode((EVIDENCE/'NATIVE_TESTS.json').read_bytes());faults=decode((EVIDENCE/'NATIVE_FAULTS.json').read_bytes())
    for name,value in (('gate1-receipt.schema.json',tests),('b1r-execution.schema.json',faults)):
        Draft202012Validator(decode((ROOT/'tools'/name).read_bytes())).validate(value)
    if not tests['passed'] or tests['tests_run']!=62 or tests['failures'] or tests['errors'] or tests['skips']:
        raise ValueError('incomplete native suite')
    if len(tests['records'])!=62 or len({r['test'] for r in tests['records']})!=62 or any(r['outcome']!='pass' for r in tests['records']):
        raise ValueError('per-test outcomes')
    if faults['gate1_receipt_sha256']!=digest((EVIDENCE/'NATIVE_TESTS.json').read_bytes()):raise ValueError('execution pairing')
    checks={(r['point'],r['execution'],r['outcome']) for r in faults['failure_checks']}
    expected_checks={
        ('AFTER_REGISTRATION_RECORD','linux_native','fail_closed'),('AFTER_REGISTRATION','linux_native','fail_closed'),
        ('WRITE:training/queries.jsonl','linux_native','fail_closed'),('AFTER_RECEIPT','linux_native','fail_closed'),
        ('BEFORE_RENAME','linux_native','fail_closed'),('AFTER_RENAME','linux_native','verified_survivor'),
        ('AFTER_PARENT_FSYNC','linux_native','verified_survivor'),('AFTER_LOSS_RECORD','linux_native','fail_closed'),
        ('AFTER_INVALIDATION','linux_native','fail_closed'),('replacement-after-rename','linux_native','verified_survivor'),
        ('competing-publish-recovery-invalidation','linux_native','serialized'),
    } | {(p,'simulated_fault','fail_closed') for p in (
        'registration-rename','index-replace','catalog-sync','record-file-sync','payload-file-sync','receipt-file-sync','recovery-file-sync')}
    if checks!=expected_checks or len(faults['failure_checks'])!=len(expected_checks):raise ValueError('failure coverage')
    for name,sha in faults['contract_hashes'].items():
        if digest((ROOT/'systems/NeuralField/experiments/P001'/name).read_bytes())!=sha:raise ValueError('active context')
    paths=subprocess.check_output(['git','ls-tree','-r','--name-only',SOURCE],cwd=ROOT,text=True).splitlines()
    expected_source={p for p in paths if p.endswith('.py') and any(p.startswith(area+'/') for area in ('systems/NeuralField/src','systems/NeuralField/tests','tools'))}
    if set(tests['source_hashes'])!=expected_source:raise ValueError('complete source closure')
    for path,sha in tests['source_hashes'].items():
        raw=subprocess.check_output(['git','show',SOURCE+':'+path],cwd=ROOT)
        if digest(raw)!=sha:raise ValueError('executed source mismatch: '+path)
        if check_current_runtime and path.startswith(('systems/NeuralField/src/','systems/NeuralField/tests/')) and digest((ROOT/path).read_bytes())!=sha:
            raise ValueError('current runtime/tests diverge from evidence: '+path)
    environment=decode((EVIDENCE/'ENVIRONMENT.json').read_bytes())
    if environment['uid']!=501 or environment['mount']['filesystems'][0]['source']!='/dev/vda1' or environment['mount']['filesystems'][0]['fstype']!='ext4':raise ValueError('native execution environment')
    if tests['actual_uid_isolation']!='not_executed' or environment['custody_profile_execution']!='not_performed' or manifest['production_qualified']:
        raise ValueError('qualification claim drift')
    for name,sha in environment['lock_hashes'].items():
        if name not in ('requirements-reference.txt','requirements-dataset.txt') or digest((ROOT/name).read_bytes())!=sha:raise ValueError('dependency lock mismatch')
    for name,version in environment['dependencies'].items():
        if name+'=='+version not in (ROOT/'requirements-dataset.txt').read_text() and name+'=='+version not in (ROOT/'requirements-reference.txt').read_text():raise ValueError('unpinned dependency')
    print('PASS: B1-R 62 native synthetic tests, 18 failure/concurrency observations, source/context/hash bindings')
    if not check_current_runtime:print('HISTORICAL: original execution/source binding only; not qualification of the current runtime')
    print('LIMIT: unprivileged test identity; no consumer launch, production publication or VM/power-loss qualification')


if __name__=='__main__':
    try:validate_package(check_current_runtime=False)
    except (AssertionError,ValueError,KeyError,OSError,subprocess.CalledProcessError) as error:sys.exit('FAIL: '+str(error))
