# P001-B1 Gate 2 — Real dataset foundation work packet

Repository: `WRRTREPO/NEURAL`. System: NeuralField. Baseline: `cdfd03a2afaad5488485e78e6e694b5a1627ef00`, normal merge of accepted [PR #8](https://github.com/WRRTREPO/NEURAL/pull/8) at `d9ac3e49b546504b25aec919f11f4b813e635b64`.

**Status: PROPOSED. Packet preparation only is authorized.** This document grants no runtime implementation, privileged deployment, real generation/publication, final-input exposure, neural work, benchmark or merge permission. Stop for independent packet review and explicit authorization.

## 1. Objective and governing authority

Produce one reproducible, independently verified P001 dataset generation with training/validation artifacts available only through approved views, and all final inputs/labels sealed under custodian authority. Preserve [P001 §5](../systems/NeuralField/P001_SPEC.md#5-dataset-construction-and-custody), [experiment protocol](EXPERIMENT_PROTOCOL.md), [fixture registry](../systems/NeuralField/experiments/P001/public-fixtures.v1.json), [custody v2](../systems/NeuralField/experiments/P001/custody.v2.json), [integrity v1](../systems/NeuralField/experiments/P001/integrity.v1.json) and [accepted B1-R runtime laws](P001_B1_R_IMPLEMENTATION.md).

No geometry, query/output semantics, thresholds, model, seeds or scientific recipe may change to fit implementation or resources. Conventional A0/A1 and the separate polygon/graph checker must independently agree for every label, not just a sample. Negative evidence remains evidence; a mismatch closes the affected generation.

P001 requires verified local integrity and deterministic regeneration, not guaranteed availability after guest/VM/host power failure. Do not reopen physical power-loss qualification, replace synchronization infrastructure or introduce external storage/model services.

## 2. Proposed bounded authorization sequence

These are operational stop points within the proposed packet, not additional research phases. Approval of the packet alone must state which actions are authorized; do not infer execution or root access from source permission.

| Step | Proposed work | Stop condition |
| --- | --- | --- |
| G2-1 — Runtime activation | Production-specific schemas, custody-aware store/authority adapter, complete deterministic generator/label/audit path and reduced synthetic regressions; dedicated implementation PR | Independent review of the exact runtime revision; no real artifacts before acceptance |
| G2-2 — Deployment and synthetic admission checks | If explicitly authorized, deploy that reviewed source/profile side by side on existing Colima ext4, then qualify the changed boundary using disposable sentinels | Stop on missing identities/resources, changed hashes or any failed access/publication/recovery check; no real generation without a separate explicit execution grant |
| G2-3 — One real generation | Only after the reviewed runtime, deployment checks and explicit generation grant: generate, independently verify, register and atomically publish/seal one fresh immutable generation | Stop after auditable counts/hashes/custody receipts and independent dataset evidence submission; no training, final-input release or benchmarking |

An owner may authorize a bounded deployment and execution together after reviewing G2-1, but the implementation must enforce every G2-2 prerequisite before any real artifact creation. This turn authorizes none of G2-1–G2-3. No automatic retries, replacement generation or dataset merge follow a failure.

## 3. Current implementation gaps

The accepted [authority guard](../systems/NeuralField/src/dataset/authority.py) unconditionally closes every real API. [SyntheticStore](../systems/NeuralField/src/dataset/storage.py) is temporary-only, has a 22-row artifact contract and requires private 0700/0600 trees. [Recipe.generate_production](../systems/NeuralField/src/dataset/recipe.py) has an unreachable full construction path, not execution evidence. Production bundle/publication/launch entrypoints remain stubs behind the guard.

The [existing launch schema](../systems/NeuralField/src/dataset/launch-profile.schema.json) is explicitly `synthetic_qualification_only` and hardcodes qualification paths. It cannot authorize the live P001 store. Current [v1 deployment receipts](evidence/P001_B1_P/v1/README.md) bind the original source, while [B1-R evidence](evidence/P001_B1_R/v1/README.md) binds unprivileged temporary-store execution. Neither is a new deployed production runtime receipt.

G2-1 must create explicit real-artifact/profile versions and production permission validation; it must not loosen synthetic quotas, accept a synthetic receipt as production authority, silently reinterpret v1 evidence or merely remove `require_gate2`. Preserve the existing synthetic path and historical schemas/evidence.

## 4. Frozen dataset construction

Use pinned NumPy 1.26.4 and both existing dependency locks. Freeze the exact reviewed source/tree, geometry/snapshot, fixture registry, custody/integrity/schema hashes, interpreter and configuration before generation. Record complete PCG64 states and rejected-draw counts for each stream.

- Tiles: unchanged SHA-256 ordering of `p001.v1:tiles:20261011:tx:ty`; 160 training, 32 validation, 64 final tiles. Publish this fixed membership before any future training; no labels or final request coordinates accompany it.
- Cover: 15,000 training, 3,000 validation and 6,000 ordinary final requests; seeds 1101/1102/1103. Shooting has the same quotas with seeds 1201/1202/1203. Draw x then y as integer micrometres in the closed 0..16,000,000 range. Preserve forbidden-public, semantic duplicate, split, domain and final-reservation rejection. Do not filter illegal cover or obstructed shooting. Enforce the preregistered rejection budget; failure cannot silently reduce quotas or pick new seeds.
- Navigation: enumerate all 3,969 nodes lexicographically. Public → excluded; reserved challenge → final; otherwise prescribed centre tile. Existing independently validated assignments are public 4, reserved 225, training 2,336, validation 476 and ordinary final 928. Exhaustive reference tests do not add exclusions. Every retained node appears exactly once with the registered actor/destination.
- Final challenges: construct the full §5 recipe privately before ordinary sampling. Cover uses expanded obstacle corners/midpoints; shooting uses raw features, extended corner rays and specified passage targets. Preserve unperturbed points and all signed 1 micrometre/1 millimetre/1 centimetre offsets, rational extension factors and ties-to-even rounding. Add the separate world edge/corner status suite, retaining invalid/out-of-domain responses. Remove declared public fixtures and deduplicate by semantic request.
- Final challenges/statuses are excluded from training/validation irrespective of tile. Overlap with ordinary final data is counted once. Retain suite-membership metadata separately so union deduplication cannot erase stratum coverage or change the ordinary final quotas. Keep evaluator strata out of model features.

Expected ordinary training total: 32,336; validation: 6,476; ordinary final: 12,928. Navigation reserves add 225 final queries. Continuous challenge/status union counts are determined by the unchanged recipe and must be reported after actual generation, not guessed now. Preserve separate ordinary/suite counts, overlaps, union totals and every required nonempty stratum in private audit metadata.

## 5. Independent labels, audits and provenance

Every query must preserve its identity, snapshot, domain, status precedence and finite/null laws. Status-suite requests intentionally retain invalid/out-of-domain coordinates: validate their registered status-case envelope and exact reference response, rather than dropping them because the ordinary valid-domain query schema rejects them. Obtain A0 and A1 results and independently check geometry/navigation with the separate checker. Verify exact predicates/IDs/statuses and existing numerical oracle tolerances. Any disagreement preserves input, expected/actual results, geometry version and source privately; do not repair labels, change tolerances or publish partial data.

Independently audit all split memberships, duplicates, public exclusions, reserved membership/completeness, ordinary quotas, navigation coverage, status retention and challenge strata. Verify every label, schema, file hash and count before registration/publication and again for recovered admission. No subset of labels may be accepted on the strength of a global hash alone.

A real generation uses an explicit real-kind schema distinct from synthetic schemas. It records actual Git source revision/tree and code/schema hashes, geometry/world version, six sampling seeds/states, generation configuration, contract/dependency/interpreter bindings, complete artifact closure/counts/hashes and independent audit receipts. No training architecture, weights or experimental latency/memory results are created. Source-hash claims and synthetic test provenance cannot substitute for the real reviewed revision.

Determinism is verified without publishing a second real identity: a custodian-private replay/stream audit against the frozen recipe checks canonical semantic queries and verified labels. Approved reduced tests may exercise the full code path with a separately declared toy recipe; production quotas/seeds remain immutable. Do not claim synthetic repeatability is itself proof of the completed real generation.

## 6. Trusted registration, publication and recovery

Extend the accepted private catalog/lock design for real-kind records. The custodian catalog stays outside candidate generations and outside every consumer view. Register immutable expected manifest/completion hashes, actual counts, frozen replay provenance and identity before publication; the receipt/catalog digest design must remain acyclic. Never import expectations from an unregistered candidate during recovery.

One store-local interprocess lock serializes registration, publication, recovery, invalidation and admission through validation and synchronization. Reject missing/corrupt/orphan/pending trust transactions, identity collisions, aliases, external hardlinks, unexpected ACLs, special objects, writable consumer authority or device drift. Do not rebuild missing registration from a candidate or automatically regenerate on registration loss.

Retain GENERATING → VERIFYING → VERIFIED, private staging, checked file/receipt/nested-directory fsync, same-filesystem `renameat2(RENAME_NOREPLACE)`, both rename-parent fsync and complete post-recovery validation before local success. A failed synchronization, rename or uncertain response cannot be reported as publication success. An intact post-rename survivor is verified under the original registration; interrupted stages are quarantined and reserved identities retired.

Registered missing generations produce durable local loss/invalidation records. Retired identities cannot return even if old bytes reappear. Any later replacement requires explicit owner authorization, a fresh identity, restored trusted frozen provenance, full verification and private lineage. Known loss does not invalidate a properly verified replacement. Incomplete/corrupt/ambiguous state closes consumption and retains diagnostics; no in-place repair, hash rewrite or silent admission.

Loss of the trusted catalog itself requires authorized provenance recovery, not candidate reconstruction or implicit replacement. Preserve final exposure/freeze history; generation recovery never permits adaptive retesting or model changes. Since final exposure is closed in this packet, no evaluator receives final inputs.

## 7. Actual custody and bounded deployment

Designate the existing Colima Ubuntu ARM64 VM, native `/dev/vda1` ext4 and `/var/lib/neuralfield/P001`. Recheck the actual host/kernel/filesystem identity, capacity, source/profile hashes and permissions before execution. Virtiofs and Docker overlay storage cannot host authoritative artifacts. No repartitioning, VM reset/configuration change, new accounts, unrelated dependencies or physical failure test is proposed.

Use the existing non-login, locked identities: nf-custodian UID/GID 11001; nf-train 11002; nf-infer 11003. Recheck identities/groups rather than recreate or substitute them. Data/catalog/staging/quarantine ownership belongs to nf-custodian. The reviewed source, launcher, isolated interpreter and configuration are root-owned and consumer-unwritable; install a separately versioned runtime/profile only under an explicit bounded privileged-deployment grant. Preserve the original installed qualification files/receipts and do not overwrite unrelated resources.

Production permission validation must distinguish the exact custody v2 classes: generation traversal 0711, training/validation directories 0750 and files 0640 with nf-train group, and final inputs/labels, catalog, staging/quarantine/diagnostics 0700 directories/0600 files. Do not relax the synthetic/private validator to allow consumer-readable sealed resources. Choose and record the complete production path/ownership map and versioned launch configuration before privileged deployment. Final inputs and labels remain private throughout staging, publication and recovery.

Approved consumer views contain only the contracted artifacts; no whole generation/store/catalog mount is allowed. Keep training, inference, runtime, jail and private resource roots disjoint under the accepted no-ancestry law. Training has read-only approved training/validation access. Inference receives no training/validation labels, final inputs or final labels; its Gate 2 probe uses only explicitly synthetic approved sentinels. No inference implementation is installed. Custodian alone can read real final records; final comparison and release remain future authorities.

Requalify the changed source/profile/path boundary using actual identities and launch environment: empty consumer supplementary groups; zero effective/bounding capabilities; NoNewPrivs; private mount/PID namespaces; closed inherited descriptors; root-owned trusted runtime; approved reads, denied writes and denied reads of final inputs/labels/catalog/staging/quarantine/diagnostics. Use disposable sentinel resources before real creation, never sealed contents. Bind receipts to the actual filesystem, identities, source, dependency locks and profile. Old v1 receipts remain historical evidence, not authority for a new mount profile.

Publication may finish only with current custody tests passed. Mounting training artifacts is itself a controlled admission after complete verification; future training remains separately closed. Public progress/errors must contain no final records, private lineage, label distributions, sentinels or credentials.

## 8. Execution authority and one-generation stop

Keep real operation disabled by default. Separate permissions for generate/publish/audit, final-input release, training and benchmarking; enabling generation cannot unlock the others. G2-1 should define a minimal root/custodian-protected immutable operator grant binding the owner's explicit decision, exact reviewed source/configuration, custody/integrity hashes, qualified host/filesystem/profile, output root and one fresh generation identity. It is an authorization record, not a cloud service or physical durability witness.

No command-line flag, user-writable grant, standalone qualification receipt, self-issued manifest or successful test can grant real execution. Reject absent/mismatched grants before real output-path access. Final-input release, neural and benchmark APIs remain independently unconditional rejections within this packet's implementation scope. Guards must reject production calls even when a caller forges nominal authority fields.

Before starting, the operator records a private source/input/dependency/space preflight and trusted generation registration plan. Insufficient resources close execution; do not reduce quotas, stream unverified outputs into consumer views or provision more infrastructure implicitly. Temporary spills and logs stay on private native ext4. One authorized generation is immutable; no second real run, retry, recovery replacement or extra diagnostic dataset follows without a bounded owner decision. After failure retain diagnostics and report; do not adjust seeds or rerun until a favorable result appears.

## 9. Acceptance, evidence and delivery

G2-1 acceptance requires meaningful reduced tests for real-kind/schema confusion, operation-grant rejection, full recipe/audit invariants, independent label failure, mixed public/private modes, catalog loss/retirement, corruption, no-overwrite/fsync/interruption and concurrent lifecycle calls. Existing reference/contracts/B1-R evidence validation and Linux Python 3.9/3.12 CI must pass. Source review is required before deployment or real execution.

G2-2 acceptance requires actual profile isolation, approved/denied access, immutable trusted runtime and native ext4 local publication/recovery evidence under the deployed revision. Synthetic mocks and development UID receipts cannot replace consumer-profile checks. A missing prerequisite blocks real creation. Do not require power-loss survival.

G2-3 passes only after all real rows/labels/splits/strata, schemas/hashes/provenance, trusted registration, synchronization, permissions and sealed custody are independently verified with zero incorrect labels, partial admissions or leaks. Submit private verification evidence to the authorized reviewer through custodian-controlled access; an ordinary PR never carries final requests/labels. A public allowlisted manifest contains generation ID, contract versions, source revision, artifact hashes, counts, verification/custody flags and receipt hash only. Detailed audit/class/error/exposure/loss/lineage records remain private.

The evidence report distinguishes implementation tests, actual deployed custody checks, real dataset verification and unknown power-loss availability. Report source/deployment/generation identities, public inventory hashes/counts, private review-access method, every failure, remaining dependency and next closed gate. Do not fabricate completion counts or qualification results.

Deliver G2-1 on a dedicated implementation branch/PR, update Plan/Handover, and stop for review. Any later deployment or one-generation execution must be explicitly authorized and stop at its own evidence handoff. Real dataset acceptance does not authorize PR merge, final-input exposure, neural implementation/training or A/B execution. Those remain P001-B2/P001-C and future freeze authorities.

## 10. Immediate next decision

Independently review this packet. The smallest next authorization is **G2-1 production adapter/source/schema implementation and reduced synthetic testing**, preserving separate deployment and real-execution grants. No missing source blocks packet preparation; the existing production stubs, synthetic-only launch schema and deployment binding are explicit implementation dependencies.

Stop here. Gate 2, final-input exposure, P001-B2, P001-C and merge of this work-packet branch remain closed.
