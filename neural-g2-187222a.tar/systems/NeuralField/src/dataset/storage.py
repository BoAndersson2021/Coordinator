"""Synthetic immutable generations, no-overwrite commit, quarantine and admission."""
from contextlib import contextmanager
import threading
import ctypes
import errno
import os
from pathlib import Path
import re
import stat
import sys
import tempfile

from dataset.artifacts import verify_bundle, schema_check
from dataset.authority import require_gate2
from dataset.codec import canonical, decode, digest


class AdmissionFailure(RuntimeError):
    def __init__(self, category, evidence=None):
        self.evidence=evidence
        super().__init__(category)


class NativeOps:
    name='linux-native' if sys.platform=='linux' else 'unsupported-native'
    def __init__(self):
        if sys.platform!='linux':raise AdmissionFailure('Linux atomic publication unavailable')
    def rename(self, source, destination):
        if sys.platform!='linux':raise AdmissionFailure('Linux renameat2 unavailable; no production fallback')
        libc=ctypes.CDLL(None,use_errno=True)
        try:fn=libc.renameat2
        except AttributeError:raise AdmissionFailure('renameat2 unavailable')
        fn.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint]
        fn.restype=ctypes.c_int
        if fn(-100,os.fsencode(source),-100,os.fsencode(destination),1):
            error=ctypes.get_errno();raise OSError(error,os.strerror(error),str(destination))

    def replace(self, source, destination):
        os.replace(source,destination)

    def sync_file(self, path):
        fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
        try:os.fsync(fd)
        finally:os.close(fd)

    def sync_dir(self, path):
        fd=os.open(path,os.O_RDONLY|getattr(os,'O_DIRECTORY',0)|getattr(os,'O_NOFOLLOW',0))
        try:os.fsync(fd)
        finally:os.close(fd)


def secure_tree(path, uid, device):
    """Reject aliases, special files, writable groups, ownership and filesystem drift."""
    for item in [path]+list(path.rglob('*')):
        info=item.lstat()
        if info.st_uid!=uid or info.st_dev!=device or stat.S_ISLNK(info.st_mode):raise AdmissionFailure('ownership/device/alias')
        if not (stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode)):raise AdmissionFailure('special file')
        if stat.S_ISREG(info.st_mode) and info.st_nlink!=1:raise AdmissionFailure('external hardlink')
        if info.st_mode&0o022:raise AdmissionFailure('group/other write authority')
        if stat.S_ISREG(info.st_mode) and info.st_mode&0o077:raise AdmissionFailure('private file permissions')
        if stat.S_ISDIR(info.st_mode) and info.st_mode&0o077:raise AdmissionFailure('private directory permissions')
        if hasattr(os,'listxattr'):
            attrs=os.listxattr(item)
            if any('acl' in n.lower() for n in attrs):raise AdmissionFailure('unexpected ACL')


def write_exclusive(path, raw):
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
    try:
        with os.fdopen(fd,'wb') as stream:
            stream.write(raw);stream.flush();os.fsync(stream.fileno())
    except BaseException:raise


class SyntheticStore:
    """Temporary, bounded synthetic authority; no production or deployment admission."""
    KIND='synthetic'
    MARKER_NAME='.synthetic-store.json'
    TOP_DIRS=('.staging','generations','quarantine','diagnostics')
    ROOT_MODE=0o700
    GENERATIONS_MODE=0o700
    COMPLETION_SCHEMA='completion.v2.schema.json'
    REGISTRATION_VERSION='p001-synthetic-registration.v1'
    STATE='SYNTHETIC COMMITTED'
    RETIRE_REASON='explicit_synthetic_retirement'
    MARKER={'store_version':'p001-synthetic-store.v2','kind':'synthetic','production_qualified':False}

    def __init__(self, root, recipe, labeler, *, ops=None, hook=None):
        path=Path(root)
        temps=(Path(tempfile.gettempdir()).resolve(),Path('/tmp').resolve())
        if '..' in path.parts or path.is_symlink() or not any(path.resolve().is_relative_to(t) and path.resolve()!=t for t in temps):
            raise AdmissionFailure('synthetic store must be a private temporary child')
        self._initialize(path,recipe,labeler,ops=ops,hook=hook)

    def _initialize(self,path,recipe,labeler,*,ops=None,hook=None):
        if self.KIND=='real':
            from dataset.generation_authority import require_generation,ROOT
            require_generation('audit')
            if Path(path)!=ROOT:raise AdmissionFailure('real store root')
        self.root=path.resolve();self.recipe=recipe;self.labeler=labeler
        self.ops=NativeOps() if ops is None else ops;self.hook=(lambda point:None) if hook is None else hook
        self.root.mkdir(mode=self.ROOT_MODE,parents=True,exist_ok=True)
        if stat.S_IMODE(self.root.stat().st_mode)!=self.ROOT_MODE:raise AdmissionFailure('store root permissions')
        self.uid=os.getuid();self.device=self.root.stat().st_dev
        self.mutex=threading.RLock();self.recovered=False
        from dataset.trust import Catalog
        self.catalog=self._catalog_class()(self)
        with self._lock(initial=True):
            marker=self.root/self.MARKER_NAME
            if not marker.exists():
                if set(p.name for p in self.root.iterdir())!={'.lock'}:raise AdmissionFailure('nonempty unmarked store')
                for name in self.TOP_DIRS:(self.root/name).mkdir(mode=self.GENERATIONS_MODE if name=='generations' else 0o700)
                self.catalog.initialize()
                self._write(marker,canonical(self.MARKER));self.ops.sync_dir(self.root)
            self._secure(self.root)
            if decode(marker.read_bytes())!=self.MARKER:raise AdmissionFailure('store version/identity')
            self._structure();self.catalog.load()

    def _catalog_class(self):
        from dataset.trust import Catalog
        return Catalog

    def _secure(self,path):secure_tree(path,self.uid,self.device)
    def _artifact_directories(self):return {'training','validation','private'}
    def _artifact_files(self):
        from dataset.artifacts import FILES
        return FILES
    def _verify(self,artifact):return verify_bundle(artifact,self.recipe,self.labeler)
    def _prepare_permissions(self,stage):pass
    def _reprivate(self,stage):pass
    def _catalog_access(self,operation):
        if self.KIND=='real':
            from dataset.generation_authority import require_generation,ROOT
            require_generation(operation)
            if self.root!=ROOT:raise AdmissionFailure('real store root')
    def _bind_loss(self,record):pass
    def _bind_registration(self,record,artifact):pass
    def _check_replacement(self,record,old):
        if any(record[k]!=old[k] for k in ('provenance','manifest_sha256','counts')):raise AdmissionFailure('regeneration changed frozen content')
    def _failure_schema(self):return 'failure.schema.json'
    def _completion(self,generation,artifact,manifest):
        from dataset.artifacts import VERSION
        return {'artifact_version':VERSION,'kind':self.KIND,'generation_id':generation,'state':self.STATE,
                'production_qualified':False,'manifest_sha256':digest(artifact['manifest.json']),'counts':manifest['counts'],
                'source_revision':manifest['source_revision'],'contract_versions':['p001-custody.v2','p001-integrity.v1'],
                'verification_pass':True,'custody_pass':False,'backend':self.ops.name}

    @contextmanager
    def _lock(self, initial=False):
        try:import fcntl
        except ImportError:raise AdmissionFailure('interprocess locking unavailable')
        with self.mutex:
            flags=os.O_RDWR|getattr(os,'O_NOFOLLOW',0)
            if initial and not (self.root/self.MARKER_NAME).exists():flags|=os.O_CREAT
            fd=os.open(self.root/'.lock',flags,0o600)
            try:
                info=os.fstat(fd)
                if info.st_uid!=self.uid or info.st_dev!=self.device or not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or stat.S_IMODE(info.st_mode)!=0o600:
                    raise AdmissionFailure('unsafe store lock')
                fcntl.flock(fd,fcntl.LOCK_EX)
                yield
            except BaseException:
                self.recovered=False
                raise
            finally:os.close(fd)

    def _structure(self):
        self._secure(self.root)
        if decode((self.root/self.MARKER_NAME).read_bytes())!=self.MARKER:raise AdmissionFailure('store version/identity drift')
        if set(p.name for p in self.root.iterdir())!={self.MARKER_NAME,'.lock','.trust'}|set(self.TOP_DIRS):
            raise AdmissionFailure('store closure')
        for name in ('.trust',)+self.TOP_DIRS:
            if not (self.root/name).is_dir():raise AdmissionFailure('missing private store resource')

    def _write(self, path, raw):
        self._catalog_access('publish')
        # Both catalog and payload synchronization faults use the same testable primitive.
        write_exclusive(path,raw)
        self.hook('AFTER_FILE_FSYNC:'+str(path.relative_to(self.root)))

    @staticmethod
    def identity(generation):
        if type(generation) is not str or not re.fullmatch(r'synthetic-[a-zA-Z0-9-]{1,64}',generation):raise AdmissionFailure('synthetic generation identity')

    def event(self, stage, state):
        self._catalog_access('publish')
        fd=os.open(stage/'events.jsonl',os.O_WRONLY|os.O_APPEND|os.O_CREAT|getattr(os,'O_NOFOLLOW',0),0o600)
        with os.fdopen(fd,'ab') as stream:stream.write(canonical({'state':state,'kind':self.KIND}));stream.flush();os.fsync(stream.fileno())

    def quarantine(self, stage, reason):
        record={'kind':self.KIND,'state':'QUARANTINED','reason':str(reason),'evidence':None}
        if hasattr(reason,'evidence'):record['evidence']=reason.evidence
        schema_check(self._failure_schema(),record)
        self._reprivate(stage)
        if not (stage/'failure.json').exists():self._write(stage/'failure.json',canonical(record))
        self.event(stage,'QUARANTINED');self._secure(stage)
        self.ops.sync_dir(stage)
        self.ops.rename(stage,self.root/'quarantine'/stage.name)
        self.ops.sync_dir(self.root/'.staging');self.ops.sync_dir(self.root/'quarantine')

    def _diagnostic(self, error):
        # Only private diagnostic files retain label-level evidence. Never print it.
        raw=canonical({'category':type(error).__name__,'evidence':getattr(error,'evidence',None)})
        directory=self.root/'diagnostics'
        secure_tree(directory,self.uid,self.device)
        name=digest(raw)+'.json'
        if not (directory/name).exists():self._write(directory/name,raw)
        self.ops.sync_dir(directory)

    def _read(self, directory):
        self._secure(directory)
        if {str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_dir()}!=self._artifact_directories():
            raise AdmissionFailure('artifact directory closure')
        excluded={'events.jsonl','completion.json'}
        return {str(p.relative_to(directory)):p.read_bytes() for p in directory.rglob('*') if p.is_file() and str(p.relative_to(directory)) not in excluded}

    def _admit(self, generation, records):
        self.identity(generation)
        if generation not in records['registrations'] or generation in records['losses']:raise AdmissionFailure('unregistered or retired generation')
        expected=records['registrations'][generation]
        directory=self.root/'generations'/generation
        artifact=self._read(directory);raw=(directory/'completion.json').read_bytes()
        if digest(artifact['manifest.json'])!=expected['manifest_sha256'] or digest(raw)!=expected['completion_sha256']:
            raise AdmissionFailure('trusted artifact expectation mismatch',{'generation_id':generation,'expected_manifest_sha256':expected['manifest_sha256'],'actual_manifest_sha256':digest(artifact['manifest.json']),'expected_completion_sha256':expected['completion_sha256'],'actual_completion_sha256':digest(raw)})
        receipt=decode(raw);schema_check(self.COMPLETION_SCHEMA,receipt)
        metadata=decode(artifact['private/provenance.json'])
        if metadata!=expected['provenance']:raise AdmissionFailure('trusted replay context mismatch')
        manifest=self._verify(artifact)
        if receipt['generation_id']!=generation or receipt['source_revision']!=metadata['source_revision'] or receipt['manifest_sha256']!=digest(artifact['manifest.json']) or receipt['counts']!=manifest['counts'] or receipt['counts']!=expected['counts']:
            raise AdmissionFailure('completion mismatch')
        events=[decode(line) for line in (directory/'events.jsonl').read_bytes().splitlines(keepends=True)]
        if events!=[{'kind':self.KIND,'state':state} for state in ('GENERATING','VERIFYING','VERIFIED')]:raise AdmissionFailure('invalid state history')
        for path in directory.rglob('*'):
            if path.is_file():self.ops.sync_file(path)
        for path in sorted([directory]+[p for p in directory.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):self.ops.sync_dir(path)
        return receipt

    def _recover(self):
        self.recovered=False;self._structure()
        _,records=self.catalog.load()
        committed={p.name:p for p in (self.root/'generations').iterdir()}
        staged={p.name:p for p in (self.root/'.staging').iterdir()}
        if set(committed)&set(staged):raise AdmissionFailure('conflicting staged/committed identities')
        for identity,path in list(committed.items())+list(staged.items()):
            self.identity(identity)
            if not path.is_dir():raise AdmissionFailure('ambiguous generation object')
        # Validate all survivors before returning any authority or performing loss disposition.
        admitted=[]
        for identity in sorted(committed):admitted.append(self._admit(identity,records))
        for identity in sorted(staged):
            self.quarantine(staged[identity],'interrupted unpublished generation')
        for identity in sorted(records['registrations']):
            if identity not in committed and identity not in records['losses']:
                self.catalog.retire(identity,'interrupted_unpublished_generation' if identity in staged else 'registered_generation_missing')
        self.ops.sync_dir(self.root/'.staging');self.ops.sync_dir(self.root/'generations')
        self.recovered=True
        return admitted

    def recover(self):
        with self._lock():
            try:return self._recover()
            except Exception as error:
                self._diagnostic(error)
                raise

    def admit(self, generation):
        with self._lock():
            if not self.recovered:raise AdmissionFailure('recovery/admission gate not completed')
            receipts=self._recover()
            return next((r for r in receipts if r['generation_id']==generation),None) or self._deny()

    @staticmethod
    def _deny():raise AdmissionFailure('generation not admitted')

    def invalidate(self, generation):
        with self._lock():
            self.identity(generation);self.recovered=False;self._structure();self.catalog.load()
            if (self.root/'generations'/generation).exists() or (self.root/'.staging'/generation).exists():
                raise AdmissionFailure('retirement requires absent synthetic generation')
            return self.catalog.retire(generation,self.RETIRE_REASON)

    def _publish(self, generation, artifact, replacement=None):
        self._catalog_access('publish')
        self.identity(generation)
        self._recover();self.recovered=False
        index,records=self.catalog.load()
        if generation in records['registrations'] or any((self.root/n/generation).exists() for n in ('.staging','generations','quarantine')):raise AdmissionFailure('generation ID already used')
        stage=self.root/'.staging'/generation;dest=self.root/'generations'/generation
        stage.mkdir(mode=0o700);self.ops.sync_dir(self.root/'.staging')
        try:
            self.event(stage,'GENERATING')
            from dataset.artifacts import VERSION
            if set(artifact)!=set(self._artifact_files())|{'manifest.json'}:raise AdmissionFailure('artifact paths')
            # Trusted producer verifies the bounded in-memory bundle before registering
            # expectations, then independently verifies the persisted bytes again.
            manifest=self._verify(artifact)
            receipt=self._completion(generation,artifact,manifest)
            schema_check(self.COMPLETION_SCHEMA,receipt);raw=canonical(receipt)
            registration={'record_version':self.REGISTRATION_VERSION,'kind':self.KIND,'generation_id':generation,
                          'manifest_sha256':receipt['manifest_sha256'],'completion_sha256':digest(raw),
                          'counts':manifest['counts'],'provenance':decode(artifact['private/provenance.json']),'replacement':replacement}
            self._bind_registration(registration,artifact)
            if replacement is not None:
                old=records['registrations'][replacement['retired_generation_id']]
                self._check_replacement(registration,old)
            self.catalog.add('registrations',generation,registration);self.hook('GENERATING')
            for name,payload in artifact.items():
                path=stage/name
                parent=stage
                for component in Path(name).parts[:-1]:
                    parent=parent/component;parent.mkdir(mode=0o700,exist_ok=True)
                self._write(path,payload);self.hook('WRITE:'+name)
            self.event(stage,'VERIFYING');self.hook('VERIFYING')
            self._verify(self._read(stage))
            self.event(stage,'VERIFIED');self.hook('VERIFIED')
            self._write(stage/'completion.json',raw);self.hook('AFTER_RECEIPT')
            self._prepare_permissions(stage)
            for directory in sorted([stage]+[p for p in stage.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):self.ops.sync_dir(directory)
            self._secure(stage);self.hook('BEFORE_RENAME')
            self.ops.rename(stage,dest);self.hook('AFTER_RENAME')
            self.ops.sync_dir(self.root/'.staging');self.ops.sync_dir(self.root/'generations');self.hook('AFTER_PARENT_FSYNC')
            receipts=self._recover()
            return next(r for r in receipts if r['generation_id']==generation)
        except Exception as error:
            self.recovered=False
            if stage.exists():self.quarantine(stage,error)
            raise
        except BaseException:
            self.recovered=False
            raise

    def publish(self, generation, artifact):
        with self._lock():
            if not self.recovered:raise AdmissionFailure('recover before publish')
            return self._publish(generation,artifact)

    def regenerate(self, retired, fresh):
        """Explicit reduced replay only; missing trust never triggers generation."""
        with self._lock():
            self.identity(retired);self.identity(fresh);self._recover()
            index,records=self.catalog.load()
            if retired not in records['losses']:raise AdmissionFailure('trusted loss required for regeneration')
            from dataset.pipeline import synthetic_bundle
            context=records['registrations'][retired]['provenance']
            artifact=synthetic_bundle(context['source_revision'],self.recipe,self.labeler)
            replacement={'retired_generation_id':retired,'loss_sha256':index['losses'][retired]}
            self.hook('BEFORE_REPLACEMENT')
            return self._publish(fresh,artifact,replacement)


def production_publish(*, generation=None, artifact=None, authorization=None, qualification=None):
    from dataset.generation_authority import require_generation
    grant=require_generation('publish',generation,authorization=authorization,qualification=qualification)
    from dataset.real_store import ProductionStore
    store=ProductionStore();store.recover()
    return store.publish(grant['generation_id'],artifact)
