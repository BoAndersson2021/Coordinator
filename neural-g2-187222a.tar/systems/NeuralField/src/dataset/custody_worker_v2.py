"""Root-invoked v2 sentinel qualification inside unshare. No provisioning or real input release."""
import ctypes
import errno
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile


def run(argv):subprocess.run(argv,check=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,close_fds=True)


def worker(profile,role):
    if sys.platform!='linux' or os.geteuid()!=0:raise RuntimeError('Linux administrator namespace worker required')
    if profile.get('profile_version')!='p001-custody-launch.v2' or role not in ('training','inference'):raise RuntimeError('v2 profile/role')
    expected=11002 if role=='training' else 11003
    if profile['identities'][role]!={'uid':expected,'gid':expected}:raise RuntimeError('fixed consumer identity')
    # Already in new mount/PID namespaces. Propagation is private; changes cannot propagate to host.
    if os.getpid()!=1:raise RuntimeError('worker must be PID 1 in a new PID namespace')
    jail=Path(tempfile.mkdtemp(prefix='probe-',dir=profile['jail_parent']))
    run(['/usr/bin/mount','-t','tmpfs','-o','mode=0755,nosuid,nodev','tmpfs',str(jail)])
    for name in ('usr','lib','lib64','bin'):
        source=Path('/'+name)
        if source.exists():
            destination=jail/name;destination.mkdir()
            run(['/usr/bin/mount','--bind',str(source),str(destination)])
            run(['/usr/bin/mount','-o','remount,bind,ro,nosuid,nodev',str(destination)])
    for name in ('proc','data','runtime','tmp','etc'):(jail/name).mkdir()
    run(['/usr/bin/mount','-t','proc','-o','nosuid,nodev,noexec','proc',str(jail/'proc')])
    run(['/usr/bin/mount','-t','tmpfs','-o','mode=1777,nosuid,nodev,noexec','tmpfs',str(jail/'tmp')])
    for source,destination in ((profile['runtime'],jail/'runtime'),(profile[role+'_view'],jail/'data')):
        run(['/usr/bin/mount','--bind',source,str(destination)])
        run(['/usr/bin/mount','-o','remount,bind,ro,nosuid,nodev',str(destination)])
    # Probe configuration is nonsecret, copied before privilege drop; no private sentinel descriptor is inherited.
    config={'role':role,'uid':profile['identities'][role]['uid'],'gid':profile['identities'][role]['gid'],
            'private_paths':profile['private_paths']}
    os.chroot(jail);os.chdir('/')
    libc=ctypes.CDLL(None,use_errno=True)
    for cap in range(64):
        if libc.prctl(24,cap,0,0,0)!=0 and ctypes.get_errno()!=errno.EINVAL:raise OSError(ctypes.get_errno(),'drop capability bounding set')
    os.setgroups([]);os.setgid(config['gid']);os.setuid(config['uid'])
    if libc.prctl(38,1,0,0,0)!=0:raise OSError(ctypes.get_errno(),'no-new-privileges')
    os.closerange(3,os.sysconf('SC_OPEN_MAX'))
    os.execve('/usr/bin/python3',['/usr/bin/python3','-I','/runtime/consumer_probe_v2.py',json.dumps(config)],
              {'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'})


if __name__=='__main__':
    try:
        if sys.platform!='linux' or os.geteuid()!=0 or os.getpid()!=1:raise RuntimeError('preprovided namespace required')
        profile=json.loads(Path(sys.argv[1]).read_text());worker(profile,sys.argv[2])
    except Exception as error:
        print('custody worker rejected',file=sys.stderr);sys.exit(1)
