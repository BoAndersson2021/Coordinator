"""Production-format artifacts and bounded G2 synthetic fixtures; no learned outputs."""
from pathlib import Path
import importlib.metadata
import platform

from dataset.artifacts import provenance as source_provenance,jsonl,rows,schema_check
from dataset.codec import canonical,decode,digest
from dataset.complete_recipe import CompletePlan,SPLITS
from dataset.generation_authority import require_generation
from dataset.labeling import Labeler,VerificationFailure
from dataset.recipe import SYSTEM

FOLDERS={'training':'consumer/training','validation':'consumer/validation','final':'private'}
FILES=('consumer/training/queries.jsonl','consumer/training/labels.jsonl',
       'consumer/validation/queries.jsonl','consumer/validation/labels.jsonl',
       'private/final-inputs/queries.jsonl','private/final-labels/labels.jsonl',
       'private/audit.json','private/provenance.json')


def paths(split):
    if split=='final':return 'private/final-inputs/queries.jsonl','private/final-labels/labels.jsonl'
    return FOLDERS[split]+'/queries.jsonl',FOLDERS[split]+'/labels.jsonl'


def version(kind):
    if kind=='real':return 'p001-real-artifacts.v1'
    if kind=='g2-synthetic':return 'p001-g2-synthetic-artifacts.v1'
    raise VerificationFailure('artifact-kind',{})


def context(kind,source_revision,rng):
    grant=require_generation('audit') if kind=='real' else None
    version(kind)
    base=source_provenance(source_revision,rng)
    if grant is not None and source_revision!=grant['source_revision']:raise VerificationFailure('reviewed-source',{})
    root=SYSTEM.parents[1]
    lock_hashes={n:digest((root/n).read_bytes()) for n in ('requirements-reference.txt','requirements-dataset.txt')}
    dependencies={}
    for n in lock_hashes:
        for line in (root/n).read_text().splitlines():
            if not line.startswith('#') and '==' in line:
                name,wanted=line.split('==')
                actual=importlib.metadata.version(name)
                if actual!=wanted:raise VerificationFailure('dependency-version',{'dependency':name})
                dependencies[name]=actual
    return {'artifact_version':version(kind),'kind':kind,'source_revision':source_revision,
            'source_tree':grant['deployment']['source_tree'] if grant else None,
            'source_claim':'reviewed_protected_deployment' if grant else 'reduced_fixture_exact_hashes',
            'contract_hashes':base['contract_hashes'],'source_hashes':base['source_hashes'],
            'lock_hashes':lock_hashes,'dependencies':dependencies,'python':platform.python_version(),
            'platform':platform.platform(),'rng':rng,'recipe':'p001.v1' if grant else 'p001-g2-toy.v1',
            'authority_sha256':grant['grant_sha256'] if grant else None,
            'profile_sha256':grant['deployment']['profile_sha256'] if grant else None,
            'training':None,'inference':None,'benchmark':None}


def assemble(plan,source_revision,labeler):
    """Real plans always re-read external authority before constructing artifacts."""
    if plan.kind=='real':require_generation('generate')
    elif plan.kind!='g2-synthetic':raise VerificationFailure('artifact-kind',{})
    expected=CompletePlan(plan.kind,plan.recipe)
    audit=expected.audit(plan.splits)
    if plan.rng!=expected.rng:raise VerificationFailure('frozen-rng',{})
    labels={s:[labeler.verify(q) for q in qs] for s,qs in plan.splits.items()}
    from dataset.preflight import MAX_RECORD_BYTES
    for split in SPLITS:
        if any(len(canonical(row))>MAX_RECORD_BYTES for row in plan.splits[split]+labels[split]):raise VerificationFailure('record-size-bound',{})
    artifact={}
    for split in SPLITS:
        qpath,lpath=paths(split)
        artifact[qpath]=jsonl(plan.splits[split]);artifact[lpath]=jsonl(labels[split])
    artifact['private/audit.json']=canonical(audit)
    artifact['private/provenance.json']=canonical(context(plan.kind,source_revision,plan.rng))
    manifest={'artifact_version':version(plan.kind),'kind':plan.kind,'source_revision':source_revision,
              'files':{p:{'sha256':digest(raw),'bytes':len(raw)} for p,raw in artifact.items()},
              'counts':audit['counts'],'ordinary_domain_counts':audit['ordinary_domain_counts'],
              'suite_counts':audit['suite_counts']}
    schema_check('custody-manifest.schema.json',manifest)
    artifact['manifest.json']=canonical(manifest)
    return artifact


def verify(artifact,kind,recipe,labeler):
    if kind=='real':require_generation('audit')
    if set(artifact)!=set(FILES)|{'manifest.json'}:raise VerificationFailure('artifact-closure',{})
    manifest=decode(artifact['manifest.json']);schema_check('custody-manifest.schema.json',manifest)
    if manifest['kind']!=kind or manifest['artifact_version']!=version(kind):raise VerificationFailure('artifact-version-confusion',{})
    for name in FILES:
        if manifest['files'][name]!={'sha256':digest(artifact[name]),'bytes':len(artifact[name])}:raise VerificationFailure('artifact-hash',{'artifact':name})
    metadata=decode(artifact['private/provenance.json']);schema_check('custody-provenance.schema.json',metadata)
    plan=CompletePlan(kind,recipe)
    expected=context(kind,manifest['source_revision'],plan.rng)
    if metadata!=expected:raise VerificationFailure('frozen-provenance',{})
    from dataset.preflight import MAX_RECORD_BYTES
    for name in FILES:
        if name.endswith('.jsonl') and any(len(line)>MAX_RECORD_BYTES for line in artifact[name].splitlines(keepends=True)):raise VerificationFailure('record-size-bound',{})
    splits={}
    for split in SPLITS:
        qpath,lpath=paths(split);queries=rows(artifact[qpath]);labels=rows(artifact[lpath])
        if len(queries)!=len(labels):raise VerificationFailure('missing-labels',{'split':split})
        if kind=='g2-synthetic' and len(queries)>10:raise VerificationFailure('reduced-bound',{})
        for query,label in zip(queries,labels):labeler.verify(query,supplied=label)
        splits[split]=queries
    audit=plan.audit(splits)
    recorded=decode(artifact['private/audit.json'])
    schema_check('custody-audit.schema.json',recorded)
    if recorded!=audit or any(manifest[k]!=audit[k] for k in ('counts','ordinary_domain_counts','suite_counts')):
        raise VerificationFailure('independent-audit',{})
    return manifest


def reduced_bundle(source_revision,recipe=None,labeler=None):
    # There is no quota/geometry override or mode flag capable of selecting real data.
    return assemble(CompletePlan('g2-synthetic',recipe),source_revision,Labeler() if labeler is None else labeler)
