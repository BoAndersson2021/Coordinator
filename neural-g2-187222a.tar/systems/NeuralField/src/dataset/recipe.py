"""Frozen P001 recipe primitives. Gate 1 exports only reduced synthetic samples."""
from fractions import Fraction
from pathlib import Path
import copy
import itertools
import numpy as np

from common.contract import Contract
from dataset.authority import require_gate2
from dataset.codec import canonical, decode, digest, semantic

SYSTEM=Path(__file__).resolve().parents[2]
NUMPY_VERSION='1.26.4'
HASHES={
    'geometry.v1.json':'37759af786f658d89eef887add98ce47d95d0c450a877a70a0c3002addb68f1b',
    'preregistration.v1.json':'f2168acf7d80c6c38136417988e5c17608575bfe4c8b2909ae9956616dd72d96',
    'public-fixtures.v1.json':'13d81577166f11efc28bbe17d4ac3a8f710545627b6722c274042003871a25a7',
    'custody.v2.json':'76c62ead6ebeae6aa50945f20a3fea740f1377d5063ceeb6076632fa140e6e59',
    'integrity.v1.json':'5fb6029f14d9b7748da75dc808c69a99425db94566a13aaaf6fe50b42aacf951',
    'custody.v1.json':'1400e05a708419afc01c2efecc38f8844c49eca45a7eac9822aa8399f3dea3b1',
}


def contracts():
    values={}
    for name in HASHES:
        raw=(SYSTEM/'experiments/P001'/name).read_bytes()
        if name in HASHES and digest(raw)!=HASHES[name]:raise ValueError('frozen contract hash: '+name)
        values[name]=decode(raw)
    if values['custody.v2.json']['supersedes']['sha256'] != HASHES['custody.v1.json']:
        raise ValueError('custody parent binding')
    return values


def request(domain, position):
    if domain=='navigation':payload={'start_node':list(position),'destination_node':[55,29],'actor':{'half_extent_m':.25}}
    elif domain=='cover':payload={'candidate_m':[n/1_000_000 for n in position],'threat_m':[2,7.5],'actor':{'half_extent_m':.25}}
    elif domain=='shooting':payload={'target_m':[n/1_000_000 for n in position],'firing_m':[2,7.5],'firing_geometry':{'projectile_radius_m':0}}
    else:raise ValueError('domain')
    value={'schema_version':'p001.v1','snapshot_id':'p001-static-v1','domain':domain,'query_id':'synthetic','input':payload}
    value['query_id']='synthetic-'+digest(semantic(value))
    return value


class Recipe:
    def __init__(self):
        self.data=contracts();self.contract=Contract()
        self.prereg=self.data['preregistration.v1.json']
        registry=self.data['public-fixtures.v1.json']
        self.public=frozenset(semantic(dict(schema_version=registry['schema_version'],snapshot_id=registry['snapshot_id'],
                             query_id='registry',domain=f['domain'],input=f['input'])) for f in registry['fixtures'])
        ranked=sorted((digest(f'p001.v1:tiles:20261011:{x}:{y}'.encode()),x,y) for x in range(16) for y in range(16))
        self.tiles={(x,y):'training' if i<160 else 'validation' if i<192 else 'final' for i,(_,x,y) in enumerate(ranked)}

    def tile(self, position_um):
        if any(type(n) is not int or not 0<=n<=16_000_000 for n in position_um):raise ValueError('tile outside world')
        return self.tiles[tuple(min(15,n//1_000_000) for n in position_um)]

    def nav_class(self, node):
        if len(node)!=2 or any(type(n) is not int or not 0<=n<63 for n in node):raise ValueError('navigation domain')
        if semantic(request('navigation',node)) in self.public:return 'public'
        x,y=(n+1 for n in node)
        if any(max(a-x,0,x-b)**2+max(c-y,0,y-d)**2<=4 for a,b,c,d in ((28,32,28,32),(44,52,8,16))):return 'challenge'
        return self.tile(tuple((n+1)*250_000 for n in node))

    def nav_membership(self):
        return {node:self.nav_class(node) for node in itertools.product(range(63),repeat=2)}

    def sample_synthetic(self, domain, split, count, reserved=(), seen=(), reject_limit=None):
        if type(count) is not int or not 0<count<=16:raise ValueError('Gate 1 synthetic quota must be 1..16')
        return self._sample(domain,split,count,reserved,seen,reject_limit)

    def _sample(self, domain, split, count, reserved=(), seen=(), reject_limit=None):
        """Internal frozen sampler; public Gate 1 API bounds the synthetic quota."""
        if type(count) is int and count>16:
            from dataset.generation_authority import require_generation
            require_generation('audit')
        if np.__version__!=NUMPY_VERSION:raise ValueError('NumPy version differs from frozen generator dependency')
        if domain not in ('cover','shooting') or split not in ('training','validation','final'):raise ValueError('sample domain/split')
        if type(count) is not int or count<=0:raise ValueError('quota')
        index=('training','validation','final').index(split)
        seed=self.prereg['datasets'][domain]['seeds'][index]
        rng=np.random.Generator(np.random.PCG64(seed))
        before=copy.deepcopy(rng.bit_generator.state)
        forbidden=set(self.public)|set(seen)|(set(reserved) if split!='final' else set())
        rows=[];rejected=0;limit=self.prereg['datasets']['max_rejected_draws'] if reject_limit is None else reject_limit
        if type(limit) is not int or limit<0:raise ValueError('rejection limit')
        while len(rows)<count:
            # Explicit x then y calls, including both world endpoints.
            point=(int(rng.integers(0,16_000_001)),int(rng.integers(0,16_000_001)))
            row=request(domain,point);key=semantic(row)
            if self.tile(point)!=split or key in forbidden or self.contract.validate(row).error is not None:
                rejected+=1
                if rejected>=limit:raise ValueError('synthetic generator rejection budget exhausted')
                continue
            forbidden.add(key);rows.append(row)
        return rows,{'kind':'synthetic','numpy_version':np.__version__,'seed':seed,'state_before':before,
                     'state_after':copy.deepcopy(rng.bit_generator.state),'rejected':rejected,'count':count}

    def generate_production(self, **kwargs):
        from dataset.generation_authority import require_generation
        grant=require_generation('generate',**kwargs)
        from dataset.real_store import ProductionStore
        store=ProductionStore()
        store.claim_generation()
        from dataset.complete_recipe import CompletePlan
        plan=CompletePlan('real',self)
        return plan


OFFSETS=(-10_000,-1_000,-1,0,1,1_000,10_000)


def challenge_points(obstacles, *, expanded=False, extended=False):
    """Recipe construction usable with synthetic rectangles; integer/rational rounding."""
    points=set()
    for box in obstacles:
        x0,y0,x1,y1=box
        h=250_000 if expanded else 0;x0-=h;y0-=h;x1+=h;y1+=h
        corners=((x0,y0),(x1,y0),(x1,y1),(x0,y1))
        features=corners+((x0,Fraction(y0+y1,2)),(x1,Fraction(y0+y1,2)),
                         (Fraction(x0+x1,2),y0),(Fraction(x0+x1,2),y1))
        if extended:
            features+=tuple((Fraction(2_000_000)+factor*(x-2_000_000),Fraction(7_500_000)+factor*(y-7_500_000))
                            for x,y in corners for factor in (Fraction(3,2),Fraction(2)))
        for x,y in features:
            points.update((round(x+dx),round(y+dy)) for dx,dy in itertools.product(OFFSETS,repeat=2))
    if extended:
        points.update((x,y+d) for x,y in ((14_000_000,7_000_000),(14_000_000,8_000_000),
                                         (7_000_000,7_000_000),(8_000_000,8_000_000)) for d in OFFSETS)
    return tuple(sorted(points))


def status_points():
    features=((0,0),(16_000_000,0),(16_000_000,16_000_000),(0,16_000_000),
              (0,8_000_000),(16_000_000,8_000_000),(8_000_000,0),(8_000_000,16_000_000))
    return tuple(sorted({(x+dx,y+dy) for x,y in features for dx,dy in itertools.product(OFFSETS,repeat=2)}))


def challenge_requests(recipe, domain, obstacles):
    if domain not in ('cover','shooting'):raise ValueError('challenge domain')
    points=challenge_points(obstacles,expanded=domain=='cover',extended=domain=='shooting')
    result=[]
    for point in points:
        row=request(domain,point)
        if semantic(row) not in recipe.public and recipe.contract.validate(row).error is None:result.append(row)
    return tuple(result)


def status_requests(recipe,domain):
    if domain not in ('cover','shooting'):raise ValueError('status domain')
    return tuple(q for q in (request(domain,p) for p in status_points()) if semantic(q) not in recipe.public)
