"""External Linux operator authority. No caller object, flag or receipt grants execution."""
import importlib.metadata
import os
from pathlib import Path
import platform
import stat
import sys
from jsonschema.exceptions import ValidationError

from dataset.authority import AuthorityClosed
from dataset.codec import canonical,decode,digest
from dataset.artifacts import schema_check,provenance
from dataset.recipe import contracts,SYSTEM

ANCHOR=Path('/etc/neuralfield/P001/generation-authority.v1.json')
ROOT=Path('/var/lib/neuralfield/P001')
OPERATIONS=('generate','publish','audit','recover','admit','invalidate')


def reject():
    raise AuthorityClosed('Gate 2 is closed: reviewed external deployment and one-generation grant required')


def protected_record(path):
    """Read only a root-owned, custodian-readable record through non-aliased ancestors."""
    path=Path(path)
    if not path.is_absolute() or '..' in path.parts or str(path)!=str(path.resolve()):reject()
    for item in list(reversed(path.parents)):
        info=item.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid!=0 or info.st_mode&0o022:reject()
        if any('acl' in name.lower() for name in os.listxattr(item)):reject()
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        info=os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=0 or info.st_gid!=11001 or info.st_nlink!=1 or stat.S_IMODE(info.st_mode)!=0o640:reject()
        if any('acl' in name.lower() for name in os.listxattr(path)):reject()
        with os.fdopen(fd,'rb',closefd=False) as stream:raw=stream.read(1_000_001)
        if len(raw)>1_000_000:reject()
        return decode(raw),digest(raw)
    finally:os.close(fd)


def validate_records(grant, deployment, qualification):
    """Pure structural/binding checks. This function does NOT confer execution authority."""
    for name,record in (('generation-grant',grant),('deployment',deployment),('deployment-qualification',qualification)):
        schema_check(name+'.schema.json',record)
    if grant['deployment_sha256']!=digest(canonical(deployment)) or grant['qualification_sha256']!=digest(canonical(qualification)):reject()
    for key in ('source_revision','source_tree','store_id','source_hashes','contract_hashes','lock_hashes','profile_sha256','filesystem','host','kernel','interpreter','environment_prefix','interpreter_sha256','dependencies'):
        if deployment[key]!=qualification[key]:reject()
    if grant['source_revision']!=deployment['source_revision'] or grant['root']!=str(ROOT):reject()
    if qualification['kind']!='actual_deployed_custody' or qualification['production_source_reviewed'] is not True:reject()
    return grant


def host_observation(root=ROOT):
    """Current facts, not a synthetic namespace qualification."""
    if sys.platform!='linux' or (os.geteuid(),os.getegid())!=(11001,11001):reject()
    # Custodian may hold the nonprivileged training group to assign 0640/0750.
    # Consumers must still have empty supplementary groups under their launcher.
    if set(os.getgroups())-set((11001,11002)) or 11002 not in os.getgroups():reject()
    status={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in Path('/proc/self/status').read_text().splitlines() if ':' in line}
    if int(status['CapEff'],16) or int(status['CapBnd'],16) or status['NoNewPrivs']!='1':reject()
    resolved=Path(root)
    if not resolved.exists() or resolved.is_symlink():reject()
    mounts=[]
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        left,right=line.split(' - ',1);fields=left.split();tail=right.split()
        mount=fields[4]
        if '\\' in mount:continue  # No escaped/ambiguous deployment paths.
        p=Path(mount)
        if resolved==p or p in resolved.parents:mounts.append((len(p.parts),fields,tail))
    if not mounts:reject()
    _,fields,tail=max(mounts,key=lambda item:item[0])
    if tail[0]!='ext4' or tail[1]!='/dev/vda1':reject()
    filesystem={'source':tail[1],'fstype':tail[0],'mount':fields[4],'device':resolved.stat().st_dev}
    return {'filesystem':filesystem,'host':platform.node(),'kernel':platform.release(),
            'interpreter':str(Path(sys.executable).absolute()),'environment_prefix':str(Path(sys.prefix).resolve()),
            'interpreter_sha256':digest(Path(sys.executable).read_bytes())}


def require_generation(operation, generation=None, *, authorization=None, qualification=None):
    """All real entrypoints re-read the fixed protected authority before output access.

    G2-1 never creates this record. Its creation needs separately authorized reviewed
    deployment and G2-3 execution; supplied objects/paths are not alternate trust roots.
    """
    try:
        if authorization is not None or qualification is not None or operation not in OPERATIONS:reject()
        if sys.platform!='linux' or (os.geteuid(),os.getegid())!=(11001,11001):reject()
        grant,grant_hash=protected_record(ANCHOR)
        schema_check('generation-grant.schema.json',grant)
        if set(grant.get('operations',()))!=set(OPERATIONS):reject()
        deployment,_=protected_record(Path(grant['deployment_record']))
        qualified,_=protected_record(Path(grant['qualification_record']))
        validate_records(grant,deployment,qualified)
        profile,profile_sha=protected_record(Path(deployment['profile_record']))
        from dataset.production_profile import validate_profile
        validate_profile(profile,check_host=True)
        if profile_sha!=deployment['profile_sha256']:reject()
        if generation is not None and generation!=grant['generation_id']:reject()
        observation=host_observation()
        if any(observation[k]!=deployment[k] for k in observation):reject()
        current=provenance(deployment['source_revision'],[])
        if current['source_hashes']!=deployment['source_hashes'] or current['contract_hashes']!=deployment['contract_hashes']:reject()
        contracts()  # Pinned accepted bytes, including immutable custody v1 parent.
        for lock,sha in deployment['lock_hashes'].items():
            if digest((SYSTEM.parents[1]/lock).read_bytes())!=sha:reject()
        expected_dependencies={}
        for lock in deployment['lock_hashes']:
            for line in (SYSTEM.parents[1]/lock).read_text().splitlines():
                if not line.startswith('#') and '==' in line:
                    name,version=line.split('==');expected_dependencies[name]=version
        if deployment['dependencies']!=expected_dependencies:reject()
        for name,version in expected_dependencies.items():
            if importlib.metadata.version(name)!=version:reject()
        # All deployed source/interpreter ancestors and files must be root controlled.
        for path in [Path(sys.executable).resolve()]+[SYSTEM.parents[1]/p for p in current['source_hashes']]:
            for item in [path]+list(path.parents):
                info=item.lstat()
                if info.st_uid!=0 or info.st_mode&0o022 or stat.S_ISLNK(info.st_mode):reject()
        return dict(grant,grant_sha256=grant_hash,deployment=deployment,qualified=qualified)
    except AuthorityClosed:raise
    except (OSError,ValueError,KeyError,TypeError,LookupError,ValidationError):reject()
