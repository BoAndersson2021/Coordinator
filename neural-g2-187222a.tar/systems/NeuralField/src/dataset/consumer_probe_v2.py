"""Sentinel-only consumer qualification; never reads real final inputs or labels."""
import json
import os
from pathlib import Path
import sys
import errno

def denied(path,write=False):
    try:
        with open(path,'r+b' if write else 'rb') as stream:stream.read(1)
    except OSError as error:
        if error.errno in (errno.EPERM,errno.EACCES,errno.EROFS,errno.ENOENT,errno.ENOTDIR,errno.EISDIR):return True
        raise
    return False


def probe(config):
    if config['role'] not in ('training','inference'):raise RuntimeError('probe role')
    private=config['private_paths']
    checks={path:denied(path) for path in private}
    for index,path in enumerate(private):
        alias=Path('/tmp')/('p001-v2-alias-'+str(index));alias.symlink_to(path)
        checks[str(alias)]=denied(alias)
    checks['private-host-proc']=not Path('/proc/2/root').exists()
    expected={'training':'training/sentinel.txt','validation':'validation/sentinel.txt'} if config['role']=='training' else {'approved':'sentinel.txt'}
    for name,relative in expected.items():
        path=Path('/data')/relative
        checks[name+'-read']=path.read_bytes()==b'synthetic-approved\n'
        checks[name+'-write-denied']=denied(path,write=True)
    if config['role']=='inference':
        checks['training-labels-denied']=denied('/data/training/labels.jsonl')
        checks['validation-labels-denied']=denied('/data/validation/labels.jsonl')
    fields=dict(line.split(':',1) for line in Path('/proc/self/status').read_text().splitlines() if ':' in line)
    cap=int(fields['CapEff'].strip(),16);bounding=int(fields['CapBnd'].strip(),16);nnp=int(fields['NoNewPrivs'].strip())
    fd_leak=any(int(p.name)>2 for p in Path('/proc/self/fd').iterdir() if p.name.isdigit() and p.exists())
    return {'kind':'synthetic_namespace_probe','role':config['role'],'uid':os.getuid(),'gid':os.getgid(),'groups':os.getgroups(),
            'cap_eff':cap,'cap_bnd':bounding,'no_new_privs':nnp,'fd_leak':fd_leak,'checks':checks,
            'mountinfo':Path('/proc/self/mountinfo').read_text(),
            'passed':all(checks.values()) and not fd_leak and cap==bounding==0 and nnp==1 and os.getgroups()==[]}


if __name__=='__main__':
    try:print(json.dumps(probe(json.loads(sys.argv[1])),sort_keys=True,separators=(',',':')))
    except Exception:sys.exit('consumer probe rejected')
