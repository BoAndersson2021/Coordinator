"""Complete recipe/audit kernel; real plans require external authority, tests remain 22 rows."""
from collections import Counter
from fractions import Fraction
import itertools

from dataset.codec import semantic
from dataset.recipe import Recipe,request,challenge_requests,status_requests
from dataset.audit import audit_splits,nav_assignment,independent_tiles
from dataset.labeling import VerificationFailure
from dataset.generation_authority import require_generation

SPLITS=('training','validation','final')
TOY=((6_000_000,6_000_000,6_500_000,6_500_000),)


def boundary_requests(recipe, domain, boxes):
    """Independent enumerator: explicit finite-edge midpoints and rational ray extension."""
    keys=set();offsets=(-10_000,-1_000,-1,0,1,1_000,10_000)
    for raw in boxes:
        left,bottom,right,top=map(Fraction,raw)
        if domain=='cover':left-=250_000;bottom-=250_000;right+=250_000;top+=250_000
        corners=[(left,bottom),(right,bottom),(right,top),(left,top)]
        features=corners+[(left,(bottom+top)/2),(right,(bottom+top)/2),((left+right)/2,bottom),((left+right)/2,top)]
        if domain=='shooting':
            for factor in (Fraction(3,2),Fraction(2)):
                features.extend((2_000_000+factor*(x-2_000_000),7_500_000+factor*(y-7_500_000)) for x,y in corners)
        for x,y in features:
            for dx in offsets:
                for dy in offsets:keys.add((round(x+dx),round(y+dy)))
    if domain=='shooting':
        for x,y in ((14_000_000,7_000_000),(14_000_000,8_000_000),(7_000_000,7_000_000),(8_000_000,8_000_000)):
            for delta in offsets:keys.add((x,y+delta))
    rows=[]
    for point in sorted(keys):
        row=request(domain,point)
        if semantic(row) not in recipe.public and recipe.contract.validate(row).error is None:rows.append(row)
    return tuple(rows)


def independent_status(recipe,domain):
    offsets=(-10_000,-1_000,-1,0,1,1_000,10_000)
    points=set()
    for x,y in ((0,0),(16_000_000,0),(16_000_000,16_000_000),(0,16_000_000),(0,8_000_000),(16_000_000,8_000_000),(8_000_000,0),(8_000_000,16_000_000)):
        for dx in offsets:
            for dy in offsets:points.add((x+dx,y+dy))
    return tuple(row for row in (request(domain,p) for p in sorted(points)) if semantic(row) not in recipe.public)


class CompletePlan:
    """A closed scope, not user-selectable quotas or obstacle overrides."""
    def __init__(self, kind, recipe=None):
        if kind=='real':require_generation('audit')
        elif kind!='g2-synthetic':raise ValueError('dataset kind')
        self.kind=kind;self.recipe=Recipe() if recipe is None else recipe
        # Prevent altered in-memory recipes becoming the scientific authority.
        trusted=Recipe()
        if self.recipe.data!=trusted.data or self.recipe.tiles!=trusted.tiles or self.recipe.public!=trusted.public or self.recipe.prereg!=trusted.prereg:raise VerificationFailure('recipe-context',{})
        self.recipe=trusted
        self.ordinary={s:[] for s in SPLITS};self.rng=[]
        boxes=TOY if kind=='g2-synthetic' else tuple(tuple(round(v*1_000_000) for v in o['min']+o['max']) for o in self.recipe.data['geometry.v1.json']['obstacles'])
        public_nodes={tuple(f['input']['start_node']) for f in self.recipe.data['public-fixtures.v1.json']['fixtures'] if f['domain']=='navigation'}
        nav=self.recipe.nav_membership()
        if any(assigned!=nav_assignment(node,public_nodes) for node,assigned in nav.items()):raise VerificationFailure('independent-navigation-membership',{})
        if kind=='g2-synthetic':
            self.challenges=[challenge_requests(self.recipe,d,boxes)[0] for d in ('cover','shooting')]
            self.challenges.append(request('navigation',next(n for n,a in nav.items() if a=='challenge')))
            self.status=[request('shooting',(16_000_001,8_000_000))]
        else:
            self.challenges=[];self.status=[]
            for domain in ('cover','shooting'):
                generated=challenge_requests(self.recipe,domain,boxes);independent=boundary_requests(self.recipe,domain,boxes)
                if list(map(semantic,generated))!=list(map(semantic,independent)):raise VerificationFailure('independent-challenge-recipe',{})
                self.challenges.extend(generated)
                generated_status=status_requests(self.recipe,domain)
                if list(map(semantic,generated_status))!=list(map(semantic,independent_status(self.recipe,domain))):raise VerificationFailure('independent-status-recipe',{})
                self.status.extend(generated_status)
            self.challenges.extend(request('navigation',n) for n,a in nav.items() if a=='challenge')
        self.challenge_keys={semantic(q) for q in self.challenges};self.status_keys={semantic(q) for q in self.status}
        self.reserved=self.challenge_keys|self.status_keys
        for index,split in enumerate(SPLITS):
            for domain in ('cover','shooting'):
                count=2 if kind=='g2-synthetic' else self.recipe.prereg['datasets'][domain]['counts'][index]
                queries,state=self.recipe._sample(domain,split,count,reserved=self.reserved)
                # Generator state is labeled according to this explicitly selected scope.
                state=dict(state,kind=kind,domain=domain,split=split)
                self.rng.append(state);self.ordinary[split].extend(queries)
            nodes=[n for n,a in nav.items() if a==split]
            if kind=='g2-synthetic':nodes=nodes[:2]
            self.ordinary[split].extend(request('navigation',n) for n in nodes)
        self.splits={s:list(rows) for s,rows in self.ordinary.items()}
        seen={semantic(q) for q in self.splits['final']}
        for q in self.challenges+self.status:
            if semantic(q) not in seen:self.splits['final'].append(q);seen.add(semantic(q))
        if kind=='g2-synthetic' and tuple(map(len,self.splits.values()))!=(6,6,10):raise VerificationFailure('reduced-bound',{})
        self.expected_domains={s:dict(Counter(q['domain'] for q in rows)) for s,rows in self.splits.items()}

    def audit(self,splits):
        if self.kind=='real':require_generation('audit')
        # Every ordinary/suite row and its deterministic identity/order are replayed;
        # the independent spatial audit additionally verifies the full classification.
        for split in SPLITS:
            if splits[split]!=self.splits[split]:raise VerificationFailure('frozen-query-replay',{'split':split})
        audit=audit_splits(splits,self.recipe,reserved=self.reserved,expected_counts=self.expected_domains,
                          challenge_keys=self.challenge_keys,status_keys=self.status_keys)
        ordinary_counts={s:dict(Counter(q['domain'] for q in qs)) for s,qs in self.ordinary.items()}
        ordinary_final={semantic(q) for q in self.ordinary['final']}
        audit.update(ordinary_domain_counts=ordinary_counts,
                     suite_counts={'challenge':len(self.challenge_keys),'status':len(self.status_keys),
                                   'challenge_status_overlap':len(self.challenge_keys&self.status_keys),
                                   'ordinary_reserved_overlap':len(ordinary_final&self.reserved),'reserved_union':len(self.reserved)},
                     recipe_kind=self.kind)
        if self.kind=='real':
            for split,expected in (('training',2336),('validation',476),('final',928)):
                if ordinary_counts[split]['navigation']!=expected:raise VerificationFailure('navigation-coverage',{})
            strata=audit['strata']
            for domain in ('cover','shooting'):
                for name in ('boundary','near_boundary','interior'):
                    if strata.get('final:'+domain+':'+name,0)==0:raise VerificationFailure('missing-required-stratum',{'domain':domain,'stratum':name})
            for name in ('passage','pocket'):
                if strata.get('final:navigation:'+name,0)==0:raise VerificationFailure('missing-navigation-stratum',{'stratum':name})
        return audit
