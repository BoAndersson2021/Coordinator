"""Only custody-allowlisted fields may leave the custodian pipeline."""
from dataset.codec import canonical,digest


def public_receipt(receipt):
    keys=('generation_id','contract_versions','source_revision','counts','verification_pass','custody_pass')
    return dict({k:receipt[k] for k in keys},artifact_hashes={'manifest':receipt['manifest_sha256']},receipt_hash=digest(canonical(receipt)))
