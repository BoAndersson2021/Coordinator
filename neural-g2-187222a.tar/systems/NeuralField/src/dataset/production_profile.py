"""Production profile contract and preprovided-host checks. Never provisions or launches."""
from itertools import combinations
from pathlib import Path
import os
import stat

from dataset.artifacts import schema_check
from dataset.codec import digest
from dataset.generation_authority import ROOT,reject


def launcher_hash(directory=None):
    root=Path(__file__).parent if directory is None else Path(directory)
    return digest(b''.join((name+'\n').encode()+ (root/name).read_bytes() for name in ('custody_worker_v2.py','consumer_probe_v2.py')))


def validate_profile(profile,*,check_host=False):
    from jsonschema.exceptions import ValidationError
    try:schema_check('production-launch-profile.schema.json',profile)
    except ValidationError:reject()
    mandatory={str(ROOT/n) for n in ('.trust','.staging','quarantine','diagnostics')}
    if not mandatory<=set(profile['private_paths']):reject()
    roots=[profile[k] for k in ('runtime','jail_parent','training_view','inference_view')]+profile['private_paths']
    for value in roots:
        path=Path(value)
        if str(path)!=value or not path.is_absolute() or '..' in path.parts:reject()
    for left,right in combinations(map(Path,roots),2):
        if left.is_relative_to(right) or right.is_relative_to(left):reject()
    # A view must never include the complete store, catalog or final records.
    for key in ('training_view','inference_view'):
        view=Path(profile[key])
        if view.is_relative_to(ROOT/'generations'):
            relative=view.relative_to(ROOT/'generations').parts
            if key=='inference_view' or len(relative)!=2 or relative[1]!='consumer':reject()
        if view==ROOT or view in ROOT.parents or view.is_relative_to(ROOT/'.trust') or view.is_relative_to(ROOT/'.staging') or view.is_relative_to(ROOT/'quarantine') or view.is_relative_to(ROOT/'diagnostics') or 'private' in view.parts:reject()
    if profile['code_hash']!=launcher_hash():reject()
    if check_host:
        for value in roots:
            path=Path(value);info=path.lstat()
            if path.is_symlink() or info.st_mode&0o022:reject()
        for key in ('runtime','jail_parent'):
            root=Path(profile[key])
            for path in [root]+list(root.rglob('*')):
                info=path.lstat()
                if info.st_uid!=0 or info.st_mode&0o022 or path.is_symlink():reject()
        for key in ('training_view','inference_view'):
            root=Path(profile[key])
            for path in [root]+list(root.rglob('*')):
                info=path.lstat()
                if info.st_uid!=11001 or info.st_mode&0o022 or path.is_symlink() or (path.is_file() and info.st_nlink!=1):reject()
        for value in profile['private_paths']:
            path=Path(value);info=path.lstat()
            if info.st_uid!=11001 or info.st_mode&0o077:reject()
        if launcher_hash(Path(profile['runtime']))!=profile['code_hash']:reject()
    return profile
