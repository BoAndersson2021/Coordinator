"""Private synthetic authority catalog; never reconstructed from candidate artifacts."""
from pathlib import Path
from dataset.codec import canonical, decode, digest
from dataset.artifacts import schema_check


class TrustFailure(RuntimeError):
    """Public errors carry only a category. Detailed bytes remain in the private store."""


class Catalog:
    """Immutable records plus an atomically replaced inventory, under the store lock.

    An interrupted record/inventory transaction deliberately closes admission. Restoring
    trusted provenance requires owner disposition; recovery never imports orphan records.
    """
    VERSION='p001-synthetic-catalog.v1'
    CATALOG_SCHEMA='catalog.schema.json'
    REGISTRATION_SCHEMA='registration.schema.json'
    LOSS_SCHEMA='loss.schema.json'
    LOSS_VERSION='p001-synthetic-loss.v1'
    CATEGORIES=('registrations','losses')
    CLAIM_SCHEMA=None

    def __init__(self, store):
        self.store=store;self.root=store.root/'.trust'

    def _schema(self,category):
        if category=='registrations':return self.REGISTRATION_SCHEMA
        if category=='losses':return self.LOSS_SCHEMA
        if category=='claims' and self.CLAIM_SCHEMA is not None:return self.CLAIM_SCHEMA
        raise TrustFailure('unknown authority record category')

    def initialize(self):
        self.store._catalog_access('publish')
        self.root.mkdir(mode=0o700)
        for name in self.CATEGORIES:(self.root/name).mkdir(mode=0o700)
        self.store._write(self.root/'index.json',canonical(dict({'catalog_version':self.VERSION},**{name:{} for name in self.CATEGORIES})))
        for name in self.CATEGORIES:self.store.ops.sync_dir(self.root/name)
        self.store.ops.sync_dir(self.root)

    def load(self):
        self.store._catalog_access('audit')
        index=decode((self.root/'index.json').read_bytes())
        schema_check(self.CATALOG_SCHEMA,index)
        if set(p.name for p in self.root.iterdir())!=set(self.CATEGORIES)|{'index.json'}:
            raise TrustFailure('ambiguous trusted inventory')
        result={}
        for category in self.CATEGORIES:
            expected=index[category]
            if set(p.name for p in (self.root/category).iterdir())!={n+'.json' for n in expected}:
                raise TrustFailure('missing or uncommitted trust record')
            result[category]={}
            for identity,sha in expected.items():
                self.store.identity(identity)
                raw=(self.root/category/(identity+'.json')).read_bytes()
                if digest(raw)!=sha:raise TrustFailure('trusted record mismatch')
                record=decode(raw);schema_check(self._schema(category),record)
                if record['kind']!=self.store.KIND or (category=='registrations' and record['provenance']['kind']!=self.store.KIND):raise TrustFailure('trusted record kind mismatch')
                if record['generation_id']!=identity:raise TrustFailure('trusted identity mismatch')
                result[category][identity]=record
        for identity,loss in result['losses'].items():
            if identity not in index['registrations'] or loss['registration_sha256']!=index['registrations'][identity]:
                raise TrustFailure('invalidation binding mismatch')
            registered=result['registrations'][identity]
            if loss['expected_manifest_sha256']!=registered['manifest_sha256'] or loss['expected_completion_sha256']!=registered['completion_sha256'] or loss['counts']!=registered['counts']:
                raise TrustFailure('invalidation expectation mismatch')
        for identity,record in result['registrations'].items():
            replacement=record['replacement']
            if replacement is not None:
                old=replacement['retired_generation_id']
                if old==identity or old not in index['losses'] or replacement['loss_sha256']!=index['losses'][old]:
                    raise TrustFailure('replacement lineage mismatch')
                old_record=result['registrations'][old]
                self.store._check_replacement(record,old_record)
        return index,result

    def add(self, category, identity, record):
        self.store._catalog_access('publish')
        index,_=self.load()
        if identity in index[category]:raise TrustFailure('trust identity already reserved')
        if record['kind']!=self.store.KIND or (category=='registrations' and record['provenance']['kind']!=self.store.KIND):raise TrustFailure('trust record kind mismatch')
        raw=canonical(record)
        schema_check(self._schema(category),record)
        directory=self.root/category
        # Temporary records are visible only to the custodian; any interruption is
        # recognized as ambiguous trust on restart, rather than importing its contents.
        pending=directory/(identity+'.pending')
        self.store._write(pending,raw);self.store.ops.sync_dir(directory)
        self.store.ops.rename(pending,directory/(identity+'.json'))
        self.store.ops.sync_dir(directory)
        self.store.hook({'registrations':'AFTER_REGISTRATION_RECORD','losses':'AFTER_LOSS_RECORD','claims':'AFTER_CLAIM_RECORD'}[category])
        index[category][identity]=digest(raw)
        update=self.root/'index.pending'
        self.store._write(update,canonical(index));self.store.ops.sync_dir(self.root)
        self.store.ops.replace(update,self.root/'index.json');self.store.ops.sync_dir(self.root)
        self.store.hook({'registrations':'AFTER_REGISTRATION','losses':'AFTER_INVALIDATION','claims':'AFTER_CLAIM'}[category])
        return digest(raw)

    def retire(self, identity, reason):
        index,records=self.load()
        if identity not in records['registrations']:raise TrustFailure('unregistered identity cannot be retired')
        if identity in records['losses']:return records['losses'][identity]
        expected=records['registrations'][identity]
        record={'record_version':self.LOSS_VERSION,'kind':self.store.KIND,
                'generation_id':identity,'registration_sha256':index['registrations'][identity],
                'reason':reason,'expected_manifest_sha256':expected['manifest_sha256'],
                'expected_completion_sha256':expected['completion_sha256'],'counts':expected['counts']}
        self.store._bind_loss(record)
        self.add('losses',identity,record)
        return record
