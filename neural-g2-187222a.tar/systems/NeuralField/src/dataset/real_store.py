"""Custody-format lifecycle adapter; real operations require protected external authority."""
from contextlib import contextmanager
import os
from pathlib import Path
import re
import stat
import tempfile

from dataset.storage import SyntheticStore,NativeOps,AdmissionFailure,secure_tree
from dataset.trust import Catalog
from dataset.codec import canonical,decode,digest
from dataset.artifacts import schema_check
from dataset.custody_artifacts import FILES,verify,version,reduced_bundle
from dataset.generation_authority import ROOT,require_generation,reject
from dataset.recipe import Recipe
from dataset.labeling import Labeler


class CustodyCatalog(Catalog):
    VERSION='p001-custody-catalog.v1'
    CATALOG_SCHEMA='custody-catalog.schema.json'
    REGISTRATION_SCHEMA='custody-registration.schema.json'
    LOSS_SCHEMA='custody-loss.schema.json'
    LOSS_VERSION='p001-custody-loss.v1'
    CATEGORIES=('registrations','losses','claims')
    CLAIM_SCHEMA='custody-claim.schema.json'


class CustodyFormatStore(SyntheticStore):
    """Shared lifecycle methods retain catalog, independent checks and native commit law."""
    MARKER_NAME='.custody-store.json'
    TOP_DIRS=('.staging','generations','quarantine','diagnostics')
    ROOT_MODE=0o711
    GENERATIONS_MODE=0o711
    COMPLETION_SCHEMA='custody-completion.schema.json'
    REGISTRATION_VERSION='p001-custody-registration.v1'
    STATE='VERIFIED LOCAL'
    RETIRE_REASON='explicit_retirement'

    def _catalog_class(self):return CustodyCatalog
    def _artifact_files(self):return FILES
    def _artifact_directories(self):return {'consumer','consumer/training','consumer/validation','private','private/final-inputs','private/final-labels'}
    def _failure_schema(self):return 'custody-failure.schema.json'
    def _verify(self,artifact):return verify(artifact,self.KIND,self.recipe,self.labeler)

    def _secure(self,path):
        for item in [path]+list(path.rglob('*')):
            info=item.lstat();relative=item.relative_to(self.root);parts=relative.parts
            directory=stat.S_ISDIR(info.st_mode)
            if info.st_uid!=self.uid or info.st_dev!=self.device or stat.S_ISLNK(info.st_mode):raise AdmissionFailure('custody ownership/device/alias')
            if not directory and not stat.S_ISREG(info.st_mode):raise AdmissionFailure('custody special file')
            if not directory and info.st_nlink!=1:raise AdmissionFailure('custody hardlink')
            attrs=getattr(os,'listxattr',None)
            if attrs is None and self.KIND=='real':raise AdmissionFailure('ACL inspection unavailable')
            if attrs is not None and any('acl' in name.lower() for name in attrs(item)):raise AdmissionFailure('custody ACL')
            modes={0o700 if directory else 0o600};groups={self.private_gid}
            if not parts:modes={self.ROOT_MODE}
            elif parts==('generations',):modes={0o711}
            elif parts[0]=='generations' and len(parts)==2 and directory:modes={0o711}
            elif len(parts)>=3 and parts[0]=='generations' and parts[2]=='consumer':
                modes={0o750 if directory else 0o640};groups={self.training_gid}
            elif parts[0]=='.staging' and len(parts)==2 and directory:modes={0o700,0o711}
            elif len(parts)>=3 and parts[0]=='.staging' and parts[2]=='consumer':
                modes={0o700,0o750} if directory else {0o600,0o640};groups={self.private_gid,self.training_gid}
            if stat.S_IMODE(info.st_mode) not in modes or info.st_gid not in groups:raise AdmissionFailure('custody permission class')

    def _prepare_permissions(self,stage):
        self._secure(stage)
        consumer=stage/'consumer'
        for item in [consumer]+list(consumer.rglob('*')):
            os.chown(item,self.uid,self.training_gid,follow_symlinks=False)
            item.chmod(0o750 if item.is_dir() else 0o640)
            if item.is_file():self.ops.sync_file(item)
        stage.chmod(0o711)
        self._secure(stage)
        self.hook('AFTER_PERMISSION_PREPARATION')

    def _reprivate(self,stage):
        # Validate all aliases/objects before changing even one permission.
        self._secure(stage)
        for item in [stage]+list(stage.rglob('*')):
            os.chown(item,self.uid,self.private_gid,follow_symlinks=False)
            item.chmod(0o700 if item.is_dir() else 0o600)
            if item.is_file():self.ops.sync_file(item)

    def _completion(self,generation,artifact,manifest):
        metadata=decode(artifact['private/provenance.json'])
        return {'artifact_version':version(self.KIND),'kind':self.KIND,'generation_id':generation,
                'state':self.STATE,'manifest_sha256':digest(artifact['manifest.json']),'counts':manifest['counts'],
                'source_revision':manifest['source_revision'],'contract_versions':['p001-custody.v2','p001-integrity.v1'],
                'verification_pass':True,'custody_pass':self.KIND=='real','backend':self.ops.name,
                'authority_sha256':metadata['authority_sha256'],'profile_sha256':metadata['profile_sha256']}

    def _bind_loss(self,record):record['authority_sha256']=self._authority_hash()
    def _authority_hash(self):return None

    def _admit(self,generation,records):
        # Generic admission re-verifies every label, split, expected hash and file.
        receipt=super()._admit(generation,records)
        artifact=self._read(self.root/'generations'/generation)
        actual=digest(canonical({p:digest(artifact[p]) for p in FILES if p!='private/provenance.json'}))
        if records['registrations'][generation]['scientific_sha256']!=actual:raise AdmissionFailure('registered scientific digest')
        directory=self.root/'generations'/generation
        if stat.S_IMODE(directory.stat().st_mode)!=0o711:raise AdmissionFailure('generation traversal mode')
        return receipt

    def _bind_registration(self,record,artifact):
        record['scientific_sha256']=digest(canonical({p:digest(artifact[p]) for p in FILES if p!='private/provenance.json'}))

    def _check_replacement(self,record,old):
        frozen=('source_revision','source_tree','source_hashes','contract_hashes','lock_hashes','dependencies','python','rng','recipe')
        if record['scientific_sha256']!=old['scientific_sha256'] or record['counts']!=old['counts'] or any(record['provenance'][k]!=old['provenance'][k] for k in frozen):
            raise AdmissionFailure('replacement scientific/provenance mismatch')

    def regenerate(self,retired,fresh):reject()


class ReducedCustodyStore(CustodyFormatStore):
    """Exactly 22 toy rows, own temporary root and no consumer/production authority."""
    KIND='g2-synthetic'
    MARKER={'store_version':'p001-g2-test-store.v1','kind':'g2-synthetic','production_qualified':False}

    def __init__(self,root,recipe=None,labeler=None,*,ops=None,hook=None):
        path=Path(root)
        temps=(Path(tempfile.gettempdir()).resolve(),Path('/tmp').resolve())
        if '..' in path.parts or path.is_symlink() or not any(path.resolve().is_relative_to(p) and path.resolve()!=p for p in temps):raise AdmissionFailure('reduced store root')
        self.private_gid=os.getgid();self.training_gid=os.getgid();self.origin=path.resolve()
        self._initialize(path,Recipe() if recipe is None else recipe,Labeler() if labeler is None else labeler,ops=ops,hook=hook)

    def _scope(self):
        temps=(Path(tempfile.gettempdir()).resolve(),Path('/tmp').resolve())
        if self.KIND!='g2-synthetic' or self.root!=self.origin or not any(self.root.resolve().is_relative_to(p) and self.root.resolve()!=p for p in temps):raise AdmissionFailure('reduced scope mutation')

    @staticmethod
    def identity(generation):
        if type(generation) is not str or not re.fullmatch(r'g2-test-[a-zA-Z0-9-]{1,64}',generation):raise AdmissionFailure('reduced identity')

    def _lock(self,initial=False):
        self._scope()
        return super()._lock(initial)

    def _publish(self,*args,**kwargs):
        self._scope();return super()._publish(*args,**kwargs)

    def claim_generation(self,generation,source_revision):
        with self._lock():
            self.identity(generation);self._structure();_,records=self.catalog.load()
            if generation in records['claims']:raise AdmissionFailure('synthetic one-generation claim consumed')
            record={'record_version':'p001-custody-claim.v1','kind':'g2-synthetic','generation_id':generation,
                    'authority_sha256':None,'source_revision':source_revision}
            self.catalog.add('claims',generation,record);return record

    def regenerate(self,retired,fresh):
        with self._lock():
            self.identity(retired);self.identity(fresh);self._recover()
            index,records=self.catalog.load()
            if retired not in records['losses']:raise AdmissionFailure('registered loss required')
            context=records['registrations'][retired]['provenance']
            artifact=reduced_bundle(context['source_revision'],self.recipe,self.labeler)
            return self._publish(fresh,artifact,{'retired_generation_id':retired,'loss_sha256':index['losses'][retired]})


class ProductionStore(CustodyFormatStore):
    """No caller-provided grant/root/profile/backend can bypass external authority."""
    KIND='real'
    MARKER={'store_version':'p001-real-store.v1','kind':'real','production_qualified':False}

    def __init__(self,*,authorization=None,qualification=None):
        grant=require_generation('audit',authorization=authorization,qualification=qualification)
        self.MARKER=dict(type(self).MARKER,store_id=grant['deployment']['store_id'])
        self.private_gid=11001;self.training_gid=11002
        self._initialize(ROOT,Recipe(),Labeler())

    @staticmethod
    def identity(generation):
        require_generation('audit',generation)
        if type(generation) is not str or not re.fullmatch(r'p001-[a-zA-Z0-9-]{1,64}',generation):reject()

    def _gate(self,operation,generation=None):
        grant=require_generation(operation,generation)
        if hasattr(self,'root') and self.root!=ROOT:reject()
        return grant

    def _initialize(self,*args,**kwargs):
        self._gate('audit')
        # G2-2 must preprovide the root; source execution cannot provision it.
        if not ROOT.is_dir() or ROOT.is_symlink():reject()
        info=ROOT.lstat()
        if info.st_uid!=11001 or info.st_gid!=11001 or stat.S_IMODE(info.st_mode)!=self.ROOT_MODE or any('acl' in name.lower() for name in os.listxattr(ROOT)):reject()
        # The external deployment must preprovide the unique store/catalog/lock.
        # Missing authority is not permission to bootstrap it from empty storage.
        if not (ROOT/self.MARKER_NAME).is_file() or not (ROOT/'.trust/index.json').is_file() or not (ROOT/'.lock').is_file():reject()
        return super()._initialize(*args,**kwargs)

    def _lock(self,initial=False):
        self._gate('audit');return super()._lock(initial)
    def _structure(self):
        grant=self._gate('audit');super()._structure()
        index,records=self.catalog.load();claims=records['claims']
        if grant['replacement'] is None:
            if any(identity!=grant['generation_id'] for identity in records['registrations']):raise AdmissionFailure('ungranted history')
        else:self._replacement(grant,index,records)
        for identity,value in claims.items():
            if identity in records['registrations']:
                metadata=records['registrations'][identity]['provenance']
                expected={'record_version':'p001-custody-claim.v1','kind':'real','generation_id':identity,'authority_sha256':metadata['authority_sha256'],'source_revision':metadata['source_revision']}
            elif identity==grant['generation_id']:
                expected={'record_version':'p001-custody-claim.v1','kind':'real','generation_id':identity,'authority_sha256':grant['grant_sha256'],'source_revision':grant['source_revision']}
            else:raise AdmissionFailure('unregistered old execution claim')
            if value!=expected:raise AdmissionFailure('execution claim binding')
        if not set(records['registrations'])<=set(claims):raise AdmissionFailure('missing trusted execution claim')
        for name in ('.staging','generations','quarantine'):
            if any(p.name not in claims for p in (self.root/name).iterdir()):raise AdmissionFailure('unclaimed production object')
    def _read(self,directory):self._gate('audit');return super()._read(directory)
    def _write(self,path,raw):
        self._gate('publish')
        if '..' in Path(path).parts or not Path(path).is_relative_to(ROOT):reject()
        return super()._write(path,raw)
    def _prepare_permissions(self,stage):self._gate('publish');return super()._prepare_permissions(stage)
    def _reprivate(self,stage):self._gate('recover');return super()._reprivate(stage)
    def _completion(self,*args):self._gate('publish');return super()._completion(*args)
    def event(self,stage,state):self._gate('publish');return super().event(stage,state)
    def quarantine(self,stage,reason):self._gate('recover');return super().quarantine(stage,reason)
    def _diagnostic(self,error):self._gate('audit');return super()._diagnostic(error)
    def _recover(self):self._gate('recover');return super()._recover()
    def recover(self):self._gate('recover');return super().recover()
    def admit(self,generation):self._gate('admit',generation);return super().admit(generation)
    def _admit(self,generation,records):self._gate('admit',generation);return super()._admit(generation,records)
    def invalidate(self,generation):self._gate('invalidate',generation);return super().invalidate(generation)
    def _authority_hash(self):return self._gate('audit')['grant_sha256']

    def _replacement(self,grant,index,records):
        link=grant['replacement']
        if link is None:
            if records['registrations'] or records['losses']:raise AdmissionFailure('fresh store grant cannot overwrite history')
            return None
        old=link['retired_generation_id']
        if old==grant['generation_id'] or old not in records['losses'] or index['losses'][old]!=link['loss_sha256'] or index['registrations'][old]!=link['registration_sha256']:
            raise AdmissionFailure('owner replacement grant binding')
        if any(identity!=grant['generation_id'] and identity not in records['losses'] for identity in records['registrations']):raise AdmissionFailure('unretired generation conflict')
        return {'retired_generation_id':old,'loss_sha256':link['loss_sha256']}

    def claim_generation(self):
        grant=self._gate('generate')
        from dataset.preflight import production_preflight
        production_preflight()
        with self._lock():
            self._structure();index,records=self.catalog.load()
            self._replacement(grant,index,records)
            if grant['generation_id'] in records['claims'] or any((self.root/n/grant['generation_id']).exists() for n in ('generations','.staging','quarantine')) or grant['generation_id'] in index['registrations']:
                raise AdmissionFailure('one-generation grant consumed')
            claim={'record_version':'p001-custody-claim.v1','kind':'real','generation_id':grant['generation_id'],'authority_sha256':grant['grant_sha256'],'source_revision':grant['source_revision']}
            self.catalog.add('claims',grant['generation_id'],claim)
            return claim

    def _claim(self,generation):
        grant=self._gate('publish',generation)
        _,records=self.catalog.load()
        expected={'record_version':'p001-custody-claim.v1','kind':'real','generation_id':generation,'authority_sha256':grant['grant_sha256'],'source_revision':grant['source_revision']}
        if records['claims'].get(generation)!=expected:raise AdmissionFailure('trusted execution claim required')

    def _publish(self,generation,artifact,replacement=None):
        grant=self._gate('publish',generation);self._claim(generation)
        index,records=self.catalog.load()
        expected=self._replacement(grant,index,records)
        if replacement is not None and replacement!=expected:reject()
        return super()._publish(generation,artifact,expected)

    def publish(self,generation,artifact):
        self._gate('publish',generation);return super().publish(generation,artifact)

    def regenerate(self,retired,fresh):
        grant=self._gate('generate',fresh)
        if grant['replacement'] is None or grant['replacement']['retired_generation_id']!=retired:reject()
        from dataset.pipeline import production_bundle
        artifact=production_bundle()
        self.recover();return self.publish(fresh,artifact)
