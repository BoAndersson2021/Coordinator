"""Read-only capacity bounds; not dataset generation or an experimental benchmark."""
import os
from pathlib import Path
from dataset.recipe import contracts
from dataset.generation_authority import ROOT,require_generation
from dataset.storage import AdmissionFailure

MAX_RECORD_BYTES=4096


def upper_row_bound():
    data=contracts();p=data['preregistration.v1.json'];g=data['geometry.v1.json']
    ordinary=sum(sum(p['datasets'][domain]['counts']) for domain in ('cover','shooting'))+3969-4
    # Duplicate/public/domain filtering can only decrease these feature/offset bounds.
    cover=len(g['obstacles'])*8*49
    shooting=len(g['obstacles'])*16*49+4*7
    statuses=2*8*49
    return ordinary+cover+shooting+statuses


def required_bytes(rows):
    # Two 4 KiB records per query, one complete staging generation plus equal
    # verification/failure reserve and 8 MiB for manifests/catalog/diagnostics.
    return rows*2*MAX_RECORD_BYTES*2+8*1024*1024


def check_capacity(free_bytes,free_inodes,rows):
    if type(free_bytes) is not int or type(free_inodes) is not int or free_bytes<required_bytes(rows) or free_inodes<128:
        raise AdmissionFailure('insufficient generation capacity')


def production_preflight():
    require_generation('generate')
    info=os.statvfs(ROOT);free=info.f_bavail*info.f_frsize
    bound=upper_row_bound();check_capacity(free,info.f_favail,bound)
    memory={}
    for line in Path('/proc/meminfo').read_text().splitlines():
        if line.split(':',1)[0] in ('MemAvailable','MemTotal'):memory[line.split(':',1)[0]]=int(line.split()[1])*1024
    return {'row_upper_bound':bound,'required_free_bytes':required_bytes(bound),'free_bytes':free,
            'free_inodes':info.f_favail,'memory_observation_bytes':memory,'power_loss_claim':False}
