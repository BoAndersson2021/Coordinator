"""G2-1: production-format source tests using only fixed reduced synthetic artifacts."""
import copy
import multiprocessing
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SRC=Path(__file__).resolve().parents[1]/'src'
sys.path.insert(0,str(SRC))
from dataset.codec import canonical,decode,digest
from dataset.recipe import Recipe,request
from dataset.labeling import Labeler,VerificationFailure
from dataset.artifacts import provenance,rows,jsonl,schema_check
from dataset.complete_recipe import CompletePlan,boundary_requests,independent_status,TOY
from dataset.custody_artifacts import reduced_bundle,verify,FILES,context
from dataset.real_store import ProductionStore,ReducedCustodyStore
from dataset.generation_authority import require_generation,validate_records,protected_record,ROOT,OPERATIONS
from dataset.authority import AuthorityClosed,require_gate2
from dataset.storage import AdmissionFailure,NativeOps,production_publish
from dataset.pipeline import production_bundle
from dataset.production_profile import validate_profile,launcher_hash
from dataset.custody import production_launch
from dataset.public_receipt import public_receipt
from test_dataset import SimulatedOps

REVISION='cdfd03a2afaad5488485e78e6e694b5a1627ef00'
FAILURE_CHECKS=[]


def profile_fixture():
    return {'profile_version':'p001-custody-launch.v2','kind':'custody_profile','root':str(ROOT),
            'runtime':'/opt/neuralfield/P001-runtime','jail_parent':'/var/lib/neuralfield/P001-access/jails',
            'training_view':'/var/lib/neuralfield/P001-access/training','inference_view':'/var/lib/neuralfield/P001-access/inference',
            'private_paths':['/var/lib/neuralfield/P001-custody/final-inputs/sentinel','/var/lib/neuralfield/P001-custody/final-labels/sentinel']+[str(ROOT/n) for n in ('.trust','.staging','quarantine','diagnostics')],
            'code_hash':launcher_hash(),'identities':{r:{'uid':n,'gid':n} for r,n in (('custodian',11001),('training',11002),('inference',11003))},
            'consumer_read_only':True,'consumer_groups':[],'consumer_capabilities':[],
            'consumer_no_new_privs':True,'consumer_private_mount_pid':True,'final_input_release':False}


def grant_fixtures():
    """Schema fixtures, NOT external authority or execution evidence."""
    metadata=context('g2-synthetic',REVISION,[])
    binding={'source_revision':REVISION,'source_tree':'a'*40,'store_id':'2'*64,'source_hashes':metadata['source_hashes'],
             'contract_hashes':metadata['contract_hashes'],'lock_hashes':metadata['lock_hashes'],
             'profile_sha256':digest(canonical(profile_fixture())),
             'filesystem':{'source':'/dev/vda1','fstype':'ext4','mount':'/','device':1},
             'host':'SCHEMA-FIXTURE','kernel':'SCHEMA-FIXTURE','interpreter':'/opt/neuralfield/fixture/python',
             'environment_prefix':'/opt/neuralfield/fixture','interpreter_sha256':'1'*64,
             'dependencies':metadata['dependencies']}
    deployment=dict(binding,record_version='p001-deployment.v1',kind='reviewed_protected_deployment',profile_record='/etc/neuralfield/P001/launch-profile.v2.json')
    def consumer(uid):
        value={'uid':uid,'gid':uid,'groups':[],'cap_eff':0,'cap_bnd':0,'no_new_privs':1,
               'private_mount_namespace':True,'private_pid_namespace':True,'fd_leak':False}
        value.update({k:True for k in ('approved_read','approved_write_denied','final_inputs_denied','final_labels_denied','catalog_denied','staging_denied','quarantine_denied','diagnostics_denied')})
        if uid==11002:value.update(training_read=True,validation_read=True)
        if uid==11003:value.update(training_labels_denied=True,validation_labels_denied=True)
        return value
    qualification=dict(binding,record_version='p001-deployed-custody.v1',kind='actual_deployed_custody',production_source_reviewed=True,
                       custodian_uid=11001,custodian_gid=11001,custodian_private_reads=True,
                       training=consumer(11002),inference=consumer(11003),local_publication_verified=True,
                       process_recovery_verified=True,power_loss_survival='not_required_not_claimed',final_input_exposure=False)
    grant={'grant_version':'p001-one-generation-grant.v1','kind':'external_operator_grant',
           'owner_authorization':'SCHEMA-FIXTURE-NOT-AUTHORITY','deployment_authority':'SCHEMA-FIXTURE-NOT-AUTHORITY',
           'execution_stage':'G2-3','deployment_stage':'G2-2-reviewed','source_revision':REVISION,
           'root':str(ROOT),'generation_id':'p001-fixture','deployment_record':'/etc/neuralfield/P001/deployment.v1.json',
           'qualification_record':'/etc/neuralfield/P001/qualification.v1.json',
           'deployment_sha256':digest(canonical(deployment)),'qualification_sha256':digest(canonical(qualification)),
           'operations':list(OPERATIONS),'max_generations':1,'automatic_retry':False,'automatic_regeneration':False,
           'final_input_release':False,'neural_execution':False,'benchmark_execution':False,'replacement':None}
    return grant,deployment,qualification


def child_publish(root,bundle,point=None,ready=None,release=None):
    def hook(event):
        if event==point:
            if ready is not None:
                ready.set()
                if not release.wait(30):os._exit(99)
            else:os._exit(47)
    store=ReducedCustodyStore(root,ops=NativeOps(),hook=hook);store.recover();store.publish('g2-test-old',bundle)


def child_recover(root,queue):
    try:
        store=ReducedCustodyStore(root,ops=NativeOps());result=store.recover();queue.put(('admitted',len(result)))
    except Exception:queue.put(('rejected',None))


class Gate2Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.recipe=Recipe();cls.labeler=Labeler();cls.bundle=reduced_bundle(REVISION,cls.recipe,cls.labeler)

    def observe(self,point,execution,outcome):FAILURE_CHECKS.append({'test':self.id(),'point':point,'execution':execution,'outcome':outcome})

    def store(self,root,hook=None,ops=None):
        store=ReducedCustodyStore(root,self.recipe,self.labeler,ops=ops or SimulatedOps(),hook=hook);store.recover();return store

    def rewrite_hash(self,artifact,name):
        manifest=decode(artifact['manifest.json']);manifest['files'][name]={'sha256':digest(artifact[name]),'bytes':len(artifact[name])};artifact['manifest.json']=canonical(manifest)

    def test_schema_valid_objects_cannot_grant_production_authority(self):
        grant,deployment,qualified=grant_fixtures();validate_records(grant,deployment,qualified)
        for object_value in (grant,qualified,{'passed':True},canonical(grant).decode(),'/tmp/forged-grant.json'):
            for operation in OPERATIONS:
                with self.subTest(operation=operation),self.assertRaises(AuthorityClosed):require_generation(operation,'p001-fixture',authorization=object_value)
        with self.assertRaises(AuthorityClosed):require_generation('generate',qualification=qualified)
        self.observe('plausible-grant-and-synthetic-receipt','schema_fixture','fail_closed')

    def test_direct_internal_production_entrypoints_reject_before_output(self):
        with tempfile.TemporaryDirectory() as temp:
            real=object.__new__(ProductionStore);real.root=Path(temp)/'forged-output'
            calls=[lambda:ProductionStore(),lambda:production_bundle(),lambda:production_publish(),
                   lambda:self.recipe.generate_production(),lambda:CompletePlan('real'),
                   lambda:self.recipe._sample('cover','training',15000),
                   lambda:verify(self.bundle,'real',self.recipe,self.labeler),
                   lambda:real._initialize(real.root,self.recipe,self.labeler),
                   lambda:real._publish('p001-fixture',self.bundle),lambda:real._write(real.root/'file',b'no authority'),
                   lambda:real._completion('p001-fixture',self.bundle,{}),lambda:real.claim_generation(),
                   lambda:real.recover(),lambda:real.admit('p001-fixture'),lambda:real.invalidate('p001-fixture'),
                   lambda:real.regenerate('p001-old','p001-new'),lambda:real.event(real.root,'GENERATING')]
            with patch('dataset.storage.write_exclusive',side_effect=AssertionError('unauthorized write')):
                for call in calls:
                    with self.assertRaises(AuthorityClosed):call()
            self.assertFalse(real.root.exists())
        self.observe('direct-production-entrypoints','schema_fixture','fail_closed')

    def test_cli_forged_grants_never_touch_root_or_expose_private_errors(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)/'never-created';grant=Path(temp)/'grant.json';grant.write_bytes(canonical(grant_fixtures()[0]))
            for operation in ('production','release-final-inputs'):
                result=subprocess.run([sys.executable,'-B',str(SRC/'dataset/run.py'),operation,'--root',str(root),
                                       '--gate2-authorization',str(grant),'--qualification','FORGED-PRIVATE-VALUE'],capture_output=True,text=True)
                self.assertNotEqual(result.returncode,0);self.assertEqual(result.stdout,'');self.assertIn('Gate 2 is closed',result.stderr)
                self.assertNotIn('FORGED-PRIVATE-VALUE',result.stderr);self.assertFalse(root.exists())
        self.observe('forged-cli-grant','schema_fixture','fail_closed')

    def test_release_training_benchmark_and_deployment_authority_stay_separate(self):
        for forbidden in ('release-final-inputs','train','infer','benchmark','deploy','regenerate'):
            with self.assertRaises(AuthorityClosed):require_generation(forbidden)
        with self.assertRaises(AuthorityClosed):require_gate2(authorization=grant_fixtures()[0])
        with self.assertRaises(AuthorityClosed):production_launch(authorization=grant_fixtures()[0])

    def test_protected_records_reject_user_owned_paths_symlinks_and_mutable_parents(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'grant.json';path.write_bytes(canonical(grant_fixtures()[0]));path.chmod(0o640)
            with self.assertRaises(AuthorityClosed):protected_record(path)
            alias=Path(temp)/'alias';alias.symlink_to(path)
            with self.assertRaises(AuthorityClosed):protected_record(alias)
            with self.assertRaises(AuthorityClosed):protected_record(Path(temp)/'../unsafe')

    def test_grant_binding_and_qualification_mutations_reject(self):
        original=grant_fixtures()
        edits=[(0,'source_revision','0'*40),(0,'max_generations',2),(0,'automatic_retry',True),
               (0,'final_input_release',True),(0,'operations',['generate']),
               (1,'profile_sha256','0'*64),(1,'source_tree','0'*40),(2,'kind','synthetic'),
               (2,'final_input_exposure',True),(2,'production_source_reviewed',False)]
        for index,field,value in edits:
            values=copy.deepcopy(original);values[index][field]=value
            with self.subTest(field=field),self.assertRaises(Exception):validate_records(*values)
        for role,field,value in (('training','groups',[11001]),('training','cap_eff',1),('inference','training_labels_denied',False),('inference','fd_leak',True)):
            values=copy.deepcopy(original);values[2][role][field]=value
            values[0]['qualification_sha256']=digest(canonical(values[2]))
            with self.assertRaises(Exception):validate_records(*values)

    def test_profile_roots_views_and_fixed_identities_reject_overlap(self):
        profile=profile_fixture();validate_profile(profile)
        for left,right in (('training_view','inference_view'),('inference_view','training_view'),('runtime','jail_parent')):
            bad=copy.deepcopy(profile);bad[right]=bad[left]+'/nested'
            with patch.object(Path,'lstat',side_effect=AssertionError('must reject before host check')):
                with self.assertRaises(AuthorityClosed):validate_profile(bad,check_host=True)
        for value in (str(ROOT),str(ROOT/'.trust'),str(ROOT/'generations'),str(ROOT/'generations/p001-id'),str(ROOT/'generations/p001-id/private/final-labels')):
            bad=copy.deepcopy(profile);bad['training_view']=value
            with self.assertRaises(AuthorityClosed):validate_profile(bad)
        bad=copy.deepcopy(profile);bad['identities']['training']['uid']=11001
        with self.assertRaises(Exception):validate_profile(bad)

    def test_reduced_complete_recipe_labels_rng_and_byte_replay(self):
        self.assertEqual(self.bundle,reduced_bundle(REVISION,self.recipe,self.labeler))
        manifest=verify(self.bundle,'g2-synthetic',self.recipe,self.labeler)
        self.assertEqual(manifest['counts'],{'training':6,'validation':6,'final':10})
        metadata=decode(self.bundle['private/provenance.json'])
        self.assertEqual(len(metadata['rng']),6);self.assertEqual(metadata['recipe'],'p001-g2-toy.v1')
        self.assertIsNone(metadata['authority_sha256']);self.assertIsNone(metadata['profile_sha256'])
        self.assertEqual(manifest['suite_counts'],{'challenge':3,'status':1,'challenge_status_overlap':0,'ordinary_reserved_overlap':0,'reserved_union':4})
        for raw in (self.bundle[p] for p in FILES if p.endswith('labels.jsonl')):
            self.assertTrue(rows(raw))

    def test_independent_adversarial_recipe_matches_on_toy_geometry_only(self):
        from dataset.recipe import challenge_requests,status_requests
        for domain in ('cover','shooting'):
            self.assertEqual(list(map(canonical,boundary_requests(self.recipe,domain,TOY))),list(map(canonical,challenge_requests(self.recipe,domain,TOY))))
            # World status fixtures are public deterministic recipe checks, not a final artifact.
            self.assertEqual(list(map(canonical,independent_status(self.recipe,domain))),list(map(canonical,status_requests(self.recipe,domain))))
        modified=Recipe();modified.prereg=copy.deepcopy(modified.prereg);modified.prereg['datasets']['cover']['counts']=[2,2,2]
        with self.assertRaises(VerificationFailure):CompletePlan('g2-synthetic',modified)

    def test_kind_confusion_expanded_samples_and_forged_hashes_reject(self):
        for mode in ('real-kind','expanded','bad-rng','audit','bad-label','missing-label','public-request'):
            artifact=copy.deepcopy(self.bundle)
            if mode=='real-kind':
                value=decode(artifact['manifest.json']);value['kind']='real';value['artifact_version']='p001-real-artifacts.v1';artifact['manifest.json']=canonical(value)
            elif mode=='expanded':
                artifact['consumer/training/queries.jsonl']*=3;self.rewrite_hash(artifact,'consumer/training/queries.jsonl')
            elif mode=='bad-rng':
                value=decode(artifact['private/provenance.json']);value['rng'][0]['seed']+=1;artifact['private/provenance.json']=canonical(value);self.rewrite_hash(artifact,'private/provenance.json')
            elif mode=='audit':
                value=decode(artifact['private/audit.json']);value['suite_counts']['challenge']=0;artifact['private/audit.json']=canonical(value);self.rewrite_hash(artifact,'private/audit.json')
            elif mode=='bad-label':
                values=rows(artifact['consumer/training/labels.jsonl']);values[0]['status']='model_failure';values[0]['output']=None;artifact['consumer/training/labels.jsonl']=jsonl(values);self.rewrite_hash(artifact,'consumer/training/labels.jsonl')
            elif mode=='missing-label':
                artifact['private/final-labels/labels.jsonl']=b'';self.rewrite_hash(artifact,'private/final-labels/labels.jsonl')
            else:
                values=rows(artifact['consumer/training/queries.jsonl']);values[0]=request('navigation',(7,29));artifact['consumer/training/queries.jsonl']=jsonl(values);self.rewrite_hash(artifact,'consumer/training/queries.jsonl')
            with self.subTest(mode=mode),self.assertRaises(Exception):verify(artifact,'g2-synthetic',self.recipe,self.labeler)

    def test_permission_classes_registered_receipt_and_public_allowlist(self):
        with tempfile.TemporaryDirectory() as temp:
            store=self.store(Path(temp)/'store');receipt=store.publish('g2-test-old',self.bundle)
            directory=store.root/'generations/g2-test-old'
            self.assertEqual(stat.S_IMODE(directory.stat().st_mode),0o711)
            self.assertEqual(stat.S_IMODE((directory/'consumer').stat().st_mode),0o750)
            self.assertEqual(stat.S_IMODE((directory/'consumer/training/labels.jsonl').stat().st_mode),0o640)
            self.assertEqual(stat.S_IMODE((directory/'private').stat().st_mode),0o700)
            self.assertEqual(stat.S_IMODE((directory/'private/final-labels/labels.jsonl').stat().st_mode),0o600)
            self.assertEqual(len(store.recover()),1);self.assertFalse(receipt['custody_pass'])
            public=public_receipt(receipt)
            self.assertEqual(set(public),{'generation_id','contract_versions','source_revision','artifact_hashes','counts','verification_pass','custody_pass','receipt_hash'})
            self.assertNotIn('authority_sha256',public);self.assertNotIn('private',canonical(public).decode())
            registered=decode((store.root/'.trust/registrations/g2-test-old.json').read_bytes())
            self.assertEqual(registered['completion_sha256'],digest(canonical(receipt)))

    def test_loss_explicit_fresh_replay_retirement_and_registration_loss(self):
        with tempfile.TemporaryDirectory() as temp:
            store=self.store(Path(temp)/'store');store.publish('g2-test-old',self.bundle)
            saved=Path(temp)/'old';shutil.move(store.root/'generations/g2-test-old',saved)
            self.assertEqual(store.recover(),[]);loss=(store.root/'.trust/losses/g2-test-old.json').read_bytes()
            self.assertEqual(store.recover(),[]);self.assertEqual(loss,(store.root/'.trust/losses/g2-test-old.json').read_bytes())
            fresh=store.regenerate('g2-test-old','g2-test-new');self.assertEqual(fresh['generation_id'],'g2-test-new')
            shutil.copytree(saved,store.root/'generations/g2-test-old')
            with self.assertRaises(AdmissionFailure):store.recover()
            with self.assertRaises(AdmissionFailure):store.admit('g2-test-new')
        with tempfile.TemporaryDirectory() as temp:
            store=self.store(Path(temp)/'store');store.publish('g2-test-old',self.bundle)
            (store.root/'.trust/index.json').unlink()
            with patch('dataset.real_store.reduced_bundle',side_effect=AssertionError('no automatic reconstruction')):
                with self.assertRaises(Exception):store.regenerate('g2-test-old','g2-test-new')
        self.observe('registered-loss-and-trust-loss','reduced_fixture','fail_closed')

    def test_analytical_resource_bound_and_capacity_failures(self):
        from dataset.preflight import upper_row_bound,required_bytes,check_capacity,production_preflight
        self.assertEqual(upper_row_bound(),62185)
        required=required_bytes(22)
        check_capacity(required,128,22)
        with self.assertRaises(AdmissionFailure):check_capacity(required-1,128,22)
        with self.assertRaises(AdmissionFailure):check_capacity(required,127,22)
        with self.assertRaises(AuthorityClosed):production_preflight()

    def test_one_generation_claim_consumption_restart_loss_and_ambiguity(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)/'store';store=self.store(root)
            claim=store.claim_generation('g2-test-old',REVISION)
            raw=(root/'.trust/claims/g2-test-old.json').read_bytes()
            self.assertEqual(claim['kind'],'g2-synthetic')
            with self.assertRaises(AdmissionFailure):store.claim_generation('g2-test-old',REVISION)
            restarted=self.store(root)
            with self.assertRaises(AdmissionFailure):restarted.claim_generation('g2-test-old',REVISION)
            self.assertEqual(raw,(root/'.trust/claims/g2-test-old.json').read_bytes())
            (root/'.trust/claims/g2-test-old.json').unlink()
            with self.assertRaises(Exception):restarted.recover()
            self.assertFalse((root/'.trust/claims/g2-test-old.json').exists())
        self.observe('one-generation-claim-loss-and-reuse','reduced_fixture','fail_closed')

    def test_independent_label_failure_retains_private_evidence_and_no_registration(self):
        with tempfile.TemporaryDirectory() as temp:
            store=self.store(Path(temp)/'store');artifact=copy.deepcopy(self.bundle)
            values=rows(artifact['consumer/training/labels.jsonl']);values[0]['status']='model_failure';values[0]['output']=None
            artifact['consumer/training/labels.jsonl']=jsonl(values);self.rewrite_hash(artifact,'consumer/training/labels.jsonl')
            with self.assertRaises(VerificationFailure):store.publish('g2-test-old',artifact)
            evidence=decode((store.root/'quarantine/g2-test-old/failure.json').read_bytes())['evidence']
            self.assertIn('request',evidence);self.assertIn('expected',evidence);self.assertIn('actual',evidence)
            self.assertFalse(list((store.root/'.trust/registrations').iterdir()))
        self.observe('independent-label-disagreement','reduced_fixture','fail_closed')

    def test_permission_drift_alias_and_scope_mutation_close_admission(self):
        for mode in ('final-public','training-write','private-symlink','hardlink','empty-extra'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as temp:
                store=self.store(Path(temp)/'store');store.publish('g2-test-old',self.bundle)
                generation=store.root/'generations/g2-test-old';private=generation/'private/final-labels/labels.jsonl'
                if mode=='final-public':private.chmod(0o640)
                elif mode=='training-write':(generation/'consumer/training/labels.jsonl').chmod(0o660)
                elif mode=='private-symlink':private.unlink();private.symlink_to(generation/'consumer/training/labels.jsonl')
                elif mode=='hardlink':os.link(private,Path(temp)/'alias')
                else:(generation/'consumer/extra').mkdir(mode=0o750)
                with self.assertRaises(Exception):store.recover()
                self.assertFalse(store.recovered)
        with tempfile.TemporaryDirectory() as temp:
            store=self.store(Path(temp)/'store');store.root=Path(temp)/'other'
            with self.assertRaises(AdmissionFailure):store.publish('g2-test-old',self.bundle)
            self.assertFalse(store.root.exists())
        with self.assertRaises(AdmissionFailure):ReducedCustodyStore(ROOT)

    def test_diagnostics_cannot_follow_an_external_alias(self):
        with tempfile.TemporaryDirectory() as temp:
            store=self.store(Path(temp)/'store');outside=Path(temp)/'outside';outside.mkdir(mode=0o700)
            (store.root/'diagnostics').rmdir();(store.root/'diagnostics').symlink_to(outside)
            with self.assertRaises(AdmissionFailure):store.recover()
            self.assertEqual(list(outside.iterdir()),[])

    def test_precommit_permission_and_catalog_faults_never_return_success(self):
        for point in ('AFTER_REGISTRATION','VERIFYING','AFTER_RECEIPT','AFTER_PERMISSION_PREPARATION','BEFORE_RENAME'):
            def hook(event):
                if event==point:raise OSError('synthetic injected failure')
            with self.subTest(point=point),tempfile.TemporaryDirectory() as temp:
                store=self.store(Path(temp)/'store',hook=hook)
                with self.assertRaises(OSError):store.publish('g2-test-old',self.bundle)
                self.assertFalse(store.recovered);self.assertFalse(list((store.root/'generations').iterdir()))
                failure=store.root/'quarantine/g2-test-old/failure.json';self.assertTrue(failure.exists())
                for path in (store.root/'quarantine/g2-test-old').rglob('*'):
                    self.assertEqual(stat.S_IMODE(path.stat().st_mode),0o700 if path.is_dir() else 0o600)
                self.observe(point,'simulated_fault','fail_closed')

    def test_unregistered_candidate_even_with_self_consistent_hashes_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            source=self.store(Path(temp)/'source');source.publish('g2-test-old',self.bundle)
            target=self.store(Path(temp)/'target');shutil.copytree(source.root/'generations/g2-test-old',target.root/'generations/g2-test-old')
            with self.assertRaises(AdmissionFailure):target.recover()
            self.assertFalse(target.recovered)

    @unittest.skipUnless(sys.platform=='linux','native claim-ledger interruption checks require Linux')
    def test_native_claim_placement_and_consumed_grant_survive_process_exit(self):
        ctx=multiprocessing.get_context('fork')
        for point in ('AFTER_CLAIM_RECORD','AFTER_CLAIM'):
            with self.subTest(point=point),tempfile.TemporaryDirectory() as temp:
                root=Path(temp)/'store';self.store(root,ops=NativeOps())
                def claim_exit():
                    def hook(event):
                        if event==point:os._exit(48)
                    store=ReducedCustodyStore(root,ops=NativeOps(),hook=hook)
                    store.claim_generation('g2-test-old',REVISION)
                child=ctx.Process(target=claim_exit);child.start();child.join(30)
                self.assertFalse(child.is_alive());self.assertEqual(child.exitcode,48)
                if point=='AFTER_CLAIM_RECORD':
                    with self.assertRaises(Exception):ReducedCustodyStore(root,ops=NativeOps())
                else:
                    store=self.store(root,ops=NativeOps())
                    with self.assertRaises(AdmissionFailure):store.claim_generation('g2-test-old',REVISION)
                self.observe(point,'linux_native','fail_closed')

    @unittest.skipUnless(sys.platform=='linux','native G2 crash checks require Linux')
    def test_native_prepared_permissions_and_rename_process_exits(self):
        ctx=multiprocessing.get_context('fork')
        for point in ('AFTER_REGISTRATION','AFTER_PERMISSION_PREPARATION','BEFORE_RENAME','AFTER_RENAME'):
            with self.subTest(point=point),tempfile.TemporaryDirectory() as temp:
                root=Path(temp)/'store';self.store(root,ops=NativeOps())
                child=ctx.Process(target=child_publish,args=(root,self.bundle,point));child.start();child.join(30)
                self.assertFalse(child.is_alive());self.assertEqual(child.exitcode,47)
                receipts=self.store(root,ops=NativeOps()).recover()
                self.assertEqual(len(receipts),int(point=='AFTER_RENAME'))
                self.observe(point,'linux_native','verified_survivor' if point=='AFTER_RENAME' else 'fail_closed')

    @unittest.skipUnless(sys.platform=='linux','native G2 concurrency checks require Linux')
    def test_native_prepared_publication_blocks_concurrent_recovery(self):
        ctx=multiprocessing.get_context('fork')
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)/'store';self.store(root,ops=NativeOps());ready=ctx.Event();release=ctx.Event();queue=ctx.Queue()
            writer=ctx.Process(target=child_publish,args=(root,self.bundle,'AFTER_PERMISSION_PREPARATION',ready,release));writer.start();self.assertTrue(ready.wait(30))
            reader=ctx.Process(target=child_recover,args=(root,queue));reader.start()
            with self.assertRaises(__import__('queue').Empty):queue.get(timeout=.3)
            release.set();writer.join(30);reader.join(30)
            self.assertEqual(writer.exitcode,0);self.assertEqual(reader.exitcode,0);self.assertEqual(queue.get(timeout=5),('admitted',1))
            self.assertFalse(list((root/'.trust/losses').iterdir()))
            self.observe('prepared-mode-publication-concurrency','linux_native','serialized')
