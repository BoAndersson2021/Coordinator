# NEURAL agent entrypoint

NEURAL is a research umbrella. NeuralField is its first system. Start by reading this file, [README.md](README.md), the [governing mission](docs/REPOSITORY_INITIALIZATION_MISSION.md), [Plan.md](Plan.md), and [Handover.md](Handover.md), then the documents for the assigned system.

## Authority and ownership

Apply platform safety and execution policies and the user's current explicit authorization. Within repository documentation, use this order:

1. [Initialization mission](docs/REPOSITORY_INITIALIZATION_MISSION.md): purpose, research laws, and authorization boundaries.
2. [THESIS.md](THESIS.md): hypotheses and scope of claims.
3. [Architecture](docs/ARCHITECTURE.md) and [experiment protocol](docs/EXPERIMENT_PROTOCOL.md): separation, authority, and evidence rules.
4. The assigned system's versioned specification; for NeuralField this is [P001_SPEC.md](systems/NeuralField/P001_SPEC.md). It owns P001 constants, geometry, query semantics, tolerances, and experiment configuration.
5. Machine-readable geometry and schemas referenced by that specification. They must agree with the prose; disagreement blocks affected work until corrected in review.
6. [Roadmap](docs/RESEARCH_ROADMAP.md), Plan, and Handover: sequence and status. They cannot authorize a phase or change a contract.

The user/domain owner controls scope and advancement. The assigned implementation agent owns only its authorized component. Reviewers check evidence independently. The conventional oracle owns geometric labels; neural outputs never own world truth. Future systems need their own specifications and must not inherit NeuralField assumptions by default.

## Current gate

Phase 0 through B1-R are accepted and merged through `cdfd03a2afaad5488485e78e6e694b5a1627ef00` (PR #8). The owner accepted the [Gate 2 packet](docs/P001_B1_GATE2_WORK_PACKET.md) in PR #9 at `486357bc28d76507988da935e7160594ab6f725d` and authorized **G2-1 source/schema implementation and reduced synthetic verification only**. See [G2-1 implementation](docs/P001_G2_1_IMPLEMENTATION.md). Preserve frozen research contracts, independent all-row labels, trusted registration/claims, loss invalidation and sealed final custody. Caller flags/objects or synthetic receipts cannot grant production authority. No privileged deployment, real generation/publication, final-input exposure, neural work, benchmarks or merge is authorized. Leave PR #9 as the packet record and submit a dedicated implementation PR, then stop for independent review.

## Operating rules

- Revalidate repository path, HEAD, branch, working tree, and applicable nested instructions before mutation. Read implementations before setup commands. Preserve unrelated changes; never overwrite another agent's work.
- Work on a dedicated branch. Keep commits bounded and reviewable. Do not force push, merge, deploy, or advance phases by inference from a document status.
- Keep A and B independently executable. Shared code may validate syntax, normalize inputs, serialize outputs, and time execution; it may not compute tactical answers for B.
- Freeze geometry, splits, metrics, thresholds, model selection, all A/B code, measurement/analysis code, final performance trace, trial order and benchmark conditions before final-input exposure. Run one registered final-evaluation campaign including planned repetitions. Post-exposure tuning or changed procedures require a new revision and a new sealed final set; preserve previous and negative evidence.
- Keep final labels unavailable to training, selection, and measured B. Report false positives and failure cases even when aggregate metrics look favorable.
- Do not describe proposed numbers, analytical fixtures, document validation, or parameter arithmetic as measured network evidence.
- Record changed files, validation commands and outcomes, unresolved dependencies, and the exact next gate in Handover. Cite commits already in existence; a commit cannot contain its own SHA.
- During CLI reviews, distinguish generated model requests, harness permission/routing decisions, execution environment, and returned results. Initialization grants no repository-work authority.

## Documentation checks

Use `python3 -B tools/validate_phase0.py --stage P001-G2-1`, `python3 -B -m unittest discover -s tools -p 'test_b1_contract.py' -v` and `python3 -B tools/verify_gate1.py --receipt /tmp/neural-g2-tests.json --g2-receipt /tmp/neural-g2-checks.json`. Runtime tests create only reduced synthetic temporary artifacts. Native tests require Linux; skips cannot prove those gates. Historical evidence checks do not requalify changed source or launch profiles. Physical power-loss survival is not required for P001. No test pass authorizes G2-2 or G2-3.
