# NEURAL agent entrypoint

NEURAL is a research umbrella. NeuralField is its first system. Start by reading this file, [README.md](README.md), the [governing mission](docs/REPOSITORY_INITIALIZATION_MISSION.md), [Plan.md](Plan.md), and [Handover.md](Handover.md), then the documents for the assigned system.

## Authority and ownership

Apply platform safety and execution policies and the user's current explicit authorization. Within repository documentation, use this order:

1. [Initialization mission](docs/REPOSITORY_INITIALIZATION_MISSION.md): purpose, research laws, and authorization boundaries.
2. [THESIS.md](THESIS.md): hypotheses and scope of claims.
3. [Architecture](docs/ARCHITECTURE.md) and [experiment protocol](docs/EXPERIMENT_PROTOCOL.md): separation, authority, and evidence rules.
4. The assigned system's versioned specification; for NeuralField this is [P001_SPEC.md](systems/NeuralField/P001_SPEC.md). It owns P001 constants, geometry, query semantics, tolerances, and experiment configuration.
5. Machine-readable geometry and schemas referenced by that specification. They must agree with the prose; disagreement blocks affected work until corrected in review.
6. [Roadmap](docs/RESEARCH_ROADMAP.md), Plan, and Handover: sequence and status. They cannot authorize a phase or change a contract.

The user/domain owner controls scope and advancement. The assigned implementation agent owns only its authorized component. Reviewers check evidence independently. The conventional oracle owns geometric labels; neural outputs never own world truth. Future systems need their own specifications and must not inherit NeuralField assumptions by default.

## Current gate

Phase 0, P001-A, B1-C, Gate 1, B1-P synthetic evidence and B1-D custody v2 are accepted and merged through `0e30cba9818f933e91ede0400dc61230aaf32a86`. The owner authorized R1–R5 in [PR #7](https://github.com/WRRTREPO/NEURAL/pull/7) at `1aff80a58e7e2c9f9a1aa3338bdec6ca47035476`: source/schema alignment and reduced synthetic verification only. See [B1-R implementation](docs/P001_B1_R_IMPLEMENTATION.md). Trusted registration must remain separate from candidate data; missing registration closes admission and never triggers reconstruction or automatic regeneration. Preserve original v1 evidence and scientific contracts. Real generation/publication, final-input exposure, neural work, benchmarks, privileged host changes, disruptive VM tests and merge remain closed. Stop after the implementation PR for independent review.

## Operating rules

- Revalidate repository path, HEAD, branch, working tree, and applicable nested instructions before mutation. Read implementations before setup commands. Preserve unrelated changes; never overwrite another agent's work.
- Work on a dedicated branch. Keep commits bounded and reviewable. Do not force push, merge, deploy, or advance phases by inference from a document status.
- Keep A and B independently executable. Shared code may validate syntax, normalize inputs, serialize outputs, and time execution; it may not compute tactical answers for B.
- Freeze geometry, splits, metrics, thresholds, model selection, all A/B code, measurement/analysis code, final performance trace, trial order and benchmark conditions before final-input exposure. Run one registered final-evaluation campaign including planned repetitions. Post-exposure tuning or changed procedures require a new revision and a new sealed final set; preserve previous and negative evidence.
- Keep final labels unavailable to training, selection, and measured B. Report false positives and failure cases even when aggregate metrics look favorable.
- Do not describe proposed numbers, analytical fixtures, document validation, or parameter arithmetic as measured network evidence.
- Record changed files, validation commands and outcomes, unresolved dependencies, and the exact next gate in Handover. Cite commits already in existence; a commit cannot contain its own SHA.
- During CLI reviews, distinguish generated model requests, harness permission/routing decisions, execution environment, and returned results. Initialization grants no repository-work authority.

## Documentation checks

Use `python3 -B tools/validate_phase0.py --stage P001-B1-R`, `python3 -B -m unittest discover -s tools -p 'test_b1_contract.py' -v` and `python3 -B tools/verify_gate1.py --receipt /tmp/neural-b1r-tests.json`. The test runner executes reduced synthetics under the current authorization; native process/lock tests require Linux and skips must be reported. `python3 -B tools/verify_qualification_evidence.py` checks historical evidence without host probes. Test passes do not authorize Gate 2 or claim production qualification. Physical power-loss survival is optional, not a P001 prerequisite.
