# Research evidence storage

No experiment results exist. This file establishes the evidence policy and makes this directory meaningful in Git.

After explicit experiment authorization, store immutable runs at `results/<system>/<experiment>/<revision>/<run_id>/` with the [protocol's](../docs/EXPERIMENT_PROTOCOL.md) manifest, raw timing, correctness, failure and memory artifacts. Source/config/data/weights must have real hashes and provenance. Keep negative and incomplete runs, with clear status and failure reason. Never overwrite a published run to improve its outcome.

Large artifacts may later use a separately approved storage policy with hashes and retrievable locations; no cloud dependency or external storage is introduced now. Phase 0 document verification belongs in [PHASE0_VERIFICATION.md](../docs/PHASE0_VERIFICATION.md), not in invented benchmark output.
