# NEURAL research thesis

Status: Phase 0 contract, pending independent review. Governing source: [initialization mission](docs/REPOSITORY_INITIALIZATION_MISSION.md). Evidence rules: [experiment protocol](docs/EXPERIMENT_PROTOCOL.md).

Small specialized networks may represent game-level spatial relationships at lower runtime or storage cost while preserving useful correctness. This is a testable proposition, not a performance claim. The first system, [NeuralField](systems/NeuralField/README.md), studies a fixed 2D world before dynamics, scale, 3D, or engine integration.

## Hypotheses and falsification

The following decisions apply to the preregistered P001 configuration and workload. A failed configuration does not disprove every possible neural representation; it rejects support for that configuration. Broader claims need new experiments. No hypothesis is rescued by excluding failures after final testing.

| Hypothesis | Supporting evidence required | Falsification / lack of support |
| --- | --- | --- |
| H1 spatial compression | B meets P001 quality gates and has strictly fewer representation bytes than the smallest qualifying conventional representation for the same three contracts. Report disk, resident representation, scratch, and process memory separately. | Quality fails, or B representation bytes are at least those of the qualifying conventional baseline. Framework memory cannot be hidden. |
| H2 query efficiency | B and all three A variants meet P001 quality gates; all three preregistered B/A primary latency intervals lie wholly below 1, establishing benefit against the fastest qualifying A without post-test baseline selection. Report cold and lifetime cost as well. | Quality fails, any required contrast is incomplete, or any interval is not wholly below 1. An interval wholly above 1 is evidence of disadvantage; overlap is inconclusive. No native-engine claim follows from a Python experiment. |
| H3 shared representation | A single B model meets all domain gates and beats the three separate B models in total representation bytes AND primary all-domain latency, with corrected uncertainty for latency. Use identical labels, training budgets per model, and disclose aggregate training cost. | Either quality gate fails or either benefit is absent. A comparison against A alone cannot establish H3. |
| H4 spatial generalization | B meets all gates on reserved spatial tiles and unseen coordinates/nodes, including sealed boundaries. Give errors by held-out tile and distance to geometry. | Any specified held-out gate fails. P001 establishes only within-level positional interpolation/extrapolation; it does not establish unseen-level or arbitrary-orientation generalization. |

Numerical quality budgets are justified in [P001](systems/NeuralField/P001_SPEC.md); they do not come from fitting observed neural errors. Statistical methodology and primary workloads are defined before testing. Hypotheses can be unsupported or inconclusive; both outcomes must be retained.

H1 is a deterministic byte comparison conditional on sample quality; H4 is descriptive finite-sample acceptance and has no significance test. H3 combines deterministic bytes with an inferential latency contrast. Only H2's three A-variant latency contrasts and H3's one shared/separate latency contrast receive the nominal family error budget under the protocol. H4 support describes those held-out samples only, not universal correctness or a probability guarantee for unseen geometry.

## Boundaries of claims

P001 cover measures finite geometric ray exposure. Shooting measures an ideal zero-radius segment. Navigation measures reachability and shortest cost on a declared four-neighbor lattice. None measures tactical desirability, continuous optimal paths, animation, penetration, projectile ballistics, destructibility, or production safety.

Exact predicates have zero permitted reference error. Numerical estimates have explicit error budgets. Neural legality predictions remain experimental even if they pass a finite test set. Advisory ranking can rank already legal choices but cannot grant movement or firing permission. Geometry and snapshots remain authoritative.

P001 may fail because its conventional computation is too cheap, because the learned field is discontinuous, because a small model cannot represent topology, or because training/storage overhead dominates. These are useful findings. Fair precomputation, batching, and caching must remain in the baseline comparison.

Research advancement is evidence-driven and requires explicit authorization under the [roadmap](docs/RESEARCH_ROADMAP.md). No experiments have been run during Phase 0.
