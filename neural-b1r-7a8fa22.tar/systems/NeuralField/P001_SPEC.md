# P001 — Static 2D tactical field

Experiment `NeuralField/P001`, revision `1`; query/response contract `p001.v1`; snapshot `p001-static-v1`. Status: implementation-grade Phase 0 proposal, pending independent review. **Implementation and training are not authorized.** Governing sources: [mission](../../docs/REPOSITORY_INITIALIZATION_MISSION.md), [architecture](../../docs/ARCHITECTURE.md), [protocol](../../docs/EXPERIMENT_PROTOCOL.md).

## 1. Objective and limits

Compare independent A and B for the same three logical queries. Assess H1-H4 without assuming a benefit. A fixed destination and firing/threat origin keep the first experiment small; arbitrary destinations/origins and actor dimensions are outside revision 1. Query types still take those values explicitly and reject unsupported ones. A learned field is never an authoritative movement or firing permission.

## 2. Coordinate and geometry law

Use Cartesian XY, x east/right, y north/up, origin at the southwest corner. Units are metres. The world is the closed square [0,16] × [0,16]. No elevation, orientation-dependent collision, dynamic geometry or time exists. Coordinates in serialized valid requests are integer multiples of 0.000001 m, processed by A in binary64. P001 schemas describe structural types; runtime domain validation additionally checks that conversion to integer micrometres and back differs by at most 1e-12 m. Other finite coordinates are out-of-domain. Internal ray points can be rational values finer than this input grid.

Every obstacle is a closed axis-aligned rectangle; contact, corner tangency and collinear overlap obstruct. The versioned [geometry file](experiments/P001/geometry.v1.json) is the machine-readable copy of this exact table:

| ID | x min | x max | y min | y max | Role |
| --- | --- | --- | --- | --- | --- |
| W0 | 7 | 8 | 0 | 7 | Lower divider |
| W1 | 7 | 8 | 8 | 16 | Upper divider |
| C0 | 3 | 4 | 3 | 6 | West cover |
| C1 | 10 | 11 | 10 | 13 | East cover |
| P0 | 11 | 13 | 2 | 2.5 | Pocket south |
| P1 | 11 | 13 | 3.5 | 4 | Pocket north |
| P2 | 11 | 11.5 | 2.5 | 3.5 | Pocket west |
| P3 | 12.5 | 13 | 2.5 | 3.5 | Pocket east |

Actor footprint: an axis-aligned square of side 0.50 m, half extent 0.25 m, centred at the queried position. It cannot rotate or step into solid contact. Its complete footprint must lie in the closed world. Touching the world boundary is allowed; touching an obstacle is not. Equivalently, the centre must be inside [0.25,15.75]² and outside every rectangle expanded by 0.25 m on each side, including that expanded rectangle's boundary. No epsilon inflates/deflates these laws. Reference numeric tolerance is for checking computations, not changing topology. Ambiguous predicate computations must use integer/rational or robust fallback in A; do not classify via a fuzzy collision margin.

The divider leaves a 1 m passage y in (7,8), with 0.5 m centre clearance width after actor expansion. Threat/firing origin is (2,7.5); fixed destination is (14,7.5). The pocket interior contains the valid centre (12,3) but cannot connect to the destination. These are analytical design properties, not measured results.

## 3. Wire contract and failure precedence

Read [query.schema.json](src/common/query.schema.json) and [response.schema.json](src/common/response.schema.json). Reject extra fields. All numeric values must be finite and bools must not be accepted as numbers or indices. Request identity is echoed exactly; `implementation` identifies A/B. Shared code can reject types/constants/domain ranges but cannot inspect obstacles.

Well-typed unsupported query domains, schema versions, snapshots, actor/firing constants, fixed origins/destinations or coordinates return `out_of_domain`; malformed shape/type, non-finite input or missing identity returns `invalid_input`. For malformed envelope identity fields, a runner returns an error record outside the successful response stream containing row index and reason; it must not fabricate a query ID. Final data contain valid identity fields, so such errors are scorer failures. Failure statuses with valid identity use null output and echo unsupported string domain/version/snapshot values. Any non-finite internal/result value, missing artifact, or schema-inconsistent result yields `model_failure`, never a guessed geometric answer.

Input schemas are the accepted-domain contract; an otherwise well-typed constant mismatch is an out-of-domain request rather than a generic schema failure. Implement structural/type validation before domain restrictions and use this status precedence in both runners. On valid in-domain requests, `ok` does not imply physical legality.

### Cover

Input: `candidate_m:[x,y]`, `threat_m:[2,7.5]`, `actor:{half_extent_m:0.25}`. Candidate may lie anywhere in the world; centre-to-threat distance must exceed 1 m, otherwise out-of-domain. Fixed threat is a point, not an actor. This exclusion avoids self-threat/silhouette degeneracy and is identical in A/B.

Output: `candidate_traversable:bool`, `exposure_fraction:number|null`, `protection_fraction:number|null`. If the square is illegal, false and two nulls. If legal, sample its threat-facing face: let d = threat - centre; if |dx| >= |dy| use the vertical face at centre.x + sign(dx)*0.25; otherwise use the horizontal face at centre.y + sign(dy)*0.25. On that face, sample 17 points including endpoints, at offsets -0.25 + j/32 m for j=0..16 along the other axis. Cast a closed segment from threat to each point. A ray is exposed iff no obstacle intersects it. Exposure is the exact exposed count /17; protection is 1 minus exposure. It measures these 17 rays, not an integral over a silhouette, blast protection or tactical quality.

B reports a continuous estimate of the same exposure quantity and its complement. It must not reconstruct A rays at inference. Candidate legality is an exact-class prediction; wrong positive legality is scored explicitly. Domain checks do not supply that label.

### Navigation

Input: `start_node:[i,j]`, `destination_node:[55,29]`, `actor:{half_extent_m:0.25}`. i,j are integers 0..62. Node centre is (0.25+0.25i, 0.25+0.25j), yielding 63² = 3,969 possible nodes. Continuous inputs are not snapped. The fixed destination centre is (14,7.5).

A node is traversable exactly when its footprint is legal. Two traversable cardinal-neighbor nodes have an undirected edge iff the entire centre segment is outside the expanded closed obstacles and inside the permitted centre world; endpoint validity alone is insufficient. Only four neighbors, no diagonal moves. Each edge costs 0.25 m. Route cost is 0.25 times minimum edge count on this graph, not continuous Euclidean shortest length or tactical preference. A zero-length path at the valid destination costs 0.

Output: `start_traversable:bool`, `destination_traversable:bool`, `reachable:bool`, `route_cost_m:number|null`. Blocked start or destination yields false reachability and null cost. A valid disconnected start also yields false reachability and null cost while both traversability flags remain true. Both A and B return the same fields. The destination is a verified fixed scenario constant, so B may report its traversability as true without querying A; the start's truth and connectivity must be predicted. Cost exists only when predicted reachable, must be nonnegative, and cannot exceed 992 m (a simple path on at most 3,969 nodes). No path is returned; B cannot execute movement.

### Shooting

Input: `firing_m:[2,7.5]`, `target_m:[x,y]`, `firing_geometry:{projectile_radius_m:0}`. Target is any world point other than the identical firing point. A target inside/on an obstacle is valid input and obstructed. This is an ideal zero-radius geometric projectile without penetration, actor hitboxes or ballistics.

Intersect the closed segment p(t)=firing+t*(target-firing), t in [0,1], against every closed obstacle. Output: `line_clear:bool`, `first_hit_t:number|null`, `first_hit_obstacle_id:string|null`. If clear, both hit fields are null. Otherwise return the minimum entry t and its obstacle ID; for exact equal entry t break ties by ID's ASCII lexical order. Endpoint and tangent hits block. A target outside the world is out-of-domain, not a simulated exterior wall hit. B estimates t and predicts the obstacle ID; it cannot use an exact intersection to repair them.

## 4. Conventional variants and label checks

A0: direct deterministic footprint/segment checks and graph search per navigation query. A1: precompute node legality, legal edges and single-destination distances once; use lookup for navigation, batched direct segment intersections for cover/shooting. A2: add an exact semantic-query cache for declared repeating traces, charging label computation, cache population and bytes. Benchmark all, including a compact A1 representation storing only needed legality/distances; dense full graphs cannot be the sole memory baseline.

Reference ray intersection uses closed segment/rectangle slab intervals, with zero-direction and boundary cases defined by section 2. Independent checker uses polygon-edge intersection plus endpoint containment and robust rational checks for ambiguous fixtures. Reference graph oracle uses BFS; a separately written shortest-path checker verifies all-node distances and unreachable components. These are implementation obligations, not Phase 0 algorithms.

Declared public fixtures are exactly the following named examples, enumerated as complete domain inputs in [public-fixtures.v1.json](experiments/P001/public-fixtures.v1.json). The registry binds the p001.v1 schema and p001-static-v1 snapshot and contains no labels. A semantic match ignores query_id. These fixtures are excluded from every learned dataset; reference verification workloads do not automatically exclude their queries. Reserved final challenges are a separate §5 recipe, with public matches removed first. Registry/table disagreement blocks generation.

Public oracle sanity cases, excluded from every learned dataset:

| Domain/input | Expected reference result | Reason |
| --- | --- | --- |
| Nav [7,29] | traversable, reachable, cost 12 m | Straight 48-edge passage route to [55,29] |
| Nav [55,29] | traversable, reachable, cost 0 | Destination |
| Nav [47,11] | traversable, unreachable, null cost | Centre (12,3) in sealed pocket |
| Nav [29,11] | start blocked, unreachable, null cost | Centre (7.5,3) in W0 |
| Shoot target (14,7.5) | clear; null hits | Through passage |
| Shoot target (14,6) | blocked; W0; t=5/12 | At x=7, y=6.875 |
| Shoot target (7,7.5) | clear | Ends inside open gap |
| Shoot target (7,7) | blocked; W0; t=1 | Endpoint on closed corner |
| Cover centre (10,7.5) | legal; exposure 1, protection 0 | Every face ray crosses open passage |
| Cover centre (10,6) | legal; exposure 0, protection 1 | Every face ray meets W0 |
| Cover centre (7.5,3) | illegal; null metrics | Footprint inside W0 |

These values are derived fixtures for future A checks, not fabricated experiment output.

## 5. Dataset construction and custody

Use NumPy `Generator(PCG64(seed))` with the pinned implementation version and record full state and artifacts. Generate tile assignment without RNG: compute SHA-256 of UTF-8 `p001.v1:tiles:20261011:tx:ty` for each integer tile tx,ty in 0..15; sort by hash hex then tx,ty. First 160 tiles are training, next 32 validation, final 64 final-test. Tile for coordinate p is (min(15,floor(x)), min(15,floor(y))). This holds out areas for all domains together. Publish tile membership/counts before training.

Cover and shooting each receive 15,000 training, 3,000 validation, 6,000 final-test unique requests. Streams have seeds 1101/1102/1103 for cover train/validation/test; 1201/1202/1203 for shooting. Draw x then y as independent uniform integer micrometres 0..16,000,000 inclusive, divide by 1,000,000, keep only the target split tile and domain-valid query. Include geometrically illegal cover locations and obstructed shooting targets rather than filtering to successful examples. Reject duplicates and public fixtures. Freeze the entire final adversarial suite first and exclude its semantic queries from the other sets. A million rejected candidate draws without meeting a count is a generator failure; report it and revise before training rather than reducing quotas silently.

For navigation enumerate every node lexicographically by (i,j), assign by the same centre tile, exclude the four public navigation fixtures and any reserved adversarial nodes. No random node duplicate can enlarge training data. Final correctness covers every final-assigned/reserved node; report exact split counts after generation, not invented counts in Phase 0. Reserved nav challenge nodes are all nodes whose centres are within 0.5 m inclusive of the divider gap rectangle [7,8]×[7,8] or the pocket outer rectangle [11,13]×[2,4], excluding public fixtures. Reserve them for final testing regardless of tile, and remove them from train/validation. This condition uses Euclidean point-to-rectangle distance, only in offline dataset construction.

Final cover adversarial cases use each expanded obstacle edge midpoint and corner, plus/minus 0.000001, 0.001 and 0.01 m along each axis; include the unperturbed point and all combinations of signed axis offsets from that set, retaining domain-valid points. Final shooting adversarial cases use the same recipe on raw obstacle edges/corners, plus target points (14,7+delta), (14,8+delta) and (7,7+delta), (8,8+delta), with delta in {0, +/-0.000001, +/-0.001, +/-0.01}. Also extend every ray from the firing origin through each raw obstacle corner by factors 1.5 and 2; perturb the resulting target by the same axis-offset combinations to test occlusion discontinuities beyond obstacle endpoints. Round derived target coordinates to integer micrometres using ties-to-even before deduplication. Add world edges/corners and their inward/outward perturbations to a separate status suite. Deduplicate and exclude public fixtures. Test adversarial points are exempt from tile assignment; their exact requests must be excluded from all training/validation inputs. Retain labels even when a perturbed point is invalid/out-of-domain; these are status tests rather than missing examples. Record counts per suite and failure stratum.

Boundary strata for ordinary valid points: distance to nearest raw/expanded obstacle edge or corner <=0.01 m; near-boundary >0.01 to <=0.25 m; remaining interior. Nav passage/pocket strata use the reserved rectangles above. These are evaluator labels, never model features. Correctness pools remain distinct from benchmark repetition traces.

Exclusion authority is the [public-fixture registry](experiments/P001/public-fixtures.v1.json), not membership in a test workload. For every navigation node apply this precedence: registered public fixture → excluded; otherwise reserved challenge → final challenge; otherwise unchanged centre-tile assignment → ordinary training/validation/final. These outcomes are disjoint and exhaustive. Challenge points overlapping ordinary final inputs are deduplicated, not counted twice. The [B1 contract](../../docs/P001_B1_CONTRACT.md), [custody v2 successor](experiments/P001/custody.v2.json) and [integrity/regeneration contract](../../docs/P001_B1_D_INTEGRITY_CONTRACT.md) specify enforced identity isolation, atomic publication and independently verified recovery. Historical [custody v1](experiments/P001/custody.v1.json) remains preserved for accepted Gate 1 evidence; v2 explicitly replaces its persistence interpretation for future P001 runs, pending correction review. Missing generations are recorded, invalidated and regenerated under fresh identities; partial/corrupt generations are never repaired or admitted silently. Host-power survival is optional, not a P001 gate. Gate 2 remains closed.

The data preparer can see geometry and the oracle, but the trainer sees only training and validation payloads/labels. The final evaluator owns sealed final labels. B sees frozen inputs only. Freeze and audit exclusions before any training; never inspect final errors to revise weights or selection. Public oracle fixtures cannot count as H4 support.

## 6. Frozen neural candidate and ablation

Plan local CPU training with PyTorch; deploy exported affine weights through NumPy CPU inference. Both measured A/B use Python plus NumPy under the same process/thread conditions; PyTorch is not imported by measured B. Actual dependency versions/lock hashes must be reviewed and recorded before authorized implementation/training. No external model services.

Shared B: input vector [x/8-1, y/8-1, cover_one_hot, navigation_one_hot, shooting_one_hot]. For nav use the start-node centre; for the other domains use candidate/target. Constant origins, destination and actor are scenario metadata. Two dense 64-unit ReLU hidden layers and a 15-unit linear output produce 5,519 parameters, 22,076 bytes in float32 weights/biases before metadata. This is arithmetic from (5*64+64)+(64*64+64)+(64*15+15), not measured memory.

For a fixed domain, this ReLU MLP produces continuous logits as position varies; thresholding induces decision boundaries but does not guarantee alignment with obstacle edges, visibility discontinuities or disconnected topology. Micrometre boundary perturbations, zero unsafe false positives and exact obstruction identity are deliberately demanding. Retain the 5→64→64→15 candidate and every preregistered gate as a falsifiable experiment; failure is a legitimate result, not a reason to relax gates after exposure. Passing sampled tests is not proof of universal correctness and cannot certify geometric safety at unseen coordinates or boundaries.

Output layout: indices 0..1 cover traversability logit and exposure logit; 2..4 nav start traversability logit, reachability logit, and cost raw value; 5..14 shooting clear logit, hit-t logit, and eight obstruction logits in ASCII-sorted ID order [C0,C1,P0,P1,P2,P3,W0,W1]. Sigmoid >=0.5 decodes booleans. Cover exposure=sigmoid, protection=1-exposure if predicted legal, otherwise null. Nav reachable is the decoded reachability AND decoded start traversability AND fixed destination true; cost=16*softplus(raw) when reachable, otherwise null. Cost above 992 is model failure, not clamped. Shooting uses sigmoid for t and argmax ID (ties first sorted ID) when predicted blocked; otherwise null hits. Preserve raw logits for diagnostics. Do not snap cover fractions, route costs or hit t to A values. Non-finite outputs fail before transforms.

H3 ablation: three separate models, each using input (x/8-1,y/8-1), hidden layers 64/64 ReLU, with 2,3,10 outputs respectively and the same decode laws. Combined parameter count is 14,031 (4,482 + 4,547 + 5,002); account for all models, loads and training. These are comparable small baselines with the same per-domain hidden width; no claim of optimal neural architecture follows. Changing widths/precision is a new preregistration.

Five seeds [2101,2102,2103,2104,2105]. Before model construction, seed PyTorch's global generator with the selected seed; use a distinct PyTorch generator initialized to that same seed for row permutations and record both states. Per model/seed train 200 epochs, Adam with lr=0.001, betas=(0.9,0.999), eps=1e-8, weight_decay=0, batches 256, shuffled with the seed-specific generator. Use default linear-layer initialization from the pinned PyTorch version; serialize its initial state hash. Shared training is domain-balanced: each epoch takes M=max(domain training counts) samples per domain, by seeded permutation cycling smaller sets, then shuffles the combined 3M rows; separate models each take M samples of their domain for equal per-domain exposure. Do not duplicate final correctness observations. Enable deterministic algorithms, CPU float32 training, one thread, no augmentation or mixed precision.

Loss is the equally weighted mean of domain mean losses. For each domain add its masked component means with weight 1: BCE-with-logits for legality/reachability/clear predicates; MSE for sigmoid exposure at reference-legal cover points; MSE for cost/16 at reference-reachable nodes; MSE for sigmoid hit t and cross entropy for obstacle ID at reference-blocked shooting queries. Missing masked components contribute zero, never NaN; predicates use all training rows. No final data determine class weights or thresholds. Checkpoints every epoch, no early stopping; select by validation rule in the protocol using normalized errors (cover / (1/17), cost /0.25, hit distance /0.01), with failed or missing predictions treated as infinite. Exact-class gate failures preclude a qualifying candidate. Export parity tolerance is 1e-5 absolute per raw output on validation, with zero decoded predicate/ID disagreement; failure blocks deployment until reviewed. Preserve all candidate losses and checkpoints.

## 7. Quality budgets and rejection

These are preregistered research budgets, not production promises and not observed results. A must pass every public/independent fixture exactly for booleans, IDs and reachability. Numeric oracle checks use 1e-9 m for cost/hit distance and 1e-12 for exposure fractions, justified as binary64 verification budgets far below the micrometre input grid. Ambiguous topology still requires robust predicates.

| Output | B gate on ordinary final + final adversarial sets, separately | Rationale |
| --- | --- | --- |
| Traversability, reachability, line-clear and obstruction ID | Zero false positives for legal/connected/clear outputs; at most 1% false negatives in each domain/stratum with negatives/positives reported. Obstruction ID must match on every reference-blocked point; a predicted-clear point also fails ID correctness. | Any unsafe positive defeats the exact-class research contract. 1% conservative omissions limit loss of useful queries without granting safety; this is a declared usability budget, not a validated gameplay requirement. Strict obstacle identity preserves meaningful obstruction reporting. |
| Cover exposure/protection | Every reference-legal estimate exists; maximum absolute error <=1/17 and mean absolute error <=1/34, including signed underexposure. | At most one of the 17 sampled rays at any point and half a ray on average. This budget is tied to the declared finite metric, not a continuous-silhouette claim. |
| Reachable route cost | Every reference-reachable estimate exists; max absolute error <=0.25 m and mean <=0.125 m; report underestimate count. | One graph edge maximum and half an edge on average. This permits estimation but cannot return a usable path. |
| Blocked first hit | Every reference-blocked estimate exists; max distance error <=0.01 m, mean <=0.005 m, correct obstacle ID. | At most 2% of the 0.5 m actor width, half that on average; sufficient for a research obstruction location, not projectile collision authority. |
| Invalid/out-of-domain/model-failure behavior | Exact status/identity/null laws, zero non-finite or missing valid-query responses | Malformed responses cannot be called numerical approximations. |

A false negative also causes regression failure if the required estimate is absent. Apply all budgets per named stratum with nonzero denominators; report empty strata as not covered, never passed. If a mandatory challenge stratum has no cases, dataset generation/coverage fails before training. No scalar average can mask an unsafe positive or adversarial failure. Even a passing finite test leaves B experimental. Failed B is still evaluated and published; H1-H4 benefits are not accepted when quality fails. No arbitrary speed-up threshold: an improvement requires the corrected interval below 1 plus honest lifetime/memory reporting under the protocol.

## 8. Measurements and work packet

Use the [protocol](../../docs/EXPERIMENT_PROTOCOL.md) without changing its batches [1,32,256], primary mixed batch 32, 30 paired trials and 10,000 resamples. The four named primary inferential latency contrasts (`H2_B_vs_A0`, `H2_B_vs_A1`, `H2_B_vs_A2`, `H3_shared_vs_separate`) each use a two-sided 98.75% interval from a nominal 0.05 family budget; H1 bytes are deterministic and H4 quality/generalization gates are descriptive finite-sample acceptance, with no inferential allocation. Workload seed 3101; pair-order seed 3102; bootstrap seed 3103. Memory includes preprocessing tables, geometry, weights, framework and scratch. Measure preparation/training/export separately and amortized costs at Q={1,1000,1000000}. Machine-readable raw evidence and failure retention are mandatory. No measured artifacts exist now.

After independent review AND explicit implementation authorization:

1. Pin the local dependency lock and environment; implement only common schema/domain plumbing with failure fixtures.
2. Implement A0/A1 and independent checks; verify all fixtures and the full lattice. Freeze graph/world and labels.
3. Generate/audit/freeze train/validation/sealed final inputs and labels; isolate final label access.
4. Implement the specified offline training and isolated B export/inference; prove no A dependency and export parity. Freeze validation-selected checkpoints and decoding. Before releasing final inputs, commit/review hashes of the complete measurement/analysis code, all variants, final performance trace, trial order, runtime settings and selection/failure policies in a final-freeze manifest; calibrate on validation only.
5. Execute one registered final-evaluation campaign: one correctness pass plus every predetermined A0/A1/A2/shared B/separate B performance condition and its 30 paired trials, cold and memory runs. Preserve all errors and incomplete trials. Any post-exposure tuning or changed procedure starts a new revision with a new sealed final set, never an adaptive rerun of this one.
6. Publish raw evidence and H1-H4 decisions; seek independent evidence review before any new experiment.

No runner CLI names are claimed to exist. Implementation may define entrypoint spelling without altering this architecture. Phase 0 review must check geometric conventions, sampling semantics, leakage rules, thresholds, ablation fairness and accounting. Current unresolved operational dependencies: independent reviewer acceptance, separate P001 authorization, and later dependency/hardware lock. There is no missing source preventing Phase 0 completion.
