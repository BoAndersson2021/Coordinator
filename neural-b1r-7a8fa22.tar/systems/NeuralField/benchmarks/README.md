# P001 benchmark obligations

No benchmarks or measurements exist during Phase 0. Implement the [protocol](../../../docs/EXPERIMENT_PROTOCOL.md) only after authorization.

All A variants, shared B and three separate B models use the same accepted contracts, CPU/thread configuration, frozen traces and batches 1/32/256. Primary comparison is the balanced mixed trace with 4,096 queries per domain at batch 32, over 30 paired fresh-process trials. Warm timing includes validation through complete result construction; kernel timings are secondary.

Record cold loading, preparation, labels, training/export, cache population, inference, validation and lifetime amortization separately. Compare to every qualifying A variant; report cache hit rates and construction costs. Record byte inventories and absolute/incremental peak RSS separately from speed runs. Preserve raw trials and corrected uncertainty; failed quality cannot become a performance success.
