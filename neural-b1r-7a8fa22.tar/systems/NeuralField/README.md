# NeuralField

NeuralField is NEURAL's first research system. It studies whether a small learned representation can answer cover, navigation and shooting queries in a fixed level with useful accuracy and lower measured costs.

Status: Phase 0, P001-A, B1-C, [B1-I Gate 1](../../docs/P001_B1_I_WORK_PACKET.md) and [B1-P synthetic evidence](../../docs/evidence/P001_B1_P/v1/README.md) are accepted and merged through `ddeaa76b`. A0/A1 query execution and independent unit checks are present. The [B1-D integrity/regeneration correction](../../docs/P001_B1_D_INTEGRITY_CONTRACT.md) explicitly selects custody v2 for review: missing data can be recorded and regenerated under a new identity; corrupt/partial data cannot be admitted. Strong power-loss survival is optional. The [dataset package](src/dataset/README.md) still pins historical v1; future real-generation provenance/recovery alignment requires separate authorization. Gate 2, neural work, benchmarks and merge remain closed.

From repository root, run `python3 -B systems/NeuralField/src/conventional/run.py --variant A0` (or `A1`). Supply one query JSON object per stdin line; stdout emits one response or a row-indexed malformed-envelope error per line. A separate synthetic-only dataset runner is documented in the dataset package; no real dataset, training or benchmark operation is enabled. A1 preprocessing occurs only with explicit variant selection and is kept in memory.

Read the [governing mission](../../docs/REPOSITORY_INITIALIZATION_MISSION.md), [thesis](../../THESIS.md), [architecture](../../docs/ARCHITECTURE.md), [protocol](../../docs/EXPERIMENT_PROTOCOL.md), and [P001 specification](P001_SPEC.md).

- [Experiment configuration](experiments/P001/README.md): exact world and preregistration.
- [Common contracts](src/common/README.md): query and response schemas.
- [Conventional responsibilities](src/conventional/README.md): oracle and fair A variants.
- [Neural responsibilities](src/neural/README.md): isolated training/export/inference.
- [Test obligations](tests/README.md) and [benchmark obligations](benchmarks/README.md).
- [Results policy](../../results/README.md).

P001 uses static 2D geometry only. Later dynamics, scale, 3D and native integration follow the [roadmap](../../docs/RESEARCH_ROADMAP.md) and need new contracts and authorization. Its grid navigation, finite-ray exposure and ideal projectile assumptions are local to NeuralField/P001.
