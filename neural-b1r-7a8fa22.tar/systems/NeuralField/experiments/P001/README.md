# P001 frozen configuration

This directory contains the real configuration contracts for the proposed first experiment:

- [geometry.v1.json](geometry.v1.json): world, actor, anchors and eight closed obstacles.
- [preregistration.v1.json](preregistration.v1.json): experiment identities, model shapes, sampling budgets, seeds, thresholds and statistical settings.
- [public-fixtures.v1.json](public-fixtures.v1.json): the 11 declared public exclusions, with four navigation fixtures; no labels.
- [custody.v1.json](custody.v1.json): immutable historical contract bound by accepted Gate 1 evidence.
- [custody.v2.json](custody.v2.json): explicit P001 research-integrity successor; isolation and atomic publication retained, universal power-loss survival not required; pending review.
- [integrity.v1.json](integrity.v1.json): recorded loss/invalidation/fresh regeneration, independent recovery and optional production-strength survival profile.
- [B1 contract](../../../../docs/P001_B1_CONTRACT.md) and [integrity correction](../../../../docs/P001_B1_D_INTEGRITY_CONTRACT.md): scientific boundaries, custody prerequisites and publication recovery.
- [P001 specification](../../P001_SPEC.md): semantics and rationale; [protocol](../../../../docs/EXPERIMENT_PROTOCOL.md): evidence custody and measurement.

Phase 0, P001-A, B1-C, Gate 1 implementation and synthetic qualification evidence are accepted and merged. PR #6 contains this reviewed-contract correction proposal only. The Gate 1 implementation still pins v1; real-generation provenance must explicitly bind v2 after review and separate authorization. Gate 2, neural work, benchmarking and merge remain closed. File SHA-256 hashes use canonical bytes; human-readable IDs do not replace hashes. No real datasets, weights or measurements exist, and none may be fabricated as configuration placeholders.
