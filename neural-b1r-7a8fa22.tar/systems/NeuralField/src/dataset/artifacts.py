"""Versioned synthetic artifact contracts; actual P001 exports remain closed."""
from pathlib import Path
import platform
import subprocess

from jsonschema import Draft202012Validator
from common.contract import parse_line
from dataset.codec import canonical, decode, digest, semantic
from dataset.labeling import VerificationFailure
from dataset.recipe import SYSTEM, request
from dataset.audit import audit_splits

VERSION='p001-dataset-artifacts.v2'
FILES=tuple(f'{folder}/{name}.jsonl' for folder in ('training','validation','private') for name in ('queries','labels'))+('private/audit.json','private/provenance.json')
SYNTHETIC_QUOTAS={'training':{'cover':2,'shooting':2,'navigation':2},
                  'validation':{'cover':2,'shooting':2,'navigation':2},
                  'final':{'cover':3,'shooting':4,'navigation':3}}


def synthetic_reservations():
    challenges={semantic(request('cover',(5_740_000,5_740_000))),
                semantic(request('shooting',(5_990_000,5_990_000))),
                semantic(request('navigation',(25,27)))}
    status={semantic(request('shooting',(16_000_001,8_000_000)))}
    return challenges|status,challenges,status


def schema_check(name,value):
    schema=decode((Path(__file__).parent/name).read_bytes())
    Draft202012Validator(schema).validate(value)


def jsonl(rows):
    return b''.join(canonical(row) for row in rows)


def rows(raw):
    result=[]
    for line in raw.splitlines(keepends=True):
        result.append(decode(line))
    return result


def provenance(source_revision, rng):
    root=SYSTEM.parents[1]
    files=[SYSTEM/'experiments/P001'/n for n in ('geometry.v1.json','preregistration.v1.json','public-fixtures.v1.json','custody.v1.json','custody.v2.json','integrity.v1.json')]
    files += [SYSTEM/'src/common'/n for n in ('query.schema.json','response.schema.json')]
    files += [root/'requirements-dataset.txt',root/'requirements-reference.txt']
    source_files=list((SYSTEM/'src/dataset').glob('*.py'))+list((SYSTEM/'src/conventional').glob('*.py'))
    source_files += list((SYSTEM/'src/dataset').glob('*.schema.json'))
    source_files += [SYSTEM/'tests/independent_oracle.py',SYSTEM/'src/common/contract.py']
    return {'artifact_version':VERSION,'kind':'synthetic','source_revision':source_revision,
            'source_claim':'synthetic_fixture_with_exact_file_hashes',
            'contract_hashes':{str(p.relative_to(root)):digest(p.read_bytes()) for p in files},
            'source_hashes':{str(p.relative_to(root)):digest(p.read_bytes()) for p in source_files},
            'python':platform.python_version(),'platform':platform.platform(),'rng':rng,
            'production_qualified':False,'training':None,'inference':None,'benchmark':None}


def build_bundle(splits, labels, recipe, source_revision, rng, reserved=(), challenge_keys=(), status_keys=()):
    quotas={s:dict(__import__('collections').Counter(r['domain'] for r in q)) for s,q in splits.items()}
    if quotas!=SYNTHETIC_QUOTAS:raise VerificationFailure('synthetic-quotas',{'actual':quotas})
    audit=audit_splits(splits,recipe,reserved=reserved,challenge_keys=challenge_keys,status_keys=status_keys,expected_counts=SYNTHETIC_QUOTAS)
    artifact={}
    for split,folder in (('training','training'),('validation','validation'),('final','private')):
        artifact[folder+'/queries.jsonl']=jsonl(splits[split]);artifact[folder+'/labels.jsonl']=jsonl(labels[split])
    private_audit=dict(audit,reserved_keys=[k.decode().strip() for k in sorted(reserved)],
                       challenge_keys=[k.decode().strip() for k in sorted(challenge_keys)],
                       status_keys=[k.decode().strip() for k in sorted(status_keys)])
    artifact['private/audit.json']=canonical(private_audit)
    artifact['private/provenance.json']=canonical(provenance(source_revision,rng))
    manifest={'artifact_version':VERSION,'kind':'synthetic','source_revision':source_revision,
              'files':{p:{'sha256':digest(raw),'bytes':len(raw)} for p,raw in artifact.items()},
              'counts':audit['counts'],'quotas':quotas,'production_qualified':False}
    schema_check('manifest.v2.schema.json',manifest)
    artifact['manifest.json']=canonical(manifest)
    return artifact


def verify_bundle(artifact, recipe, labeler):
    if set(artifact)!=set(FILES)|{'manifest.json'}:raise VerificationFailure('artifact-closure',{})
    manifest=decode(artifact['manifest.json']);schema_check('manifest.v2.schema.json',manifest)
    for name in FILES:
        if manifest['files'].get(name)!={'sha256':digest(artifact[name]),'bytes':len(artifact[name])}:
            raise VerificationFailure('artifact-hash',{'artifact':name})
    metadata=decode(artifact['private/provenance.json'])
    schema_check('provenance.v2.schema.json',metadata)
    if metadata.get('kind')!='synthetic' or metadata.get('source_revision')!=manifest['source_revision'] or metadata.get('production_qualified') is not False:
        raise VerificationFailure('provenance',{})
    current=provenance(metadata['source_revision'],metadata['rng'])
    if any(metadata[k]!=current[k] for k in ('contract_hashes','source_hashes','python')):
        raise VerificationFailure('provenance-mismatch',{})
    splits={}
    for split,folder in (('training','training'),('validation','validation'),('final','private')):
        queries=rows(artifact[folder+'/queries.jsonl']);labels=rows(artifact[folder+'/labels.jsonl'])
        if len(queries)!=len(labels):raise VerificationFailure('missing-labels',{'split':split})
        if len(queries)>64:raise VerificationFailure('synthetic-size-limit',{})
        for query,label in zip(queries,labels):labeler.verify(query,supplied=label)
        splits[split]=queries
    recorded=decode(artifact['private/audit.json'])
    def keys(name):return {v.encode()+b'\n' for v in recorded[name]}
    if (keys('reserved_keys'),keys('challenge_keys'),keys('status_keys'))!=synthetic_reservations():
        raise VerificationFailure('synthetic-reservation-drift',{})
    regenerated_states=[]
    for split in ('training','validation','final'):
        for domain in ('cover','shooting'):
            expected,state=recipe.sample_synthetic(domain,split,2,reserved=keys('reserved_keys'))
            recorded_rows=[r for r in splits[split] if r['domain']==domain][:2]
            if list(map(semantic,recorded_rows))!=list(map(semantic,expected)):
                raise VerificationFailure('seed-stream-mismatch',{'domain':domain,'split':split})
            regenerated_states.append(dict(state,domain=domain,split=split))
    if metadata['rng']!=regenerated_states:raise VerificationFailure('rng-provenance',{})
    audit=audit_splits(splits,recipe,reserved=keys('reserved_keys'),challenge_keys=keys('challenge_keys'),
                       status_keys=keys('status_keys'),expected_counts=manifest['quotas'])
    if any(recorded[k]!=audit[k] for k in audit) or manifest['counts']!=audit['counts']:
        raise VerificationFailure('audit-receipt',{})
    return manifest
