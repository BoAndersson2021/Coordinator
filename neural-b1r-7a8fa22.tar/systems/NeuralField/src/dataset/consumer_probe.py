"""Synthetic denied-read checks under the eventual restricted consumer profile."""
import ctypes
import errno
import json
import os
from pathlib import Path
import sys


def denied(path,write=False):
    try:
        with open(path,'r+b' if write else 'rb') as stream:stream.read(1)
    except OSError as error:
        if error.errno in (errno.EPERM,errno.EACCES,errno.EROFS,errno.ENOENT,errno.ENOTDIR,errno.EISDIR):return True
        raise
    return False


def probe(config):
    private=config['private_paths']
    checks={p:denied(p) for p in private}
    checks.update({p+'/../'+Path(p).name:denied(p+'/../'+Path(p).name) for p in private})
    # Actual aliases exist only in writable private tmpfs and must not grant host path access.
    for index,path in enumerate(private):
        alias=Path('/tmp')/('alias-'+str(index));alias.symlink_to(path);checks[str(alias)]=denied(alias)
    checks['private-host-proc']=not Path('/proc/2/root').exists()
    fd_leak=any(int(p.name)>2 for p in Path('/proc/self/fd').iterdir() if p.name.isdigit() and p.exists())
    status=Path('/proc/self/status').read_text()
    fields=dict(line.split(':',1) for line in status.splitlines() if ':' in line)
    caps=int(fields['CapEff'].strip(),16);bounding=int(fields['CapBnd'].strip(),16)
    nnp=int(fields['NoNewPrivs'].strip())
    visible=Path('/data/sentinel.txt')
    checks['approved-read']=visible.read_bytes()==b'synthetic-approved\n'
    checks['approved-write-denied']=denied(visible,write=True)
    checks['label-alias-denied']=denied('/data/final-labels')
    if config['role']=='inference':checks['released-input-pipe']=sys.stdin.buffer.read()==b'synthetic-released-input\n'
    return {'role':config['role'],'uid':os.getuid(),'gid':os.getgid(),'groups':os.getgroups(),
            'cap_eff':caps,'cap_bnd':bounding,'no_new_privs':nnp,'fd_leak':fd_leak,
            'mountinfo':Path('/proc/self/mountinfo').read_text(),'checks':checks,
            'passed':all(checks.values()) and not fd_leak and caps==bounding==0 and nnp==1}


if __name__=='__main__':
    print(json.dumps(probe(json.loads(sys.argv[1])),sort_keys=True,separators=(',',':')))
