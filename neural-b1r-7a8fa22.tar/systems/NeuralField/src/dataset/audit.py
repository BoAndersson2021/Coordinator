"""Split auditing independently derives membership; no neural feature fitting."""
from collections import Counter
from fractions import Fraction
import hashlib
import itertools
import math

from common.contract import Contract
from dataset.codec import semantic
from dataset.labeling import VerificationFailure


def independent_tiles():
    coordinates=list(itertools.product(range(16),repeat=2))
    coordinates.sort(key=lambda p:(hashlib.sha256(('p001.v1:tiles:20261011:%d:%d'%p).encode()).hexdigest(),p))
    return {p:'training' if k<160 else 'validation' if k<192 else 'final' for k,p in enumerate(coordinates)}


def nav_assignment(node, public):
    # Metre Fractions rather than the generator's quarter-metre integer predicate.
    if tuple(node) in public:return 'public'
    x,y=(Fraction(n+1,4) for n in node)
    for x0,x1,y0,y1 in ((7,8,7,8),(11,13,2,4)):
        nx=min(max(x,x0),x1);ny=min(max(y,y0),y1)
        if (x-nx)**2+(y-ny)**2<=Fraction(1,4):return 'challenge'
    return independent_tiles()[int(x),int(y)]


def stratum(row, obstacles):
    if row['domain']=='navigation':
        point=tuple((n+1)*250_000 for n in row['input']['start_node'])
        for name,(x0,x1,y0,y1) in (('passage',(7,8,7,8)),('pocket',(11,13,2,4))):
            x,y=(Fraction(n,1_000_000) for n in point)
            if (max(x0-x,0,x-x1))**2+(max(y0-y,0,y-y1))**2<=Fraction(1,4):return name
        return 'interior'
    point=tuple(round(n*1_000_000) for n in row['input']['candidate_m' if row['domain']=='cover' else 'target_m'])
    half=250_000 if row['domain']=='cover' else 0
    distances=[]
    for raw in obstacles:
        x0,y0,x1,y1=raw;x0-=half;y0-=half;x1+=half;y1+=half
        # Distance to each finite edge segment, including corners and interior points.
        for a,b in (((x0,y0),(x1,y0)),((x1,y0),(x1,y1)),((x1,y1),(x0,y1)),((x0,y1),(x0,y0))):
            closest=(min(max(point[0],min(a[0],b[0])),max(a[0],b[0])),
                     min(max(point[1],min(a[1],b[1])),max(a[1],b[1])))
            distances.append(sum((n-c)**2 for n,c in zip(point,closest)))
    distance=min(distances,default=float('inf'))
    return 'boundary' if distance<=10_000**2 else 'near_boundary' if distance<=250_000**2 else 'interior'


def audit_splits(splits, recipe, *, reserved=(), expected_counts=None, challenge_keys=(), status_keys=()):
    """Exact semantic disjointness and membership, including retained status queries."""
    if set(splits)!={'training','validation','final'}:raise VerificationFailure('split-names',{})
    seen=set();reserved=set(reserved);challenge=set(challenge_keys);status=set(status_keys)
    if not challenge|status<=reserved:raise VerificationFailure('undeclared-reservation',{})
    tiles=independent_tiles();counts={};domain_counts={};strata=Counter();contract=Contract()
    public_nodes={tuple(f['input']['start_node']) for f in recipe.data['public-fixtures.v1.json']['fixtures'] if f['domain']=='navigation'}
    boxes=[tuple(round(v*1_000_000) for v in o['min']+o['max']) for o in recipe.data['geometry.v1.json']['obstacles']]
    for split,rows in splits.items():
        counts[split]=len(rows);domains=Counter()
        for row in rows:
            key=semantic(row)
            if key in seen or key in recipe.public:raise VerificationFailure('duplicate-or-public',{'split':split,'request':row})
            if key in reserved and split!='final':raise VerificationFailure('reserved-leak',{'split':split,'request':row})
            validation=contract.validate(row)
            if validation.error is not None:
                if split!='final' or key not in status:raise VerificationFailure('unexpected-invalid',{'request':row})
                strata[split+':'+row['domain']+':status:'+validation.error['status']]+=1
            elif row['domain']=='navigation':
                assigned=nav_assignment(row['input']['start_node'],public_nodes)
                if assigned=='public' or ('final' if assigned=='challenge' else assigned)!=split:
                    raise VerificationFailure('navigation-membership',{'request':row,'split':split})
                strata[split+':'+row['domain']+':'+stratum(row,boxes)]+=1
            else:
                point=row['input']['candidate_m' if row['domain']=='cover' else 'target_m']
                tile=tuple(min(15,math.floor(n)) for n in point)
                if key not in challenge and tiles[tile]!=split:raise VerificationFailure('spatial-membership',{'request':row,'split':split})
                strata[split+':'+row['domain']+':'+stratum(row,boxes)]+=1
            seen.add(key);domains[row['domain']]+=1
        domain_counts[split]=dict(domains)
    if expected_counts is not None and domain_counts!=expected_counts:raise VerificationFailure('quotas',{'actual':domain_counts,'expected':expected_counts})
    if not reserved<=seen:raise VerificationFailure('missing-reserved',{'missing_count':len(reserved-seen)})
    return {'counts':counts,'domain_counts':domain_counts,'strata':dict(strata),'disjoint':True,'passed':True}
