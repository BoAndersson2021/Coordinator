# Dataset foundation — Gate 1

Authorized scope and stopping point: [B1-I work packet](../../../../docs/P001_B1_I_WORK_PACKET.md). Governing [B1-C contract](../../../../docs/P001_B1_CONTRACT.md) and its machine-readable contracts remain unchanged. This package is custodian-side code; it is never a neural runtime dependency.

- [recipe.py](recipe.py): frozen generation primitives; full registered preparation is behind the closed Gate 2 check. Gate 1's public sampler permits only 1..16 rows, and its integration bundle is a fixed 22-row synthetic case with toy challenge geometry. No complete canonical final suite is exported.
- [labeling.py](labeling.py): A0/A1 agreement and the existing independent polygon/Dijkstra checker. Every supplied label is checked, including first-hit identity and distance tolerance; disagreements retain input/expected/actual evidence.
- [audit.py](audit.py): separate spatial hashing and Fraction-based navigation reservation checks, exact integer boundary strata, uniqueness, exclusions, quotas and retained status cases.
- [artifacts.py](artifacts.py): canonical queries/labels, exact file closure/hashes, source/dependency/RNG provenance and schema enforcement. Synthetic manifests and completion receipts cannot represent production qualification.
- [storage.py](storage.py): a private temporary SyntheticStore, verified immutable commit, no-overwrite renameat2, fsync, quarantine and admission/recovery. No production store is constructible; the production entrypoint rejects. The synthetic completion state is SYNTHETIC COMMITTED, not PUBLISHED / SEALED authority.
- [custody.py](custody.py), [worker](custody_worker.py), [probe](consumer_probe.py): synthetic Linux profile validation and restricted launches. Root-owned supplied profile/resources and existing named identities are required. No account creation, sudo fallback, host installation or privileged launch has been performed.

- [authority.py](authority.py): unconditional Gate 2 closure. CLI flags, environment values and receipts cannot open real generation/publication or final-input release.

All configured resource roots must be pairwise disjoint: jail parent, training/inference views, runtime and private sentinel paths. Identical paths and either ancestry direction are rejected before host checks or launch; v1 contracts no nested-root exception. Disjoint siblings sharing a parent, including paths with merely matching lexical prefixes, remain valid.

Synthetic schemas: [manifest](manifest.schema.json), [provenance](provenance.schema.json), [completion](completion.schema.json), [failure](failure.schema.json), [launch profile](launch-profile.schema.json) and [qualification](qualification.schema.json). They are configuration contracts, not dataset or enforcement evidence.

## Reproduce synthetic tests

Use the existing pinned [reference dependencies](../../../../requirements-reference.txt) plus [NumPy lock](../../../../requirements-dataset.txt). From repository root:

```sh
python3 -B -m unittest discover -s systems/NeuralField/tests -p 'test_dataset.py' -v
```

The portable tests explicitly inject a simulation-test-only filesystem backend. Native tests run only on Linux; macOS skips them. No simulation backend is available through the CLI or production entrypoint. All generated queries/labels stay in ephemeral test stores; committed receipts contain outcomes/hashes, not final records.

On Linux, `python3 -B systems/NeuralField/src/dataset/run.py synthetic --root /tmp/neural-synthetic-demo` executes the fixed synthetic bundle with native atomic publication. The root must be a private temporary directory. Other operations reject before output access. This command is a synthetic integration test, not production generation or a benchmark.

Actual deployment qualification must use the documented profile and supplied synthetic sentinel resources under real nf-custodian/nf-train/nf-infer identities. Profile/runtime changes invalidate previous evidence. Final input streaming and production activation remain closed.

## Custody v2 runtime

[B1-R implementation](../../../../docs/P001_B1_R_IMPLEMENTATION.md) selects custody v2 and integrity v1 with pinned hashes. Current bounded artifacts use [manifest v2](manifest.v2.schema.json), [provenance v2](provenance.v2.schema.json) and [completion v2](completion.v2.schema.json). V1 schemas and accepted qualification evidence retain their original identity.

[Private catalog](trust.py) uses closed [inventory](catalog.schema.json), [registration](registration.schema.json) and [loss](loss.schema.json) contracts. A store-local interprocess lock serializes registration, publication, recovery, invalidation and admission. Missing/corrupt/uncommitted trust closes authority; recovery never imports a candidate's self-manifest. Registered missing generations are retired; explicit synthetic regeneration uses fresh identity and private lineage. Source replay must match the original exact provenance.

Linux-only disposable examples: `python3 -B systems/NeuralField/src/dataset/run.py synthetic --root /tmp/nf-synthetic --generation synthetic-one`; `synthetic-recover --root /tmp/nf-synthetic`; `synthetic-regenerate --root /tmp/nf-synthetic --retired synthetic-one --generation synthetic-two` after independently recorded loss. These operations remain bounded to 22 synthetic requests, temporary roots and no production qualification. CLI output uses the custody public allowlist; detailed diagnostics remain private.
