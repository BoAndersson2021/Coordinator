"""Canonical artifact encoding and semantic identities, without spatial truth."""
import copy
import hashlib
import json
from common.contract import finite_json, parse_line


def canonical(value):
    if not finite_json(value):
        raise ValueError("non-finite/non-JSON artifact")
    return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def decode(raw):
    value=parse_line(raw.decode('utf-8'))
    if canonical(value)!=raw:
        raise ValueError('noncanonical artifact')
    return value


def semantic(request):
    """Ignore query ID; normalize valid coordinate quanta and integer indices."""
    value=copy.deepcopy({k:request[k] for k in ('schema_version','snapshot_id','domain','input')})
    if not finite_json(value):raise ValueError('invalid semantic payload')
    for key in ('candidate_m','target_m','threat_m','firing_m'):
        if key in value['input']:
            coords=value['input'][key]
            if any(type(n) not in (int,float) for n in coords):raise ValueError('coordinate type')
            value['input'][key]=[round(n*1_000_000)/1_000_000 if abs(n-round(n*1_000_000)/1_000_000)<=1e-12 else n for n in coords]
    for key in ('start_node','destination_node'):
        if key in value['input']:
            coords=value['input'][key]
            if any(type(n) not in (int,float) or int(n)!=n for n in coords):raise ValueError('index type')
            value['input'][key]=[int(n) for n in coords]
    return canonical(value)
