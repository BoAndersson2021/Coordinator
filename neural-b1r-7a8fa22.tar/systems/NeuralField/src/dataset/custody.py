"""Linux synthetic qualification launcher. Never provisions accounts or opens Gate 2."""
import os
from itertools import combinations
from pathlib import Path
import platform
import pwd
import stat
import subprocess
import sys

from dataset.artifacts import schema_check
from dataset.codec import canonical, decode, digest
from dataset.authority import require_gate2


class CustodyFailure(RuntimeError):pass


def launcher_hash(directory=None):
    directory=Path(__file__).parent if directory is None else Path(directory)
    return digest(b''.join((name+'\n').encode()+ (directory/name).read_bytes()
                           for name in ('custody_worker.py','consumer_probe.py')))


def validate_profile(profile, *, check_host=False):
    schema_check('launch-profile.schema.json',profile)
    identities=profile['identities']
    if len({i['uid'] for i in identities.values()})!=3 or len({i['gid'] for i in identities.values()})!=3:
        raise CustodyFailure('distinct non-root UID/GID identities required')
    paths=[profile[k] for k in ('jail_parent','training_view','inference_view','runtime')]+profile['private_paths']
    if any(str(Path(p))!=p or '..' in Path(p).parts or not Path(p).is_absolute() for p in paths):raise CustodyFailure('profile path')
    # Every configured resource root is separate in v1; no nested-root exception is contracted.
    # Check before code/host admission so invalid views cannot reach any privileged launch.
    for left,right in combinations(map(Path,paths),2):
        if left.is_relative_to(right) or right.is_relative_to(left):
            raise CustodyFailure('overlapping profile roots: '+str(left)+' / '+str(right))
    if profile['code_hash']!=launcher_hash():raise CustodyFailure('launcher code hash mismatch')
    if check_host:
        if sys.platform!='linux' or os.geteuid()!=0:raise CustodyFailure('preprovided Linux administrator execution required; no sudo fallback')
        for role,name in (('custodian','nf-custodian'),('training','nf-train'),('inference','nf-infer')):
            entry=pwd.getpwnam(name)
            if (entry.pw_uid,entry.pw_gid)!=(identities[role]['uid'],identities[role]['gid']):raise CustodyFailure('host identity mismatch')
        for path in paths:
            p=Path(path)
            if p.is_symlink() or not p.exists():raise CustodyFailure('preprovided resource missing/alias')
            if p.stat().st_mode&0o022:raise CustodyFailure('writable host resource')
        jail=Path(profile['jail_parent'])
        if jail.stat().st_uid!=0 or stat.S_IMODE(jail.stat().st_mode)!=0o700:raise CustodyFailure('jail parent must be administrator-owned mode 0700')
        # Runtime must contain only trusted, root-owned launcher/probe code; mount sources cannot be mutable by consumers.
        runtime=Path(profile['runtime'])
        for p in [runtime]+list(runtime.rglob('*')):
            info=p.lstat()
            if info.st_uid!=0 or info.st_mode&0o022 or p.is_symlink():raise CustodyFailure('untrusted runtime')
        for view in ('training_view','inference_view'):
            for p in [Path(profile[view])]+list(Path(profile[view]).rglob('*')):
                info=p.lstat()
                if info.st_uid!=identities['custodian']['uid'] or info.st_mode&0o022 or p.is_symlink() or (p.is_file() and info.st_nlink!=1):raise CustodyFailure('consumer-owned/aliased view')
        for path in profile['private_paths']:
            p=Path(path);info=p.stat()
            if info.st_uid!=identities['custodian']['uid'] or info.st_mode&0o077:raise CustodyFailure('private ownership/mode')
    return profile


def read_profile(path):
    p=Path(path);info=p.lstat()
    if stat.S_ISLNK(info.st_mode) or info.st_uid!=0 or stat.S_IMODE(info.st_mode)!=0o600:raise CustodyFailure('profile must be root-owned mode 0600')
    return validate_profile(decode(p.read_bytes()),check_host=True)


def launch_probe(profile_path, role):
    if role not in ('training','inference'):raise CustodyFailure('consumer role')
    profile=read_profile(profile_path)
    worker=Path(profile['runtime'])/'custody_worker.py'
    if launcher_hash(worker.parent)!=profile['code_hash']:raise CustodyFailure('deployed worker/probe mismatch')
    argv=['/usr/bin/unshare','--mount','--pid','--fork','--mount-proc','--propagation','private',
          '/usr/bin/python3','-I',str(worker),str(Path(profile_path).resolve()),role]
    streams={'input':b'synthetic-released-input\n'} if role=='inference' else {'stdin':subprocess.DEVNULL}
    result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                          env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'},close_fds=True,timeout=60,**streams)
    if result.returncode:raise CustodyFailure('consumer profile failed: '+result.stderr.decode(errors='replace')[:2000])
    receipt=decode(result.stdout)
    if receipt.get('passed') is not True or receipt.get('role')!=role:raise CustodyFailure('probe admission')
    expected=profile['identities'][role]
    if receipt.get('uid')!=expected['uid'] or receipt.get('gid')!=expected['gid'] or receipt.get('groups')!=[]:
        raise CustodyFailure('effective identity mismatch')
    if receipt.get('no_new_privs')!=1 or receipt.get('cap_eff')!=0 or receipt.get('cap_bnd')!=0 or receipt.get('fd_leak') is not False:
        raise CustodyFailure('effective process restrictions')
    return receipt


def qualification(profile_path, source_revision):
    profile=read_profile(profile_path)
    checks={role:launch_probe(profile_path,role) for role in ('training','inference')}
    # Administrator reads are not substituted for custodian identity reads.
    uid=profile['identities']['custodian']['uid'];gid=profile['identities']['custodian']['gid']
    command=['/usr/bin/setpriv','--reuid',str(uid),'--regid',str(gid),'--clear-groups','--no-new-privs',
             '/usr/bin/python3','-I','-c','import pathlib,sys; [pathlib.Path(p).read_bytes() for p in sys.argv[1:]]',*profile['private_paths']]
    result=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True,timeout=30)
    if result.returncode:raise CustodyFailure('custodian sentinel reads failed')
    receipt={'qualification_version':'p001-linux-qualification.v1','kind':'synthetic','production_qualified':False,
             'profile_sha256':digest(canonical(profile)),'host':platform.node(),'kernel':platform.release(),
             'identity_isolation':True,'filesystem_durability':'not_power_loss_qualified',
             'checks':checks,'source_revision':source_revision}
    schema_check('qualification.schema.json',receipt)
    return receipt


def production_launch(*, authorization=None, qualification=None):
    require_gate2(authorization=authorization,qualification=qualification)
