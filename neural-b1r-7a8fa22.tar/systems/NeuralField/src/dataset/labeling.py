"""Custodian-side A0/A1 and separately written polygon/Dijkstra checks."""
import copy
import importlib.util
import math
from types import MappingProxyType

from common.contract import Contract, finite_json
from conventional.reference import Reference
from dataset.codec import canonical, digest
from dataset.recipe import SYSTEM


class VerificationFailure(RuntimeError):
    def __init__(self, stage, evidence):
        self.stage=stage;self.evidence=dict(evidence,stage=stage)
        super().__init__('verification failure: '+stage)


def independent_checker():
    path=SYSTEM/'tests/independent_oracle.py'
    spec=importlib.util.spec_from_file_location('neuralfield_independent_label_checker',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


class Labeler:
    def __init__(self, a0=None, a1=None, checker=None):
        self.a0=Reference(variant='A0') if a0 is None else a0
        self.a1=Reference(variant='A1') if a1 is None else a1
        self.checker=independent_checker() if checker is None else checker
        self.contract=Contract();self._navigation=None

    def expected(self, request):
        validation=self.contract.validate(request)
        if validation.error is not None:return validation.error
        query=validation.query
        if query.domain=='cover':output=self.checker.cover_truth(query.point_um)
        elif query.domain=='shooting':output=self.checker.shooting_truth(query.point_um)
        else:
            if self._navigation is None:
                legal,graph,distance=self.checker.navigation_truth()
                self._navigation=(MappingProxyType(legal),MappingProxyType(distance))
            legal,distance=self._navigation;n=query.start_node
            output={'start_traversable':legal[n],'destination_traversable':legal[(55,29)],
                    'reachable':n in distance,'route_cost_m':distance[n]/4 if n in distance else None}
        return self.contract.response(query,output)

    @staticmethod
    def agrees(actual, expected, request):
        if type(actual) is not dict or not finite_json(actual) or set(actual)!=set(expected):return False
        if any(actual[k]!=expected[k] for k in expected if k!='output'):return False
        if expected['output'] is None:return actual['output'] is None
        if type(actual['output']) is not dict or set(actual['output'])!=set(expected['output']):return False
        for key,value in expected['output'].items():
            other=actual['output'][key]
            if value is None or type(value) in (bool,str):
                if type(other) is not type(value) or other!=value:return False
            else:
                if type(other) not in (int,float) or not math.isfinite(other):return False
                tolerance=1e-12 if 'fraction' in key else 1e-9
                scale=1
                if key=='first_hit_t':
                    a=request['input']['firing_m'];b=request['input']['target_m']
                    scale=math.hypot(a[0]-b[0],a[1]-b[1])
                if abs(other-value)*scale>tolerance:return False
        return True

    def verify(self, request, supplied=None):
        raw=canonical(request)
        expected=self.expected(copy.deepcopy(request))
        answers=[self.a0.handle(copy.deepcopy(request)),self.a1.handle(copy.deepcopy(request))]
        if supplied is not None:answers.append(supplied)
        for name,answer in zip(('A0','A1','artifact'),answers):
            if (type(answer) is not dict or answer.get('status')=='model_failure' or not self.contract._response.is_valid(answer)
                    or not self.agrees(answer,expected,request)):
                raise VerificationFailure('label-'+name,{'snapshot_id':'p001-static-v1',
                    'geometry_sha256':self.a0.snapshot.sha256,'request':copy.deepcopy(request),
                    'expected':expected,'actual':answer})
        if canonical(request)!=raw:raise VerificationFailure('request-mutation',{'request_hash':digest(raw)})
        return answers[0]
