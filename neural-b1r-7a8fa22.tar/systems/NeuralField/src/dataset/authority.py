"""Gate 1 has no production capability. Receipts never grant user authority."""
class AuthorityClosed(RuntimeError):
    pass


def require_gate2(*, authorization=None, qualification=None):
    # Deliberately unconditional. Enabling Gate 2 needs separate authorization and review.
    raise AuthorityClosed("P001-B1-I Gate 2 is closed: real generation/publication/input exposure prohibited")
