"""Reduced synthetic end-to-end integration. No real artifact entrypoint."""
from dataset.artifacts import build_bundle
from dataset.authority import require_gate2
from dataset.codec import semantic
from dataset.recipe import Recipe, request, challenge_requests
from dataset.labeling import Labeler


def synthetic_bundle(source_revision, recipe=None, labeler=None):
    recipe=Recipe() if recipe is None else recipe;labeler=Labeler() if labeler is None else labeler
    splits={s:[] for s in ('training','validation','final')};rng=[]
    # Toy challenge geometry only; never construct/export the complete canonical final suite.
    toy=((6_000_000,6_000_000,6_500_000,6_500_000),)
    challenges=[challenge_requests(recipe,d,toy)[0] for d in ('cover','shooting')]
    node=next((i,j) for i in range(63) for j in range(63) if recipe.nav_class((i,j))=='challenge')
    challenges.append(request('navigation',node))
    status=request('shooting',(16_000_001,8_000_000))
    reserved={semantic(r) for r in challenges+[status]}
    for split in splits:
        for domain in ('cover','shooting'):
            rows,state=recipe.sample_synthetic(domain,split,2,reserved=reserved)
            splits[split].extend(rows);rng.append(dict(state,domain=domain,split=split))
        nodes=((i,j) for i in range(63) for j in range(63) if recipe.nav_class((i,j))==split)
        splits[split].extend(request('navigation',next(nodes)) for _ in range(2))
    splits['final'].extend(challenges+[status])
    labels={s:[labeler.verify(q) for q in rows] for s,rows in splits.items()}
    return build_bundle(splits,labels,recipe,source_revision,rng,reserved=reserved,
                        challenge_keys={semantic(q) for q in challenges},status_keys={semantic(status)})


def production_bundle(*, authorization=None, qualification=None):
    require_gate2(authorization=authorization,qualification=qualification)
