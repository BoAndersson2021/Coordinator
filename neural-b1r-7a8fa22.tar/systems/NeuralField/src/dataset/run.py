"""Gate 1 synthetic runner; production commands reject before output-path access."""
import argparse
from pathlib import Path
import subprocess
import sys

SRC=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(SRC))
from dataset.authority import require_gate2, AuthorityClosed
from dataset.codec import canonical
from dataset.recipe import Recipe
from dataset.labeling import Labeler
from dataset.pipeline import synthetic_bundle
from dataset.storage import SyntheticStore


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=('synthetic','synthetic-recover','synthetic-regenerate','production','release-final-inputs'))
    parser.add_argument('--root',required=True)
    parser.add_argument('--gate2-authorization')
    parser.add_argument('--qualification')
    parser.add_argument('--generation',default='synthetic-demo')
    parser.add_argument('--retired')
    args=parser.parse_args()
    if args.operation in ('production','release-final-inputs'):require_gate2(authorization=args.gate2_authorization,qualification=args.qualification)
    revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SRC.parents[2],text=True).strip()
    recipe=Recipe();labeler=Labeler()
    store=SyntheticStore(args.root,recipe,labeler);survivors=store.recover()
    if args.operation=='synthetic-recover':receipts=survivors
    elif args.operation=='synthetic-regenerate':receipts=[store.regenerate(args.retired,args.generation)]
    else:receipts=[store.publish(args.generation,synthetic_bundle(revision,recipe,labeler))]
    allowed={'generation_id','contract_versions','source_revision','counts','verification_pass','custody_pass'}
    public=[dict({k:r[k] for k in allowed},artifact_hashes={'manifest':r['manifest_sha256']},receipt_hash=__import__('hashlib').sha256(canonical(r)).hexdigest()) for r in receipts]
    sys.stdout.buffer.write(canonical(public))


if __name__=='__main__':
    try:main()
    except Exception as error:
        print('Gate 2 is closed' if isinstance(error,AuthorityClosed) else type(error).__name__+': operation rejected; inspect private store diagnostics',file=sys.stderr);sys.exit(1)
