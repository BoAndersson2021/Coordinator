# Conventional implementation responsibilities

Independently executable A under [P001](../../P001_SPEC.md), authorized only by [P001-A](../../../../docs/P001_A_WORK_PACKET.md). [geometry.py](geometry.py) loads the immutable canonical snapshot and exact predicates; [reference.py](reference.py) evaluates A0; [navigation.py](navigation.py) explicitly constructs A1; [run.py](run.py) provides JSON-lines execution.

A0 evaluates deterministic geometry and per-query BFS without graph preprocessing. A1 stores immutable node legality, edges and single-destination distances; cover/shooting retain direct reference evaluation. No A2 cache or performance/batching optimization is implemented in P001-A. Future comparisons must account for preprocessing and storage and include compact representations; this stage makes no speed or memory-benefit claim.

Reference labels require analytic fixtures and independently written checks. Geometry/world state is authoritative; a reference implementation bug invalidates its labels. Shared code must not expose these computations to B. Offline label generation is separately timed and access-controlled.
