"""Explicit A1 preprocessing, added after the independently verified A0 gate."""
from collections import deque
from dataclasses import dataclass

from conventional.geometry import actor_legal, cardinal_edge_legal
from conventional.reference import neighbors, node_point


@dataclass(frozen=True)
class NavigationTable:
    snapshot_id: str
    geometry_hash: str
    legality: tuple
    adjacency: tuple
    distances: tuple
    destination_index: int


def index(node):
    return node[0]*63+node[1]


def build_table(snapshot):
    nodes=tuple((i,j) for i in range(63) for j in range(63))
    legality=tuple(actor_legal(snapshot,node_point(n)) for n in nodes)
    adjacency=tuple(tuple(index(other) for other in neighbors(n)
                         if legality[index(n)] and legality[index(other)] and
                         cardinal_edge_legal(snapshot,node_point(n),node_point(other))) for n in nodes)
    distances=[-1]*len(nodes)
    destination=index(snapshot.destination)
    if legality[destination]:
        distances[destination]=0
        queue=deque([destination])
        while queue:
            n=queue.popleft()
            for other in adjacency[n]:
                if distances[other] < 0:
                    distances[other]=distances[n]+1
                    queue.append(other)
    return NavigationTable(snapshot.version,snapshot.sha256,legality,adjacency,tuple(distances),destination)


def navigation_a1(table,start):
    i=index(start)
    reachable=table.distances[i]>=0
    return {"start_traversable":table.legality[i],"destination_traversable":table.legality[table.destination_index],
            "reachable":reachable,"route_cost_m":table.distances[i]/4 if reachable else None}
