"""Immutable canonical geometry; integer topology and exact slab parameters."""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
import hashlib
import json
from pathlib import Path
from typing import Tuple

GEOMETRY_HASH = "37759af786f658d89eef887add98ce47d95d0c450a877a70a0c3002addb68f1b"
Point = Tuple[int, int]


@dataclass(frozen=True)
class Rectangle:
    id: str
    xmin: int
    ymin: int
    xmax: int
    ymax: int

    def expand(self, half_extent):
        return Rectangle(self.id, self.xmin-half_extent, self.ymin-half_extent,
                         self.xmax+half_extent, self.ymax+half_extent)


@dataclass(frozen=True)
class Snapshot:
    version: str
    sha256: str
    obstacles: Tuple[Rectangle, ...]
    expanded: Tuple[Rectangle, ...]
    half_extent: int
    world_max: int
    origin: Point
    destination: Tuple[int, int]


def load_snapshot(path=None):
    if path is None:
        path = Path(__file__).resolve().parents[2] / "experiments/P001/geometry.v1.json"
    raw = Path(path).read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != GEOMETRY_HASH:
        raise ValueError("canonical geometry hash mismatch: " + actual)
    data = json.loads(raw)
    rectangles = tuple(Rectangle(o["id"], *(round(n*1_000_000) for n in
                       (o["min"][0], o["min"][1], o["max"][0], o["max"][1])))
                       for o in data["obstacles"])
    half = round(data["actor"]["half_extent_m"] * 1_000_000)
    return Snapshot(data["snapshot_id"], actual, rectangles, tuple(r.expand(half) for r in rectangles),
                    half, 16_000_000, (2_000_000, 7_500_000), tuple(data["navigation"]["destination_node"]))


def actor_legal(snapshot, point):
    x, y = point
    half, limit = snapshot.half_extent, snapshot.world_max - snapshot.half_extent
    if not (half <= x <= limit and half <= y <= limit):
        return False
    return not any(r.xmin <= x <= r.xmax and r.ymin <= y <= r.ymax for r in snapshot.expanded)


def segment_entry(start, end, rectangle):
    """Closed slab intersection; Fraction avoids any uncertain float predicate."""
    if (max(start[0], end[0]) < rectangle.xmin or min(start[0], end[0]) > rectangle.xmax or
            max(start[1], end[1]) < rectangle.ymin or min(start[1], end[1]) > rectangle.ymax):
        return None
    low, high = Fraction(0), Fraction(1)
    for a, b, minimum, maximum in ((start[0], end[0], rectangle.xmin, rectangle.xmax),
                                  (start[1], end[1], rectangle.ymin, rectangle.ymax)):
        delta = b - a
        if delta == 0:
            if not minimum <= a <= maximum:
                return None
            continue
        enter, leave = sorted((Fraction(minimum-a, delta), Fraction(maximum-a, delta)))
        low, high = max(low, enter), min(high, leave)
        if low > high:
            return None
    return low


def first_hit(obstacles, start, end):
    hits = ((segment_entry(start, end, r), r.id) for r in obstacles)
    return min(((t, oid) for t, oid in hits if t is not None), default=None)


def cardinal_edge_legal(snapshot, start, end):
    if not actor_legal(snapshot, start) or not actor_legal(snapshot, end):
        return False
    if abs(start[0]-end[0]) + abs(start[1]-end[1]) != 250_000 or (
            start[0] != end[0] and start[1] != end[1]):
        return False
    xmin, xmax = sorted((start[0], end[0])); ymin, ymax = sorted((start[1], end[1]))
    return not any(xmax >= r.xmin and xmin <= r.xmax and ymax >= r.ymin and ymin <= r.ymax
                   for r in snapshot.expanded)
