"""Independent JSON-lines A0/A1 runner. Creates no datasets or result files."""
import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from common.contract import Contract, parse_line, serialize
from conventional.reference import Reference


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant",choices=("A0","A1"),default="A0")
    args=parser.parse_args()
    contract = Contract()
    try:
        reference = Reference(variant=args.variant)
    except Exception as error:
        reference = None
        print("REFERENCE_INITIALIZATION_FAILURE " + str(error), file=sys.stderr)
    for row_index, line in enumerate(sys.stdin):
        try:
            request = parse_line(line)
        except (ValueError, RecursionError) as error:
            result = contract.row_error(row_index, "invalid JSON: " + str(error))
        else:
            if reference is not None:
                result = reference.handle(request, row_index)
            else:
                validated = contract.validate(request, row_index)
                result = validated.error or contract.error(validated.query.identity(), "model_failure")
        sys.stdout.write(serialize(result))
        sys.stdout.flush()


if __name__ == "__main__":
    main()
