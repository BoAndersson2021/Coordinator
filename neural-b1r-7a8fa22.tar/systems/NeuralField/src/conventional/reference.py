"""Independent A0/A1 references; no labels, learned inference or query caching."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import logging

from common.contract import Contract
from conventional.geometry import actor_legal, cardinal_edge_legal, first_hit, load_snapshot

SIZE = 63


def node_point(node):
    return (250_000 + 250_000*node[0], 250_000 + 250_000*node[1])


def neighbors(node):
    i, j = node
    return tuple((x, y) for x, y in ((i-1,j), (i+1,j), (i,j-1), (i,j+1))
                 if 0 <= x < SIZE and 0 <= y < SIZE)


def navigation_a0(snapshot, start):
    start_ok = actor_legal(snapshot, node_point(start))
    destination_ok = actor_legal(snapshot, node_point(snapshot.destination))
    steps = None
    if start_ok and destination_ok:
        queue, seen = deque([(start, 0)]), {start}
        while queue:
            node, depth = queue.popleft()
            if node == snapshot.destination:
                steps = depth
                break
            point = node_point(node)
            for other in neighbors(node):
                if other not in seen and cardinal_edge_legal(snapshot, point, node_point(other)):
                    seen.add(other)
                    queue.append((other, depth+1))
    return {"start_traversable": start_ok, "destination_traversable": destination_ok,
            "reachable": steps is not None, "route_cost_m": None if steps is None else steps/4}


def cover(snapshot, point):
    if not actor_legal(snapshot, point):
        return {"candidate_traversable": False, "exposure_fraction": None, "protection_fraction": None}
    dx, dy = (a-b for a, b in zip(snapshot.origin, point))
    half, exposed = snapshot.half_extent, 0
    for j in range(17):
        offset = -half + j*31_250
        if abs(dx) >= abs(dy):
            target = (point[0] + (half if dx >= 0 else -half), point[1]+offset)
        else:
            target = (point[0]+offset, point[1] + (half if dy >= 0 else -half))
        exposed += first_hit(snapshot.obstacles, snapshot.origin, target) is None
    exposure = exposed/17
    return {"candidate_traversable": True, "exposure_fraction": exposure, "protection_fraction": 1-exposure}


def shooting(snapshot, point):
    hit = first_hit(snapshot.obstacles, snapshot.origin, point)
    return {"line_clear": hit is None, "first_hit_t": None if hit is None else float(hit[0]),
            "first_hit_obstacle_id": None if hit is None else hit[1]}


@dataclass(frozen=True, init=False)
class Reference:
    snapshot: object
    contract: object
    variant: str
    table: object

    def __init__(self, geometry_path=None, variant="A0"):
        if variant not in ("A0","A1"):
            raise ValueError("only A0 and A1 are authorized")
        object.__setattr__(self, "snapshot", load_snapshot(geometry_path))
        object.__setattr__(self, "contract", Contract())
        object.__setattr__(self, "variant", variant)
        if variant == "A1":
            from conventional.navigation import build_table
            table=build_table(self.snapshot)
        else:
            table=None
        object.__setattr__(self, "table", table)

    def evaluate(self, query):
        if query.domain == "cover":
            return cover(self.snapshot, query.point_um)
        if query.domain == "shooting":
            return shooting(self.snapshot, query.point_um)
        if self.variant == "A1":
            from conventional.navigation import navigation_a1
            return navigation_a1(self.table,query.start_node)
        return navigation_a0(self.snapshot, query.start_node)

    def handle(self, request, row_index=0):
        result = self.contract.validate(request, row_index)
        if result.error is not None:
            return result.error
        try:
            output = self.evaluate(result.query)
            response = self.contract.response(result.query, output)
            if response["status"] != "ok":
                logging.error("REFERENCE_OUTPUT_FAILURE snapshot=%s request=%r actual=%r",
                              self.snapshot.version, request, output)
            return response
        except Exception:
            logging.exception("REFERENCE_FAILURE snapshot=%s hash=%s request=%r",
                              self.snapshot.version, self.snapshot.sha256, request)
            return self.contract.error(result.query.identity(), "model_failure")
