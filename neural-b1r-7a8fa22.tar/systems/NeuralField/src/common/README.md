# Common contract boundary

This directory contains wire contracts and [contract.py](contract.py), the authorized P001-A structural/domain/serialization implementation. [query.schema.json](query.schema.json) and [response.schema.json](response.schema.json) use JSON Schema draft 2020-12. [P001](../../P001_SPEC.md) owns semantic validation and numeric laws that cannot be expressed as simple structural constraints.

Future common code may handle syntax, finite numbers, accepted constants, coordinate precision, normalization, serialization and timing. It may not inspect obstacles, rays, graph legality, route costs or labels. Accepted query schemas describe the in-domain stream; unsupported typed values have the status policy defined by P001.

Response `ok` denotes execution success only. A's outputs are checked reference evaluations; B's fields are predictions with identical logical units. Cross-field laws include cover fractions summing to 1, null metrics when illegal, route cost only when reachable, reachability implying both locations traversable, and null hit fields iff line-clear. Non-ok records have null output. Query identity must match the request; booleans are not numeric coordinates.

The accepted schemas are unchanged. Typed unsupported constants/ranges are checked after structural/finite validation, preserving `invalid_input` before `out_of_domain`. JSON integer semantics admit finite integral numeric values but reject booleans. No conventional module is imported; common validation is executable without geometric truth.
