"""P001 wire/domain validation only. No obstacle, ray, or graph evaluation."""
from __future__ import annotations

from dataclasses import dataclass
import json
import math
from pathlib import Path
from typing import Optional, Tuple

from jsonschema import Draft202012Validator, validators

MICROMETRES = 1_000_000
SCHEMA_VERSION = "p001.v1"
SNAPSHOT_ID = "p001-static-v1"


def _number(checker, value):
    return type(value) in (int, float)


def _integer(checker, value):
    return type(value) is int or (type(value) is float and math.isfinite(value) and value.is_integer())


WireValidator = validators.extend(
    Draft202012Validator,
    type_checker=Draft202012Validator.TYPE_CHECKER.redefine_many({"number": _number, "integer": _integer}),
)


def finite_json(value, ancestors=None):
    if type(value) is float:
        return math.isfinite(value)
    if type(value) in (int, str, bool) or value is None:
        return True
    if type(value) in (list,dict):
        ancestors=set() if ancestors is None else ancestors
        if id(value) in ancestors:
            return False
        ancestors.add(id(value))
        try:
            if type(value) is list:
                return all(finite_json(item,ancestors) for item in value)
            return all(type(key) is str and finite_json(item,ancestors) for key,item in value.items())
        finally:
            ancestors.remove(id(value))
    return False


def _structure(schema):
    """Keep grammar/types, deferring constants and bounds to domain validation."""
    if isinstance(schema, list):
        return [_structure(item) for item in schema]
    if not isinstance(schema, dict):
        return schema
    if "const" in schema:
        value = schema["const"]
        if isinstance(value, dict):
            return {"type": "object", "properties": {k: _structure({"const": v}) for k, v in value.items()},
                    "required": list(value), "additionalProperties": False}
        if isinstance(value, list):
            return {"type": "array", "prefixItems": [_structure({"const": v}) for v in value],
                    "minItems": len(value), "maxItems": len(value)}
        return {"type": "string" if isinstance(value, str) else "number"}
    return {key: _structure(value) for key, value in schema.items()
            if key not in ("minimum", "maximum", "enum", "$id")}


@dataclass(frozen=True)
class Query:
    schema_version: str
    snapshot_id: str
    query_id: str
    domain: str
    point_um: Optional[Tuple[int, int]] = None
    start_node: Optional[Tuple[int, int]] = None

    def identity(self):
        return {name: getattr(self, name) for name in ("schema_version", "snapshot_id", "query_id", "domain")}


@dataclass(frozen=True)
class Validation:
    query: Optional[Query]
    error: Optional[dict]


class Contract:
    def __init__(self):
        root = Path(__file__).resolve().parent
        accepted = json.loads((root / "query.schema.json").read_text())
        response = json.loads((root / "response.schema.json").read_text())
        WireValidator.check_schema(accepted)
        WireValidator.check_schema(response)
        self._accepted = WireValidator(accepted)
        self._response = WireValidator(response)
        fields = {key: {"type": "string", "minLength": 1} for key in
                  ("schema_version", "snapshot_id", "query_id", "domain")}
        fields["query_id"]["maxLength"] = 128
        self._identity = WireValidator({"type": "object", "properties": fields, "required": list(fields)})
        envelope = {"type": "object", "properties": dict(fields, input={"type": "object"}),
                    "required": list(fields) + ["input"], "additionalProperties": False}
        self._envelope = WireValidator(envelope)
        self._inputs = {}
        for domain in ("cover", "navigation", "shooting"):
            structure = _structure(accepted["$defs"][domain])
            structure["$defs"] = _structure(accepted["$defs"])
            self._inputs[domain] = WireValidator(structure)

    @staticmethod
    def row_error(row_index, reason):
        return {"row_index": row_index, "status": "invalid_input", "reason": reason}

    def error(self, identity, status):
        result = dict(identity, implementation="A", status=status, output=None)
        self._response.validate(result)
        return result

    def validate(self, request, row_index=0):
        if not self._identity.is_valid(request):
            return Validation(None, self.row_error(row_index, "malformed envelope identity"))
        identity = {key: request[key] for key in ("schema_version", "snapshot_id", "query_id", "domain")}
        try:
            finite=finite_json(request)
        except RecursionError:
            finite=False
        if not finite or not self._envelope.is_valid(request):
            return Validation(None, self.error(identity, "invalid_input"))
        domain = request["domain"]
        if domain in self._inputs and not self._inputs[domain].is_valid(request["input"]):
            return Validation(None, self.error(identity, "invalid_input"))
        if not self._accepted.is_valid(request):
            return Validation(None, self.error(identity, "out_of_domain"))
        payload = request["input"]
        if domain == "navigation":
            return Validation(Query(**identity, start_node=tuple(int(n) for n in payload["start_node"])), None)
        raw = payload["candidate_m" if domain == "cover" else "target_m"]
        point = tuple(round(float(n) * MICROMETRES) for n in raw)
        if any(abs(float(n) - p / MICROMETRES) > 1e-12 for n, p in zip(raw, point)):
            return Validation(None, self.error(identity, "out_of_domain"))
        origin = (2_000_000, 7_500_000)
        if (domain == "cover" and sum((a-b)**2 for a, b in zip(point, origin)) <= MICROMETRES**2) or (
                domain == "shooting" and point == origin):
            return Validation(None, self.error(identity, "out_of_domain"))
        return Validation(Query(**identity, point_um=point), None)

    def response(self, query, output):
        result = dict(query.identity(), implementation="A", status="ok", output=output)
        valid = finite_json(result) and self._response.is_valid(result)
        if valid and query.domain == "cover" and output["candidate_traversable"]:
            valid = output["protection_fraction"] == 1 - output["exposure_fraction"]
        if not valid:
            return self.error(query.identity(), "model_failure")
        return result


def parse_line(line):
    def reject_constant(value):
        raise ValueError("non-finite JSON token: " + value)

    def unique_keys(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate JSON key: " + key)
            result[key] = value
        return result

    return json.loads(line, parse_constant=reject_constant, object_pairs_hook=unique_keys)


def serialize(result):
    if not finite_json(result):
        raise ValueError("non-finite or non-JSON response")
    return json.dumps(result, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n"
