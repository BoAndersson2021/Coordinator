# Neural implementation responsibilities

Reserved ownership for local training, export and independently executable B under [P001](../../P001_SPEC.md). No model or training code exists yet.

Use three distinct future entrypoints/environments: trainer (training/validation labels only), exporter (frozen checkpoint and validation parity inputs), and measured inference (weights/config plus frozen query inputs only). Final labels and conventional code must be unavailable to inference and training.

The specified shared and separate models, seeds, losses, selection rule and decoders are preregistered. No geometry lookup or conventional fallback may repair B answers. Log failures and raw diagnostics outside timing; the comparator evaluates predictions after their artifact is frozen. Review any change as a new revision before final testing.
