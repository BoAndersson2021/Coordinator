"""Gate 1 synthetic/fixture tests. No real datasets or privileged provisioning."""
import copy
from collections import Counter
import itertools
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SRC=Path(__file__).resolve().parents[1]/'src'
sys.path.insert(0,str(SRC))
from dataset.authority import AuthorityClosed, require_gate2
from dataset.codec import canonical, decode, digest, semantic
from dataset.recipe import Recipe, request, challenge_points, challenge_requests, status_points
from dataset.audit import audit_splits, nav_assignment, stratum
from dataset.labeling import Labeler, VerificationFailure
from dataset.pipeline import synthetic_bundle, production_bundle
from dataset.artifacts import verify_bundle, rows, jsonl
from dataset.storage import SyntheticStore, NativeOps, AdmissionFailure, production_publish
from dataset.custody import validate_profile, launch_probe, CustodyFailure, launcher_hash, production_launch

REVISION='8be84508e8fed30d860552d265bf89ef84f23d44'


class SimulatedOps(NativeOps):
    """Explicit test-only filesystem shim, never an enforcement qualification."""
    name='simulation-test-only'
    def __init__(self):pass
    def rename(self,source,destination):
        if Path(destination).exists():raise FileExistsError(str(destination))
        os.rename(source,destination)


class DatasetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.recipe=Recipe();cls.labeler=Labeler();cls.bundle=synthetic_bundle(REVISION,cls.recipe,cls.labeler)

    def test_semantic_quantization_identity_and_nonfinite(self):
        a=request('shooting',(14_000_000,6_000_000));b=copy.deepcopy(a)
        b['query_id']='different';b['input']['target_m'][0]+=5e-13
        self.assertEqual(semantic(a),semantic(b))
        b['input']['target_m'][0]=True
        with self.assertRaises(ValueError):semantic(b)
        with self.assertRaises(ValueError):canonical({'x':float('nan')})
        with self.assertRaises(ValueError):decode(b'{"x":1,"x":2}\n')

    def test_pcg64_reproducibility_and_metadata(self):
        for domain in ('cover','shooting'):
            for split in ('training','validation','final'):
                a,meta=self.recipe.sample_synthetic(domain,split,4)
                b,again=self.recipe.sample_synthetic(domain,split,4)
                self.assertEqual(canonical(a),canonical(b));self.assertEqual(meta,again)
                self.assertEqual(len(set(map(semantic,a))),4)
                self.assertTrue(all(semantic(q) not in self.recipe.public for q in a))
                for q in a:
                    p=q['input']['candidate_m' if domain=='cover' else 'target_m']
                    self.assertEqual(self.recipe.tile(tuple(round(n*1_000_000) for n in p)),split)
        with self.assertRaises(ValueError):self.recipe.sample_synthetic('cover','training',15000)
        with self.assertRaises(ValueError):self.recipe.sample_synthetic('cover','training',2,reject_limit=0)

    def test_exhaustive_nav_membership_against_fraction_audit(self):
        public={(7,29),(55,29),(47,11),(29,11)};actual=self.recipe.nav_membership()
        for node,assigned in actual.items():self.assertEqual(assigned,nav_assignment(node,public),msg=str(node))
        self.assertEqual(Counter(actual.values()),Counter(public=4,challenge=225,training=2336,validation=476,final=928))

    def test_toy_adversarial_rounding_statuses_and_strata(self):
        box=((6_000_000,6_000_000,6_500_000,6_500_000),)
        points=challenge_points(box,expanded=True)
        self.assertTrue(all((5_750_000+dx,5_750_000+dy) in points for dx,dy in itertools.product((-10000,-1000,-1,0,1,1000,10000),repeat=2)))
        self.assertEqual(points,tuple(sorted(set(points))))
        self.assertIn((round(2_000_000+1.5*(6_000_000-2_000_000)),round(7_500_000+1.5*(6_000_000-7_500_000))),challenge_points(box,extended=True))
        self.assertIn((-1,-1),status_points());self.assertIn((16_000_001,16_000_001),status_points())
        self.assertEqual(stratum(request('shooting',(6_990_000,5_000_000)),((7_000_000,0,8_000_000,7_000_000),)),'boundary')
        self.assertEqual(stratum(request('shooting',(6_989_999,5_000_000)),((7_000_000,0,8_000_000,7_000_000),)),'near_boundary')

    def test_complete_synthetic_bundle_byte_reproducibility(self):
        again=synthetic_bundle(REVISION,self.recipe,self.labeler)
        self.assertEqual(self.bundle,again)
        manifest=verify_bundle(self.bundle,self.recipe,self.labeler)
        self.assertEqual(manifest['counts'],{'training':6,'validation':6,'final':10})

    def test_independent_disagreement_retains_input_expected_actual(self):
        q=request('shooting',(14_000_000,6_000_000));answer=self.labeler.verify(q)
        answer['output']['first_hit_obstacle_id']='W1'
        with self.assertRaises(VerificationFailure) as caught:self.labeler.verify(q,supplied=answer)
        self.assertEqual(caught.exception.evidence['request'],q)
        self.assertEqual(caught.exception.evidence['expected']['output']['first_hit_obstacle_id'],'W0')
        self.assertEqual(caught.exception.evidence['actual'],answer)
        with patch.object(self.labeler.checker,'shooting_truth',return_value={'line_clear':True,'first_hit_t':None,'first_hit_obstacle_id':None}):
            with self.assertRaises(VerificationFailure):self.labeler.verify(q)

    def test_reserved_overlap_public_status_and_quota_failures(self):
        splits={'training':rows(self.bundle['training/queries.jsonl']),'validation':rows(self.bundle['validation/queries.jsonl']),'final':rows(self.bundle['private/queries.jsonl'])}
        for mode in ('duplicate','public','reserved','quota','invalid'):
            value=copy.deepcopy(splits);kw={}
            if mode=='duplicate':value['training'].append(value['validation'][0])
            elif mode=='public':value['training'].append(request('navigation',(7,29)))
            elif mode=='reserved':kw['reserved']={semantic(value['training'][0])}
            elif mode=='quota':kw['expected_counts']={}
            else:value['training'].append(request('shooting',(16_000_001,8_000_000)))
            with self.subTest(mode=mode),self.assertRaises(VerificationFailure):audit_splits(value,self.recipe,**kw)

    def test_corruption_missing_label_and_forged_audit_rejected(self):
        for mode in ('hash','label','audit','provenance','quotas'):
            value=copy.deepcopy(self.bundle)
            if mode=='hash':value['training/queries.jsonl']+=b'\n'
            elif mode=='label':value['training/labels.jsonl']=b''
            elif mode=='audit':
                a=decode(value['private/audit.json']);a['reserved_keys']=[];value['private/audit.json']=canonical(a)
            elif mode=='provenance':
                a=decode(value['private/provenance.json']);a['source_hashes']={};value['private/provenance.json']=canonical(a)
            else:
                a=decode(value['manifest.json']);a['quotas']['training']['cover']=1;value['manifest.json']=canonical(a)
            if mode not in ('hash','quotas'):
                m=decode(value['manifest.json'])
                for name in m['files']:m['files'][name]={'sha256':digest(value[name]),'bytes':len(value[name])}
                value['manifest.json']=canonical(m)
            with self.subTest(mode=mode),self.assertRaises(Exception):verify_bundle(value,self.recipe,self.labeler)

    def test_production_apis_and_cli_reject_before_any_write(self):
        for fn in (require_gate2,production_bundle,production_publish,production_launch,self.recipe.generate_production):
            for auth,profile in ((None,None),('AUTHORIZED',{'qualified':True}),('forged',{'source_revision':REVISION})):
                with self.subTest(fn=fn,auth=auth),self.assertRaises(AuthorityClosed):fn(authorization=auth,qualification=profile)
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'untouched'
            for operation in ('production','release-final-inputs'):
                result=subprocess.run([sys.executable,'-B',str(SRC/'dataset/run.py'),operation,'--root',str(root),
                                       '--gate2-authorization','AUTHORIZED','--qualification','forged'],capture_output=True,text=True)
                self.assertNotEqual(result.returncode,0);self.assertIn('Gate 2 is closed',result.stderr);self.assertFalse(root.exists())


class PublicationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.recipe=Recipe();cls.labeler=Labeler();cls.bundle=synthetic_bundle(REVISION,cls.recipe,cls.labeler)

    def store(self,tmp,hook=None,ops=None):
        store=SyntheticStore(Path(tmp)/'store',self.recipe,self.labeler,ops=SimulatedOps() if ops is None else ops,hook=hook)
        store.recover();return store

    def test_valid_generation_recovery_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=self.store(tmp);receipt=store.publish('synthetic-valid',self.bundle)
            self.assertFalse(receipt['production_qualified']);self.assertFalse(receipt['custody_pass'])
            recovered=self.store(tmp);self.assertEqual(recovered.admit('synthetic-valid'),receipt)
            with self.assertRaises(AdmissionFailure):store.publish('synthetic-valid',self.bundle)
            self.assertEqual(recovered.admit('synthetic-valid'),receipt)

    def test_precommit_failures_and_interruptions_quarantine(self):
        for point in ('GENERATING','WRITE:training/queries.jsonl','VERIFYING','VERIFIED','BEFORE_RENAME'):
            with self.subTest(point=point),tempfile.TemporaryDirectory() as tmp:
                def hook(p):
                    if p==point:raise RuntimeError('injected '+p)
                store=self.store(tmp,hook)
                with self.assertRaises(RuntimeError):store.publish('synthetic-failed',self.bundle)
                self.assertEqual(list((store.root/'generations').iterdir()),[])
                evidence=decode((store.root/'quarantine/synthetic-failed/failure.json').read_bytes())
                self.assertIn(point,evidence['reason']);self.assertEqual(self.store(tmp).recover(),[])

    def test_unacknowledged_postrename_generation_is_revalidated(self):
        for point in ('AFTER_RENAME','AFTER_PARENT_FSYNC'):
            with self.subTest(point=point),tempfile.TemporaryDirectory() as tmp:
                def hook(p):
                    if p==point:raise RuntimeError('injected '+p)
                store=self.store(tmp,hook)
                with self.assertRaises(RuntimeError):store.publish('synthetic-committed',self.bundle)
                with self.assertRaises(AdmissionFailure):store.admit('synthetic-committed')
                recovered=self.store(tmp);self.assertTrue(recovered.admit('synthetic-committed')['verification_pass'])

    def test_corrupted_or_ambiguous_committed_state_closes_admission(self):
        for mode in ('corrupt','receipt','extra','symlink','hardlink','permissions'):
            with self.subTest(mode=mode),tempfile.TemporaryDirectory() as tmp:
                store=self.store(tmp);store.publish('synthetic-good',self.bundle)
                directory=store.root/'generations/synthetic-good'
                if mode=='corrupt':(directory/'training/queries.jsonl').write_bytes(b'corrupt')
                elif mode=='receipt':(directory/'completion.json').unlink()
                elif mode=='extra':(directory/'private/extra').write_bytes(b'unknown');(directory/'private/extra').chmod(0o600)
                elif mode=='symlink':(directory/'private/link').symlink_to(directory/'manifest.json')
                elif mode=='hardlink':os.link(directory/'manifest.json',Path(tmp)/'outside')
                else:(directory/'private').chmod(0o755)
                with self.assertRaises(Exception):store.recover()
                with self.assertRaises(AdmissionFailure):store.admit('synthetic-good')

    def test_receipt_in_staging_does_not_authorize_admission(self):
        with tempfile.TemporaryDirectory() as tmp:
            def crash(p):
                if p=='BEFORE_RENAME':raise KeyboardInterrupt('simulated process interruption')
            store=self.store(tmp,crash)
            with self.assertRaises(KeyboardInterrupt):store.publish('synthetic-interrupted',self.bundle)
            self.assertTrue((store.root/'.staging/synthetic-interrupted/completion.json').exists())
            with self.assertRaises(AdmissionFailure):store.admit('synthetic-interrupted')
            recovered=self.store(tmp);self.assertTrue((recovered.root/'quarantine/synthetic-interrupted').exists())

    def test_label_failure_is_private_quarantine_evidence(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=self.store(tmp);value=copy.deepcopy(self.bundle)
            labels=rows(value['training/labels.jsonl']);labels[0]['output']['candidate_traversable']=not labels[0]['output']['candidate_traversable']
            value['training/labels.jsonl']=jsonl(labels)
            m=decode(value['manifest.json']);m['files']['training/labels.jsonl']={'sha256':digest(value['training/labels.jsonl']),'bytes':len(value['training/labels.jsonl'])};value['manifest.json']=canonical(m)
            with self.assertRaises(VerificationFailure):store.publish('synthetic-label-fail',value)
            record=decode((store.root/'quarantine/synthetic-label-fail/failure.json').read_bytes())
            self.assertIn('expected',record['evidence']);self.assertIn('actual',record['evidence']);self.assertIn('request',record['evidence'])

    @unittest.skipUnless(sys.platform=='linux','real renameat2 test requires Linux; simulation is not qualification')
    def test_native_linux_atomic_rename_and_recovery(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=self.store(tmp,ops=NativeOps());store.publish('synthetic-native',self.bundle)
            recovered=self.store(tmp,ops=NativeOps());self.assertEqual(recovered.admit('synthetic-native')['backend'],'linux-native')

    @unittest.skipUnless(sys.platform=='linux','native subprocess crash test requires Linux')
    def test_native_process_crashes_before_and_after_rename(self):
        code='''import sys,os
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from dataset.recipe import Recipe
from dataset.labeling import Labeler
from dataset.pipeline import synthetic_bundle
from dataset.storage import SyntheticStore
r=Recipe();l=Labeler()
def hook(p):
    if p==sys.argv[3]:os._exit(47)
s=SyntheticStore(Path(sys.argv[2])/"store",r,l,hook=hook);s.recover()
s.publish("synthetic-crash",synthetic_bundle(sys.argv[4],r,l))
'''
        for point in ('WRITE:training/queries.jsonl','BEFORE_RENAME','AFTER_RENAME','AFTER_PARENT_FSYNC'):
            with self.subTest(point=point),tempfile.TemporaryDirectory() as tmp:
                result=subprocess.run([sys.executable,'-B','-c',code,str(SRC),tmp,point,REVISION],capture_output=True)
                self.assertEqual(result.returncode,47,msg=result.stderr.decode())
                store=SyntheticStore(Path(tmp)/'store',self.recipe,self.labeler);admitted=store.recover()
                self.assertEqual(bool(admitted),point in ('AFTER_RENAME','AFTER_PARENT_FSYNC'))
                if admitted:self.assertTrue(store.admit('synthetic-crash')['verification_pass'])
                else:self.assertTrue((store.root/'quarantine/synthetic-crash').exists())

    def test_unavailable_rename_and_fsync_fail_without_consumer_authority(self):
        class BrokenRename(SimulatedOps):
            def rename(self,a,b):raise OSError('injected unsupported rename')
        with tempfile.TemporaryDirectory() as tmp:
            store=self.store(tmp,ops=BrokenRename())
            with self.assertRaises(OSError):store.publish('synthetic-rename-fail',self.bundle)
            self.assertEqual(list((store.root/'generations').iterdir()),[])
            with self.assertRaises(AdmissionFailure):store.admit('synthetic-rename-fail')
        class BrokenSync(SimulatedOps):
            failing=False
            def sync_dir(self,path):
                if self.failing and Path(path).name=='generations':raise OSError('injected fsync failure')
                super().sync_dir(path)
        with tempfile.TemporaryDirectory() as tmp:
            ops=BrokenSync();store=self.store(tmp,ops=ops)
            def hook(p):
                if p=='AFTER_RENAME':ops.failing=True
            store.hook=hook
            with self.assertRaises(OSError):store.publish('synthetic-sync-fail',self.bundle)
            with self.assertRaises(AdmissionFailure):store.admit('synthetic-sync-fail')
            with self.assertRaises(OSError):store.recover()
            ops.failing=False;store.recover();self.assertTrue(store.admit('synthetic-sync-fail')['verification_pass'])


class CustodyTests(unittest.TestCase):
    def profile(self):
        return {'profile_version':'p001-linux-launch.v1','kind':'synthetic_qualification_only',
                'identities':{'custodian':{'uid':11001,'gid':11001},'training':{'uid':11002,'gid':11002},'inference':{'uid':11003,'gid':11003}},
                'jail_parent':'/var/lib/neuralfield/qualification/jails','training_view':'/var/lib/neuralfield/qualification/training',
                'inference_view':'/var/lib/neuralfield/qualification/inference','runtime':'/opt/neuralfield/qualification-runtime',
                'private_paths':['/var/lib/neuralfield/qualification/'+n+'/sentinel' for n in ('final-inputs','final-labels','staging','quarantine')],
                'code_hash':launcher_hash()}

    def test_consumer_view_ancestry_rejected_before_host_checks(self):
        for parent,child in (('training_view','inference_view'),('inference_view','training_view')):
            for suffix in ('/nested','/nested/deeper'):
                profile=self.profile();profile[parent]='/var/lib/neuralfield/qualification/shared'
                profile[child]=profile[parent]+suffix
                with self.subTest(parent=parent,suffix=suffix):
                    with patch('dataset.custody.os.geteuid') as identity,patch('dataset.custody.subprocess.run') as launch:
                        with self.assertRaisesRegex(CustodyFailure,'overlapping profile roots'):
                            validate_profile(profile,check_host=True)
                        identity.assert_not_called();launch.assert_not_called()

    def test_all_separate_roots_reject_pairwise_ancestry(self):
        fields=('jail_parent','training_view','inference_view')
        for parent,child in itertools.permutations(fields,2):
            profile=self.profile();profile[child]=profile[parent]+'/nested/mount'
            with self.subTest(parent=parent,child=child),self.assertRaisesRegex(CustodyFailure,'overlapping profile roots'):
                validate_profile(profile)
        for parent,child in itertools.permutations(range(4),2):
            profile=self.profile();profile['private_paths'][child]=profile['private_paths'][parent]+'/nested'
            with self.subTest(private_parent=parent,private_child=child),self.assertRaisesRegex(CustodyFailure,'overlapping profile roots'):
                validate_profile(profile)

    def test_disjoint_siblings_and_lexical_prefixes_remain_valid(self):
        for training,inference in (('shared/training','shared/inference'),('shared-training','shared-training-extra')):
            profile=self.profile();prefix='/var/lib/neuralfield/qualification/'
            profile['training_view']=prefix+training;profile['inference_view']=prefix+inference
            self.assertEqual(validate_profile(profile),profile)

    def test_profile_rejects_identity_path_and_code_mismatch(self):
        validate_profile(self.profile())
        for mode in ('uid','gid','path','visible','code','root'):
            p=self.profile()
            if mode=='uid':p['identities']['training']['uid']=11001
            elif mode=='gid':p['identities']['inference']['gid']=11001
            elif mode=='path':p['training_view']+='/../final-labels'
            elif mode=='visible':p['private_paths'][0]=p['training_view']+'/sentinel'
            elif mode=='code':p['code_hash']='0'*64
            else:p['identities']['custodian']['uid']=0
            with self.subTest(mode=mode),self.assertRaises(Exception):validate_profile(p)

    def test_unavailable_host_missing_profile_and_role_fail_closed(self):
        with patch('dataset.custody.sys.platform','darwin'):
            with self.assertRaises(CustodyFailure):validate_profile(self.profile(),check_host=True)
        with patch('dataset.custody.os.geteuid',return_value=1000):
            with self.assertRaises(CustodyFailure):validate_profile(self.profile(),check_host=True)
        with self.assertRaises(Exception):launch_probe('/missing-profile','training')
        with self.assertRaises(CustodyFailure):launch_probe('/missing-profile','custodian')


if __name__=='__main__':unittest.main()
