"""Test-only polygon/SAT and Dijkstra checker. Imports no production methods."""
from fractions import Fraction
import heapq
import json
from pathlib import Path

RAW = json.loads((Path(__file__).resolve().parents[1] / "experiments/P001/geometry.v1.json").read_text())
BOXES = tuple((o["id"], tuple(round(v*1_000_000) for v in o["min"] + o["max"])) for o in RAW["obstacles"])
VERSION = RAW["snapshot_id"]


def corners(box):
    x0,y0,x1,y1 = box
    return ((x0,y0),(x1,y0),(x1,y1),(x0,y1))


def cross(a, b):
    return a[0]*b[1]-a[1]*b[0]


def sub(a, b):
    return (a[0]-b[0], a[1]-b[1])


def inside(point, polygon):
    return all(cross(sub(polygon[(i+1)%4], a), sub(point, a)) >= 0 for i,a in enumerate(polygon))


def segment_polygon_entry(start, end, polygon):
    if inside(start, polygon):
        return Fraction(0)
    direction, hits = sub(end,start), []
    if direction == (0,0):
        return None
    for i, a in enumerate(polygon):
        b = polygon[(i+1)%4]
        edge, offset = sub(b,a), sub(a,start)
        determinant = cross(direction,edge)
        if determinant:
            t, u = Fraction(cross(offset,edge),determinant), Fraction(cross(offset,direction),determinant)
            if 0 <= t <= 1 and 0 <= u <= 1:
                hits.append(t)
        elif cross(offset,direction) == 0:
            axis = 0 if direction[0] else 1
            t0,t1 = sorted((Fraction(a[axis]-start[axis],direction[axis]),
                            Fraction(b[axis]-start[axis],direction[axis])))
            if max(t0,0) <= min(t1,1):
                hits.append(max(t0,Fraction(0)))
    return min(hits,default=None)


def hit(start, end):
    candidates = [(segment_polygon_entry(start,end,corners(box)),oid) for oid,box in BOXES]
    return min(((t,oid) for t,oid in candidates if t is not None),default=None)


def overlap_polygon(a,b):
    """Separating-axis check on the raw polygons, not expanded-centre boxes."""
    for polygon in (a,b):
        for i,p in enumerate(polygon):
            edge = sub(polygon[(i+1)%4],p)
            normal = (-edge[1],edge[0])
            pa = [v[0]*normal[0]+v[1]*normal[1] for v in a]
            pb = [v[0]*normal[0]+v[1]*normal[1] for v in b]
            if max(pa) < min(pb) or max(pb) < min(pa):
                return False
    return True


def legal_sweep(start,end):
    footprint = corners((min(start[0],end[0])-250_000,min(start[1],end[1])-250_000,
                         max(start[0],end[0])+250_000,max(start[1],end[1])+250_000))
    if not all(0 <= coordinate <= 16_000_000 for p in footprint for coordinate in p):
        return False
    return not any(overlap_polygon(footprint,corners(box)) for oid,box in BOXES)


def point(node):
    return (250_000*(node[0]+1),250_000*(node[1]+1))


def navigation_truth():
    nodes = [(i,j) for i in range(63) for j in range(63)]
    legality = {n:legal_sweep(point(n),point(n)) for n in nodes}
    graph = {}
    for i,j in nodes:
        n = (i,j)
        graph[n] = tuple(o for o in ((i+1,j),(i-1,j),(i,j+1),(i,j-1))
                         if o in legality and legality[n] and legality[o] and legal_sweep(point(n),point(o)))
    distance, heap = {(55,29):0}, [(0,(55,29))]
    while heap:
        d,n = heapq.heappop(heap)
        if d != distance[n]:
            continue
        for other in graph[n]:
            proposed = d+1
            if proposed < distance.get(other,10**9):
                distance[other] = proposed
                heapq.heappush(heap,(proposed,other))
    return legality,graph,distance


def cover_truth(centre):
    if not legal_sweep(centre,centre):
        return {"candidate_traversable":False,"exposure_fraction":None,"protection_fraction":None}
    threat = (2_000_000,7_500_000)
    displacement = sub(threat,centre)
    normals = ((-1,0),(1,0),(0,-1),(0,1))
    normal = max(normals,key=lambda n: n[0]*displacement[0]+n[1]*displacement[1])
    centre_face = (centre[0]+normal[0]*250_000,centre[1]+normal[1]*250_000)
    axis = 1 if normal[0] else 0
    endpoints = []
    for k in range(17):
        p = list(centre_face);p[axis] += (k-8)*31_250;endpoints.append(tuple(p))
    value = sum(hit(threat,p) is None for p in endpoints)/17
    return {"candidate_traversable":True,"exposure_fraction":value,"protection_fraction":1-value}


def shooting_truth(target):
    obstruction = hit((2_000_000,7_500_000),target)
    return {"line_clear":obstruction is None,"first_hit_t":None if obstruction is None else float(obstruction[0]),
            "first_hit_obstacle_id":None if obstruction is None else obstruction[1]}
