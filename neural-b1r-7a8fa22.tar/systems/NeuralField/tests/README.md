# P001 verification obligations

P001-A implements [test_reference.py](test_reference.py) with a separate [independent_oracle.py](independent_oracle.py). The [verification record](../../../docs/P001_A_VERIFICATION.md) gives commands and populations. These are deterministic unit/reference fixtures, not experiment splits or datasets. The accepted [P001](../P001_SPEC.md) and [protocol](../../../docs/EXPERIMENT_PROTOCOL.md) also define later obligations that remain unauthorized:

Declared public fixtures are the 11 named P001 §4 examples in the [versioned registry](../experiments/P001/public-fixtures.v1.json); exclude those semantic requests from every learned dataset. Reference verification workloads do not automatically exclude their queries. Exhaustive node/edge and generated geometry checks establish oracle evidence, not new exclusions. Reserved final challenges follow P001 §5, are excluded from training/validation, and remain final-only after public-fixture exclusion. Tests neither read nor create a training/validation/sealed-final pool. See the [B1-C contract](../../../docs/P001_B1_CONTRACT.md) for classification and custody.

- Schema/status/identity tests, non-finite and unsupported queries, null/result invariants.
- Every public analytic fixture, exact collision tangency/closed-edge laws, cover face-selection ties, shooting slab zero directions and first-hit ties.
- All 3,969 navigation nodes, legal edge symmetry and independently checked shortest distances; distinct blocked and disconnected states.
- Spatial split/exclusion audit, sealed adversarial coverage, no final labels in training/export selection, artifact hashes.
- Run B in an environment lacking A modules, geometry evaluators and label tables; inspect dependency/import/artifact manifests. Network predictions must still return the common contract.
- Export parity on validation only; complete final-query accounting and explicit legality/visibility false positives.

Documentation verification is [documented separately](../../../docs/PHASE0_VERIFICATION.md). Passing those checks establishes document integrity, not oracle or neural correctness.

Gate 1 adds [test_dataset.py](test_dataset.py) for reduced synthetic generation, independent labels, split/provenance audits, fail-closed authority, profile validation, private publication/quarantine and recovery. Existing reference workloads retain their classification law above. Synthetic records do not become registered public exclusions. Native Linux rename/process-crash tests skip on macOS; neither simulation nor CI establishes actual production identity isolation or power-loss durability. See [Gate 1 evidence](../../../docs/P001_B1_I_VERIFICATION.md).
