"""P001-A unit/reference fixtures only; no experiment datasets or benchmarks."""
from __future__ import annotations

import ast
import copy
from dataclasses import FrozenInstanceError
from fractions import Fraction
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0,str(SRC))

from common.contract import Contract, Query, parse_line, serialize
from conventional.geometry import Rectangle, actor_legal, cardinal_edge_legal, first_hit, load_snapshot, segment_entry
from conventional.reference import Reference, node_point, neighbors, navigation_a0
from conventional.navigation import build_table, navigation_a1
import independent_oracle as independent


def request(domain, value, query_id="fixture"):
    payload = {
        "cover":{"candidate_m":value,"threat_m":[2,7.5],"actor":{"half_extent_m":0.25}},
        "navigation":{"start_node":value,"destination_node":[55,29],"actor":{"half_extent_m":0.25}},
        "shooting":{"firing_m":[2,7.5],"target_m":value,"firing_geometry":{"projectile_radius_m":0}},
    }[domain]
    return {"schema_version":"p001.v1","snapshot_id":"p001-static-v1","query_id":query_id,
            "domain":domain,"input":payload}


def spatial_points(expanded=False):
    points = set()
    for oid,box in independent.BOXES:
        x0,y0,x1,y1 = box
        h = 250_000 if expanded else 0
        x0,y0,x1,y1 = x0-h,y0-h,x1+h,y1+h
        features = independent.corners((x0,y0,x1,y1)) + ((x0,(y0+y1)//2),(x1,(y0+y1)//2),
                     ((x0+x1)//2,y0),((x0+x1)//2,y1))
        for x,y in features:
            for dx in (-1,0,1):
                for dy in (-1,0,1):
                    p = (x+dx,y+dy)
                    if all(0 <= n <= 16_000_000 for n in p):
                        points.add(p)
    return sorted(points)


class EvidenceCase(unittest.TestCase):
    def equal_evidence(self, actual, expected, value):
        self.assertEqual(actual,expected,msg=f"snapshot={independent.VERSION} input={value!r} expected={expected!r} actual={actual!r}")


class CommonTests(EvidenceCase):
    @classmethod
    def setUpClass(cls):
        cls.contract = Contract();cls.reference = Reference()

    def test_accepted_identity_and_quantization(self):
        for domain,point in (("cover",[10,6]),("navigation",[7.0,29]),("shooting",[14,7.5])):
            value = request(domain,point,"opaque-identity")
            result = self.reference.handle(value)
            self.assertEqual(result["status"],"ok")
            for key in ("schema_version","snapshot_id","query_id","domain"):
                self.assertEqual(result[key],value[key])
            self.assertEqual(json.loads(serialize(result)),result)
        near = request("shooting",[14+5e-13,7.5])
        self.assertEqual(self.contract.validate(near).query.point_um,(14_000_000,7_500_000))

    def test_status_precedence(self):
        cases = []
        for key,value in (("schema_version","future.v2"),("snapshot_id","unknown"),("domain","unknown")):
            item=request("shooting",[14,6]);item[key]=value;cases.append((item,"out_of_domain"))
        for point in ([17,6],[14.0000005,6],[2,7.5]):
            cases.append((request("shooting",point),"out_of_domain"))
        for point in ([2,7.5],[3,7.5]):
            cases.append((request("cover",point),"out_of_domain"))
        cases += [(request("navigation",[-1,2]),"out_of_domain"),(request("navigation",[63,2]),"out_of_domain")]
        for change,value in (("actor",{"half_extent_m":0.5}),("destination_node",[54,29])):
            item=request("navigation",[7,29]);item["input"][change]=value;cases.append((item,"out_of_domain"))
        for value in (True,"14",float("nan"),float("inf"),float("-inf")):
            cases.append((request("shooting",[value,6]),"invalid_input"))
        cases.append((request("navigation",[True,2]),"invalid_input"))
        cases.append((request("navigation",[1.5,2]),"invalid_input"))
        item=request("cover",[10,6]);item["input"]["actor"]["half_extent_m"]=True;cases.append((item,"invalid_input"))
        item=request("shooting",[14,6]);item["extra"]=1;cases.append((item,"invalid_input"))
        item=request("shooting",[float("nan"),6]);item["snapshot_id"]="unknown";cases.append((item,"invalid_input"))
        item=request("navigation",[63,2]);del item["input"]["actor"];cases.append((item,"invalid_input"))
        item=request("shooting",[14,6]);item["schema_version"]="future.v2";item["input"]["target_m"]=["bad",6];cases.append((item,"invalid_input"))
        item=request("shooting",[14,6]);item["input"]["cycle"]=item;cases.append((item,"invalid_input"))
        for value,status in cases:
            with self.subTest(request=value):
                result=self.reference.handle(value)
                self.equal_evidence(result["status"],status,value)
                self.assertIsNone(result["output"])
                self.assertEqual(result["query_id"],value["query_id"])
                self.contract._response.validate(result)

    def test_malformed_envelope_and_parse_errors(self):
        for value in (None,[],{},dict(request("shooting",[14,6]),query_id=""),
                      dict(request("shooting",[14,6]),snapshot_id=1)):
            result=self.reference.handle(value,row_index=8)
            self.assertEqual(result["row_index"],8);self.assertEqual(result["status"],"invalid_input")
            self.assertNotIn("query_id",result)
        for line in ('{"query_id":"a","query_id":"b"}','{"x":NaN}','{"x":Infinity}','broken'):
            with self.assertRaises(ValueError):parse_line(line)
        with self.assertRaises(ValueError):serialize({"x":float("nan")})

    def test_response_rejection_and_inspectable_runtime_failure(self):
        query=self.contract.validate(request("cover",[10,6])).query
        for output in ({"candidate_traversable":True,"exposure_fraction":float("nan"),"protection_fraction":0},
                       {"candidate_traversable":False,"exposure_fraction":0,"protection_fraction":None},
                       {"candidate_traversable":True,"exposure_fraction":0.2,"protection_fraction":0.7}):
            self.assertEqual(self.contract.response(query,output)["status"],"model_failure")
        with patch.object(Reference,"evaluate",side_effect=RuntimeError("injected-verification-failure")):
            with self.assertLogs(level="ERROR") as logs:
                result=self.reference.handle(request("shooting",[14,6]))
            self.assertEqual(result["status"],"model_failure")
            self.assertIn("p001-static-v1",str(logs.output));self.assertIn("injected-verification-failure",str(logs.output))
        for domain,output in (
            ("navigation",{"start_traversable":False,"destination_traversable":True,"reachable":True,"route_cost_m":1}),
            ("navigation",{"start_traversable":True,"destination_traversable":True,"reachable":False,"route_cost_m":1}),
            ("shooting",{"line_clear":True,"first_hit_t":0.5,"first_hit_obstacle_id":"W0"}),
            ("shooting",{"line_clear":False,"first_hit_t":0.5,"first_hit_obstacle_id":"unknown"})):
            point=[7,29] if domain=="navigation" else [14,6]
            query=self.contract.validate(request(domain,point)).query
            self.assertEqual(self.contract.response(query,output)["status"],"model_failure")

    def test_common_admits_geometrically_illegal_locations(self):
        for domain,value in (("cover",[7.5,3]),("navigation",[29,11]),("shooting",[7,7])):
            validated=self.contract.validate(request(domain,value))
            self.assertIsNone(validated.error)
            self.assertIsNotNone(validated.query)

    def test_initialization_failure_preserves_status_precedence(self):
        code=("import sys;sys.path.insert(0,sys.argv[1]);from conventional import run;"
              "run.Reference=lambda **kwargs: (_ for _ in ()).throw(ValueError('injected-snapshot-failure'));"
              "sys.argv=['run','--variant','A0'];run.main()")
        invalid=request("shooting",[True,6]);unsupported=dict(request("shooting",[14,6]),snapshot_id="unknown")
        lines=[invalid,unsupported,request("shooting",[14,6])]
        process=subprocess.run([sys.executable,"-B","-c",code,str(SRC)],
            input="\n".join(json.dumps(x) for x in lines)+"\n",capture_output=True,text=True)
        self.assertEqual(process.returncode,0,process.stderr)
        self.assertIn("injected-snapshot-failure",process.stderr)
        self.assertEqual([json.loads(x)["status"] for x in process.stdout.splitlines()],
                         ["invalid_input","out_of_domain","model_failure"])

    def test_common_dependency_boundary(self):
        tree=ast.parse((SRC/"common/contract.py").read_text())
        names=[n.module for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)]
        names += [a.name for n in ast.walk(tree) if isinstance(n,ast.Import) for a in n.names]
        self.assertFalse(any("conventional" in str(n) or "neural" in str(n) for n in names))
        process=subprocess.run([sys.executable,"-B","-c",
            "import sys;sys.path.insert(0,sys.argv[1]);from common.contract import Contract;Contract();assert not any(n.startswith('conventional') for n in sys.modules)",str(SRC)],
            capture_output=True,text=True)
        self.assertEqual(process.returncode,0,process.stderr)

    def test_json_lines_runner(self):
        lines=[json.dumps(request("shooting",[14,7.5],"first")),"invalid-json",json.dumps(request("navigation",[47,11],"last"))]
        process=subprocess.run([sys.executable,"-B",str(SRC/"conventional/run.py"),"--variant",self.reference.variant],input="\n".join(lines)+"\n",capture_output=True,text=True)
        self.assertEqual(process.returncode,0,process.stderr)
        rows=[json.loads(row) for row in process.stdout.splitlines()]
        self.assertEqual(len(rows),3);self.assertEqual(rows[0]["query_id"],"first")
        self.assertEqual(rows[1]["row_index"],1);self.assertEqual(rows[2]["query_id"],"last")
        self.assertFalse(rows[2]["output"]["reachable"])


class GeometryTests(EvidenceCase):
    @classmethod
    def setUpClass(cls):cls.snapshot=load_snapshot();cls.reference=Reference();cls.precomputed=Reference(variant="A1")

    def test_analytical_fixtures(self):
        cases=[("navigation",[7,29],{"start_traversable":True,"destination_traversable":True,"reachable":True,"route_cost_m":12}),
            ("navigation",[55,29],{"start_traversable":True,"destination_traversable":True,"reachable":True,"route_cost_m":0}),
            ("navigation",[47,11],{"start_traversable":True,"destination_traversable":True,"reachable":False,"route_cost_m":None}),
            ("navigation",[29,11],{"start_traversable":False,"destination_traversable":True,"reachable":False,"route_cost_m":None}),
            ("shooting",[14,7.5],{"line_clear":True,"first_hit_t":None,"first_hit_obstacle_id":None}),
            ("shooting",[14,6],{"line_clear":False,"first_hit_t":5/12,"first_hit_obstacle_id":"W0"}),
            ("shooting",[7,7.5],{"line_clear":True,"first_hit_t":None,"first_hit_obstacle_id":None}),
            ("shooting",[7,7],{"line_clear":False,"first_hit_t":1,"first_hit_obstacle_id":"W0"}),
            ("cover",[10,7.5],{"candidate_traversable":True,"exposure_fraction":1,"protection_fraction":0}),
            ("cover",[10,6],{"candidate_traversable":True,"exposure_fraction":0,"protection_fraction":1}),
            ("cover",[7.5,3],{"candidate_traversable":False,"exposure_fraction":None,"protection_fraction":None})]
        for domain,value,expected in cases:
            with self.subTest(domain=domain,value=value):
                actual=self.reference.handle(request(domain,value))
                self.assertEqual(actual["status"],"ok")
                self.equal_evidence(actual["output"],expected,(domain,value))
                self.equal_evidence(self.precomputed.handle(request(domain,value)),actual,("A1",domain,value))

    def test_exact_segment_degeneracies_and_ties(self):
        box=Rectangle("b",0,0,10,10)
        cases=[((-10,0),(20,0),Fraction(1,3)),((-10,10),(20,10),Fraction(1,3)),
               ((-10,-10),(0,0),Fraction(1)),((-10,10),(10,-10),Fraction(1,2)),
               ((-10,11),(20,11),None),((0,0),(0,0),Fraction(0)),((11,11),(11,11),None),
               ((5,-1),(5,11),Fraction(1,12)),((11,-1),(11,11),None),((5,5),(20,20),Fraction(0))]
        for start,end,expected in cases:
            with self.subTest(start=start,end=end):
                self.equal_evidence(segment_entry(start,end,box),expected,(start,end))
                self.equal_evidence(segment_entry(start,end,box),independent.segment_polygon_entry(start,end,independent.corners((0,0,10,10))),(start,end))
        self.equal_evidence(first_hit((box,Rectangle("a",0,0,10,10)),(-1,5),(11,5)),(Fraction(1,12),"a"),
                            {"obstacles":["b","a"],"start":(-1,5),"end":(11,5)})

    def test_independent_shooting_and_segment_boundaries(self):
        origin=self.snapshot.origin
        targets=spatial_points()
        rng=random.Random(87123)
        targets += [(rng.randrange(16_000_001),rng.randrange(16_000_001)) for _ in range(400)]
        checked=0
        for target in targets:
            for rect in self.snapshot.obstacles:
                expected=independent.segment_polygon_entry(origin,target,independent.corners((rect.xmin,rect.ymin,rect.xmax,rect.ymax)))
                self.equal_evidence(segment_entry(origin,target,rect),expected,(rect.id,origin,target))
                checked+=1
            if target != origin:
                value=request("shooting",[n/1e6 for n in target])
                actual=self.reference.handle(value)
                self.equal_evidence(actual["output"],independent.shooting_truth(target),target)
                self.equal_evidence(self.precomputed.handle(value),actual,("A1",target))
        print(f"VERIFIED independent segment cases={checked}; shooting requests={len(targets)}",flush=True)

    def test_actor_and_cover_boundaries_and_face_ties(self):
        points=spatial_points(True)+[(250_000,250_000),(249_999,250_000),(15_750_000,15_750_000),
                  (15_750_001,15_750_000),(4_000_000,9_500_000),(4_000_000,5_500_000)]
        for point in points:
            expected=independent.legal_sweep(point,point)
            self.equal_evidence(actor_legal(self.snapshot,point),expected,point)
            if sum((a-b)**2 for a,b in zip(point,self.snapshot.origin))>1_000_000**2:
                value=request("cover",[n/1e6 for n in point]);actual=self.reference.handle(value)
                self.equal_evidence(actual["output"],independent.cover_truth(point),point)
                self.equal_evidence(self.precomputed.handle(value),actual,("A1",point))
        print(f"VERIFIED actor/cover boundary points={len(points)}",flush=True)

    def test_snapshot_immutability_and_hash_rejection(self):
        with self.assertRaises(FrozenInstanceError):self.snapshot.world_max=1
        with self.assertRaises(FrozenInstanceError):self.snapshot.obstacles[0].xmin=1
        with self.assertRaises(FrozenInstanceError):self.reference.snapshot=None
        self.assertIsNone(self.reference.table)
        with self.assertRaises(TypeError):self.precomputed.table.legality[0]=False
        with self.assertRaises(FrozenInstanceError):self.precomputed.table.geometry_hash="changed"
        with self.assertRaisesRegex(ValueError,"authorized"):Reference(variant="A2")
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/"geometry.json"
            path.write_text("{}")
            with self.assertRaisesRegex(ValueError,"hash mismatch"):Reference(path)


class NavigationTests(EvidenceCase):
    @classmethod
    def setUpClass(cls):
        cls.snapshot=load_snapshot();cls.legal,cls.graph,cls.distance=independent.navigation_truth()
        cls.table=build_table(cls.snapshot)
        cls.direct=Reference();cls.precomputed=Reference(variant="A1")

    def test_all_nodes_and_all_directed_cardinal_edges(self):
        edges=0
        for node,legal in self.legal.items():
            self.equal_evidence(actor_legal(self.snapshot,node_point(node)),legal,node)
            self.equal_evidence(self.table.legality[node[0]*63+node[1]],legal,("A1",node))
            self.equal_evidence(set(self.table.adjacency[node[0]*63+node[1]]),
                                {n[0]*63+n[1] for n in self.graph[node]},("A1 edges",node))
            for other in neighbors(node):
                expected=other in self.graph[node]
                self.equal_evidence(cardinal_edge_legal(self.snapshot,node_point(node),node_point(other)),expected,(node,other))
                self.equal_evidence(cardinal_edge_legal(self.snapshot,node_point(other),node_point(node)),expected,(other,node))
                self.assertEqual(node in self.graph[other],expected)
                edges+=1
        print(f"VERIFIED navigation classifications={len(self.legal)}; directed edge candidates={edges}",flush=True)

    def test_all_a0_a1_costs_against_independent_dijkstra(self):
        for index,node in enumerate(self.legal):
            steps=self.distance.get(node)
            expected={"start_traversable":self.legal[node],"destination_traversable":True,
                      "reachable":steps is not None,"route_cost_m":None if steps is None else steps/4}
            value=request("navigation",list(node),f"nav-{node[0]}-{node[1]}")
            actual= self.direct.handle(value)
            self.assertEqual(actual["status"],"ok")
            self.equal_evidence(actual["output"],expected,node)
            self.equal_evidence(self.precomputed.handle(value),actual,("A1",node))
            if index % 500 == 499:
                print(f"VERIFIED A0 independent shortest paths={index+1}/3969",flush=True)
        print("VERIFIED A0/A1 independent shortest paths and equivalence=3969/3969",flush=True)


class CommonA1Tests(CommonTests):
    @classmethod
    def setUpClass(cls):cls.contract=Contract();cls.reference=Reference(variant="A1")


if __name__ == "__main__":unittest.main(verbosity=2)
