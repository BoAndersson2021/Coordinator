#!/usr/bin/env python3
"""Read-only integrity/consistency review of retained v1 evidence; never qualifies a host."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / 'docs/evidence/P001_B1_P/v1'
BASELINE = 'b60d63e39fe0601a55bfd67eac0d218054897996'
MANIFEST_SHA256 = '5726e0c10643da35a471cc65c31c905f3df904a9470f5a5a2694eb2c92618dbe'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def baseline_bytes(name):
    return subprocess.check_output(['git', 'show', BASELINE + ':' + name], cwd=ROOT)


def load(path):
    def unique_pairs(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, 'Duplicate JSON key: ' + key)
            result[key] = value
        return result
    def invalid_constant(value):
        raise ValueError('Non-finite JSON: ' + value)
    return json.loads(path.read_bytes(), object_pairs_hook=unique_pairs, parse_constant=invalid_constant)


def validate_package(package=PACKAGE):
    manifest = load(package / 'MANIFEST.json')
    require(sha((package / 'MANIFEST.json').read_bytes()) == MANIFEST_SHA256, 'Immutable v1 manifest changed')
    require(manifest['source_revision'] == BASELINE and manifest['production_qualified'] is False
            and manifest['gate2'] == 'CLOSED' and manifest['review_status'] == 'independent_review_pending', 'Package authority')
    actual = {str(p.relative_to(package)) for p in package.rglob('*') if p.is_file()}
    require(actual == set(manifest['files']) | {'MANIFEST.json'}, 'Evidence inventory mismatch')
    for name, expected in manifest['files'].items():
        path = package / name
        require(not path.is_symlink() and path.resolve().is_relative_to(package.resolve()), 'Aliased evidence')
        raw = path.read_bytes()
        require(sha(raw) == expected, 'Evidence hash mismatch: ' + name)
        require(not re.search(rb'synthetic-private-[0-9a-f]{64}|gh[pousr]_[A-Za-z0-9]{30,}|sk-[A-Za-z0-9_-]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY-----', raw), 'Private value pattern in evidence: ' + name)
    data = {name: load(package / name) for name in manifest['files'] if name.endswith('.json')}
    report = data['REPORT.json']; profile = data['LAUNCH_PROFILE.json']; identities = data['IDENTITY_NAMESPACE.json']
    dac = data['IDENTITY_DAC_ENVIRONMENT.json']; provenance = data['DEPLOYMENT_PROVENANCE.json']
    native = data['NATIVE_NOOVERWRITE.json']; tests = data['GATE1_NATIVE_TESTS.json']; summary = data['NATIVE_TEST_SUMMARY.json']
    for name in ('REPORT.json', 'IDENTITY_NAMESPACE.json', 'IDENTITY_DAC_ENVIRONMENT.json', 'DEPLOYMENT_PROVENANCE.json', 'GATE1_NATIVE_TESTS.json', 'NATIVE_TEST_SUMMARY.json', 'NATIVE_NOOVERWRITE.json', 'SANITIZATION.json'):
        require(data[name]['production_qualified'] is False, 'Production claim: ' + name)
    require(report['source_revision'] == identities['source_revision'] == dac['source_revision'] == provenance['source_revision'] == summary['source_revision_binding'] == BASELINE, 'Source bindings disagree')
    require(report['gate2'] == report['neural_and_benchmark'] == 'CLOSED', 'Closed authority')
    require(report['requirements']['power_loss_durability']['status'] == 'NOT TESTED'
            and identities['filesystem_durability'] == 'not_power_loss_qualified'
            and summary['power_loss_durability'] == native['power_loss_durability'] == 'NOT TESTED', 'Durability overclaim')
    for filename, instance in [('launch-profile.schema.json', profile), ('qualification.schema.json', identities)]:
        Draft202012Validator(load(ROOT / 'systems/NeuralField/src/dataset' / filename)).validate(instance)
    Draft202012Validator(load(ROOT / 'tools/gate1-receipt.schema.json')).validate(tests)
    require(profile == report['profile'] and sha((package / 'LAUNCH_PROFILE.json').read_bytes()) == report['profile_file_sha256'] == identities['profile_sha256'], 'Profile hash mismatch')
    resources = [profile[k] for k in ('jail_parent', 'training_view', 'inference_view', 'runtime')] + profile['private_paths']
    for i, left in enumerate(resources):
        for right in resources[i+1:]:
            require(not Path(left).is_relative_to(right) and not Path(right).is_relative_to(left), 'Overlapping resource roots')
    expected_ids = {'custodian': 11001, 'training': 11002, 'inference': 11003}
    for role, uid in expected_ids.items():
        require(profile['identities'][role] == {'uid': uid, 'gid': uid}, 'Profile identity')
        actual = dac['host_dac_checks'][role]
        require(actual['uid'] == actual['gid'] == uid and actual['groups'] == [] and actual['cap_eff'] == actual['cap_bnd'] == 0 and actual['no_new_privs'] == 1, 'Actual identity restrictions')
        for private in profile['private_paths']:
            require(actual['reads'][private]['read'] == (role == 'custodian'), 'Private DAC read')
        if role != 'custodian':
            require(not any(item['open_write'] for item in actual['write_access'].values()), 'Consumer write authority')
    for role, name in [('custodian', 'nf-custodian'), ('training', 'nf-train'), ('inference', 'nf-infer')]:
        account = dac['accounts'][name]; uid = expected_ids[role]
        require(account['uid'] == account['gid'] == uid and account['groups'] == [uid] and account['shell'] == '/usr/sbin/nologin' and account['password_status'].split()[1] == 'L', 'Account isolation')
    for role in ('training', 'inference'):
        actual = identities['checks'][role]; uid = expected_ids[role]
        require(actual['uid'] == actual['gid'] == uid and actual['groups'] == [] and actual['cap_eff'] == actual['cap_bnd'] == 0 and actual['no_new_privs'] == 1 and actual['fd_leak'] is False and actual['passed'], 'Actual launcher restrictions')
        require(all(actual['checks'].values()), 'Denied/approved jailed check failed')
        mounts = actual['mountinfo'].splitlines()
        require('shared:' not in actual['mountinfo'], 'Shared jailed propagation')
        for mountpoint, source in [('/data', profile[role + '_view']), ('/runtime', profile['runtime'])]:
            matches = [line.split() for line in mounts if line.split()[4] == mountpoint]
            require(len(matches) == 1 and matches[0][3] == source and 'ro' in matches[0][5].split(','), 'Readonly role/runtime mount')
        require(any(line.split()[4] == '/proc' and ' - proc ' in line for line in mounts), 'Isolated proc evidence')
    training_paths = [profile['training_view'] + '/' + name for name in ('sentinel.txt', 'training-labels.sentinel', 'validation.sentinel')]
    for name in training_paths:
        require(dac['host_dac_checks']['training']['reads'][name]['read'] and not dac['host_dac_checks']['inference']['reads'][name]['read'], 'Training/inference read isolation')
    require(report['filesystem']['source'] == '/dev/vda1' and report['filesystem']['fstype'] == 'ext4' and summary['filesystem'] == '/dev/vda1 ext4', 'Native filesystem binding')
    require(native['passed'] and native['uid'] == native['gid'] == 11001 and native['groups'] == [] and native['native_renameat2'] and native['collision_errno'] == 17 and native['destination_preserved'] and native['replacement_preserved'] and native['file_and_directory_fsync'], 'Native collision/fsync outcome')
    require(summary['passed'] and all(item['passed'] and item['exit_code'] == 0 for item in summary['results'].values()), 'Synthetic run result')
    require(summary['identity'] == {k: dac['host_dac_checks']['custodian'][k] for k in ('uid', 'gid', 'groups', 'cap_eff', 'cap_bnd', 'no_new_privs')}, 'Custodian test identity')
    require(tests['tests_run'] == len(tests['records']) == 46 and tests['failures'] == tests['errors'] == tests['skips'] == 0 and tests['passed'] and all(item['outcome'] == 'pass' for item in tests['records']), 'Complete test outcomes')
    require(tests['source_revision'] is None and tests['source_state'] == 'dirty' and tests['actual_uid_isolation'] == 'not_executed', 'Original archive/test-runner caveat must remain')
    for test in ('test_native_linux_atomic_rename_and_recovery', 'test_native_process_crashes_before_and_after_rename', 'test_production_apis_and_cli_reject_before_any_write'):
        require(any(item['test'].endswith('.' + test) for item in tests['records']), 'Missing required outcome: ' + test)
    require('Ran 8 tests' in (package / 'CONTRACT_TESTS.log').read_text() and '\nOK\n' in (package / 'CONTRACT_TESTS.log').read_text(), 'Contract results')
    deployed = provenance['deployed_source_hashes']
    require(len(deployed) == 67, 'Deployed source inventory')
    git_files = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASELINE], cwd=ROOT, text=True).splitlines()
    require(set(git_files) == set(deployed), 'Baseline source inventory mismatch')
    for name, expected in deployed.items():
        require(sha(baseline_bytes(name)) == expected, 'Deployed baseline source hash: ' + name)
    require(sha(subprocess.check_output(['git', 'archive', BASELINE], cwd=ROOT)) == provenance['archive_sha256'] == report['source_archive_sha256'], 'Source archive hash')
    for name, expected in tests['source_hashes'].items():
        require(deployed[name] == expected, 'Tested/deployed source hash mismatch')
    launcher = b''.join((name + '\n').encode() + baseline_bytes('systems/NeuralField/src/dataset/' + name) for name in ('custody_worker.py', 'consumer_probe.py'))
    require(sha(launcher) == profile['code_hash'] == provenance['launcher_sha256'] == report['launcher_sha256'], 'Reviewed launcher binding')
    require(report['dependencies'] == dac['environment'] and report['dependency_wheel_hashes'] == provenance['dependency_wheels'], 'Dependency receipt mismatch')
    packages = {}
    for lock in ('requirements-reference.txt', 'requirements-dataset.txt'):
        raw = baseline_bytes(lock)
        require(sha(raw) == report['dependencies']['lock_hashes'][lock], 'Dependency lock hash')
        for line in raw.decode().splitlines():
            if line and not line.startswith(('#', '-')):
                name, version = line.split('=='); packages[name] = version
    require(packages == report['dependencies']['packages'], 'Pinned package versions')
    report_receipts = {item['path']: item['sha256'] for item in report['receipts']}
    for item in data['SANITIZATION.json']['entries']:
        require(item['package_sha256'] == manifest['files'][item['file']], 'Exported receipt hash')
        expected = report['profile_file_sha256'] if item['file'] == 'LAUNCH_PROFILE.json' else manifest['files']['REPORT.json'] if item['file'] == 'REPORT.json' else report_receipts[item['origin']]
        require(item['original_sha256'] == expected, 'Original retained receipt binding')
    for artifact in summary['artifacts']:
        require(report_receipts[artifact['path']] == artifact['sha256'], 'Test log/receipt binding')
    host_binding = {'host': report['host'], 'filesystem': report['filesystem'], 'profile_sha256': report['profile_file_sha256'], 'launcher_sha256': report['launcher_sha256'], 'source_revision': BASELINE}
    print('PASS: immutable v1 payload hashes, schemas, source/deployment/receipt bindings and actual recorded restrictions')
    print('HOST/FILESYSTEM/PROFILE/SOURCE BINDING SHA256 ' + sha((json.dumps(host_binding, sort_keys=True, separators=(',', ':')) + '\n').encode()))
    print('LIMIT: record validation is not independent host execution or power-loss durability; Gate 2 remains CLOSED')


if __name__ == '__main__':
    validate_package()
