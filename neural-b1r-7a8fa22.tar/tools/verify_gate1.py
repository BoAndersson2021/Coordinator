#!/usr/bin/env python3
"""Run reference/synthetic tests and emit a public receipt without dataset records."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'systems/NeuralField/src'))
from dataset.codec import canonical, decode
from dataset.artifacts import schema_check


class Receipts(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.records=[]
    def addSuccess(self,test):super().addSuccess(test);self.records.append({'test':test.id(),'outcome':'pass'})
    def addFailure(self,test,err):super().addFailure(test,err);self.records.append({'test':test.id(),'outcome':'fail'})
    def addError(self,test,err):super().addError(test,err);self.records.append({'test':test.id(),'outcome':'error'})
    def addSkip(self,test,reason):super().addSkip(test,reason);self.records.append({'test':test.id(),'outcome':'skip','reason':reason})


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--receipt',required=True);parser.add_argument('--b1r-receipt');args=parser.parse_args()
    path=Path(args.receipt).resolve()
    temp_roots=(Path(tempfile.gettempdir()).resolve(),Path('/tmp').resolve())
    runner_temp=os.environ.get('RUNNER_TEMP')
    if runner_temp and Path(runner_temp).is_absolute():temp_roots+=(Path(runner_temp).resolve(),)
    if path.is_relative_to(ROOT) or not any(path.is_relative_to(p) for p in temp_roots):
        parser.error('execution receipts must be outside the repository under the temporary root')
    try:
        revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True,stderr=subprocess.DEVNULL).strip()
        dirty=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
        diff=subprocess.check_output(['git','diff','HEAD','--'],cwd=ROOT)
    except subprocess.CalledProcessError:revision=None;dirty=b'uncommitted copy';diff=b''
    source={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
            for area in ('systems/NeuralField/src','systems/NeuralField/tests','tools')
            for p in (ROOT/area).rglob('*.py')}
    suite=unittest.defaultTestLoader.discover(str(ROOT/'systems/NeuralField/tests'),pattern='test_*.py')
    result=unittest.TextTestRunner(verbosity=2,resultclass=Receipts).run(suite)
    receipt={'receipt_version':'p001-gate1-tests.v1','kind':'synthetic_test_evidence','source_revision':revision,
             'source_state':'dirty' if dirty else 'clean','dirty_diff_sha256':hashlib.sha256(diff).hexdigest(),
             'source_hashes':source,'python':platform.python_version(),'platform':platform.platform(),
             'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),
             'records':result.records,'passed':result.wasSuccessful(),'production_qualified':False,
             'actual_uid_isolation':'not_executed','power_loss_durability':'not_qualified'}
    from jsonschema import Draft202012Validator
    Draft202012Validator(decode((ROOT/'tools/gate1-receipt.schema.json').read_bytes())).validate(receipt)
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(canonical(receipt))
    if args.b1r_receipt:
        extra=Path(args.b1r_receipt).resolve()
        if extra.is_relative_to(ROOT) or not any(extra.is_relative_to(p) for p in temp_roots) or extra==path:
            parser.error('B1-R receipt must be a distinct temporary path outside the repository')
        from dataset.recipe import HASHES
        observations=getattr(sys.modules.get('test_runtime_v2'),'FAILURE_CHECKS',[])
        b1r={'receipt_version':'p001-b1r-tests.v1','kind':'synthetic_test_evidence',
              'gate1_receipt_sha256':hashlib.sha256(canonical(receipt)).hexdigest(),
              'contract_hashes':{n:HASHES[n] for n in ('custody.v1.json','custody.v2.json','integrity.v1.json')},
              'failure_checks':observations,'gate2':'CLOSED','deployed_profiles_changed':False,
              'production_qualified':False,'physical_power_loss':'not_tested_not_required'}
        Draft202012Validator(decode((ROOT/'tools/b1r-execution.schema.json').read_bytes())).validate(b1r)
        extra.parent.mkdir(parents=True,exist_ok=True);extra.write_bytes(canonical(b1r))
        print('B1R RECEIPT '+str(extra)+' SHA256 '+hashlib.sha256(extra.read_bytes()).hexdigest())
    print('RECEIPT '+str(path)+' SHA256 '+hashlib.sha256(path.read_bytes()).hexdigest())
    return 0 if result.wasSuccessful() else 1


if __name__=='__main__':sys.exit(main())
