"""Read-only contract drift tests; no dataset or label generation."""
import copy
import unittest

import validate_phase0 as v


class B1ContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.registry=v.read_json(v.SYSTEM/"experiments/P001/public-fixtures.v1.json")
        cls.custody=v.read_json(v.SYSTEM/"experiments/P001/custody.v1.json")
        cls.query=v.read_json(v.SYSTEM/"src/common/query.schema.json")
        cls.prereg=v.read_json(v.SYSTEM/"experiments/P001/preregistration.v1.json")
        cls.spec=(v.SYSTEM/"P001_SPEC.md").read_text()

    def test_accepted_contracts_and_navigation_partition(self):
        v.check_fixture_registry(self.registry,self.query,self.spec)
        v.check_recipe_text(self.spec)
        v.check_frozen_sections(self.spec)
        v.check_custody_contract(self.custody)
        v.check_b1_documents(v.ROOT)
        counts=v.audit_navigation_classification(self.registry,self.prereg)
        self.assertEqual(sum(counts.values()),3969)
        self.assertEqual(counts['public'],4)
        self.assertGreater(counts['training'],0)
        self.assertGreater(counts['validation'],0)
        self.assertEqual(counts,{'public':4,'challenge':225,'training':2336,'validation':476,'final':928})

    def test_public_registry_expansion_omission_duplicate_and_labels_rejected(self):
        mutations=[]
        for mode in ('extra','omit','duplicate','label','workload','identity'):
            r=copy.deepcopy(self.registry)
            if mode=='extra':
                f=copy.deepcopy(r['fixtures'][0]);f['fixture_id']='nav-added';f['input']['start_node']=[0,0];r['fixtures'].append(f)
            elif mode=='omit':r['fixtures'].pop(0)
            elif mode=='duplicate':r['fixtures'].append(copy.deepcopy(r['fixtures'][0]))
            elif mode=='label':r['fixtures'][0]['output']={'reachable':True}
            elif mode=='workload':r['reference_workload_implies_exclusion']=True
            elif mode=='identity':r['identity_fields'].append('query_id')
            mutations.append((mode,r))
        for mode,r in mutations:
            with self.subTest(mode=mode),self.assertRaises(AssertionError):
                v.check_fixture_registry(r,self.query,self.spec)

    def test_registry_table_mismatch_rejected(self):
        with self.assertRaises(AssertionError):
            v.check_fixture_registry(self.registry,self.query,self.spec.replace('Nav [7,29]','Nav [8,29]'))

    def test_recipe_changes_rejected(self):
        for before,after in (('First 160 tiles','First 159 tiles'),('1101/1102/1103','1101/1102/1199'),
                             ('within 0.5 m inclusive','within 0.4 m inclusive'),('15,000 training','14,000 training'),
                             ('ties-to-even','ties-away-from-zero'),('exclude the four public navigation fixtures','exclude all tested navigation nodes')):
            with self.subTest(before=before),self.assertRaises(AssertionError):
                v.check_recipe_text(self.spec.replace(before,after))

    def test_tile_allocation_prefix_and_navigation_exclusion_drift_rejected(self):
        for mode in ('tiles','prefix','exclude'):
            p=copy.deepcopy(self.prereg);r=copy.deepcopy(self.registry)
            if mode=='tiles':p['datasets']['tile_counts']={'training':159,'validation':33,'final':64}
            elif mode=='prefix':p['datasets']['tile_assignment_prefix']='different-seed'
            else:r['fixtures'][0]['input']['start_node']=[0,0]
            with self.subTest(mode=mode),self.assertRaises(AssertionError):
                v.audit_navigation_classification(r,p)

    def test_geometry_query_model_and_quality_prose_drift_rejected(self):
        for before,after in (('Two dense 64-unit ReLU','Two dense 32-unit ReLU'),
                             ('Zero false positives','One false positive'),
                             ('[0,16] × [0,16]','[0,32] × [0,32]'),('63² = 3,969','62² = 3,844')):
            self.assertIn(before,self.spec)
            with self.subTest(before=before),self.assertRaises(AssertionError):
                v.check_frozen_sections(self.spec.replace(before,after))

    def test_weakened_custody_rejected(self):
        cases={'status':'enforced','identities':{'custodian':'nf-custodian','training':'nf-custodian','inference':'nf-infer'},
               'private_directory_mode':'0755','consumer_capabilities':['CAP_DAC_READ_SEARCH'],
               'consumer_no_new_privileges':False,'consumer_private_pid_namespace':False,
               'consumer_private_mount_namespace':False,'tests_use_actual_launch_profile':False,
               'final_inputs_release':'before_freeze','manifest_sealed_records_allowed':True,
               'symlinks_allowed':True,'external_hardlinks_allowed':True,'b1c_artifact_creation_authorized':True}
        for field,value in cases.items():
            c=copy.deepcopy(self.custody);c[field]=value
            with self.subTest(field=field),self.assertRaises(AssertionError):v.check_custody_contract(c)

    def test_publication_bypasses_rejected(self):
        cases={'same_filesystem_required':False,'publish_primitive':'copy',
               'fsync_files_and_directories':False,'receipt_required_for_consumption':False,
               'recovery':'auto_resume','publish_requires':['all_hashes_verified'],
               'transitions':self.custody['transitions']+[['GENERATING','PUBLISHED / SEALED']]}
        for field,value in cases.items():
            c=copy.deepcopy(self.custody);c[field]=value
            with self.subTest(field=field),self.assertRaises(AssertionError):v.check_custody_contract(c)

    def test_research_custody_successor_preserves_isolation_and_parent_binding(self):
        current=v.read_json(v.SYSTEM/'experiments/P001/custody.v2.json')
        v.check_custody_v2(current,self.custody)
        cases={'consumer_capabilities':['CAP_DAC_READ_SEARCH'], 'fsync_files_and_directories':False,
               'manifest_sealed_records_allowed':True, 'recovered_generation_requires_independent_validation':False}
        for field,value in cases.items():
            mutated=copy.deepcopy(current);mutated[field]=value
            with self.subTest(field=field),self.assertRaises(AssertionError):v.check_custody_v2(mutated,self.custody)
        mutated=copy.deepcopy(current);mutated['supersedes']['sha256']='0'*64
        with self.assertRaises(AssertionError):v.check_custody_v2(mutated,self.custody)

    def test_loss_cannot_reuse_identity_or_silently_repair_corruption(self):
        current=v.read_json(v.SYSTEM/'experiments/P001/integrity.v1.json')
        v.check_research_integrity(current)
        for section,field,value in (('loss_policy','new_generation_identity_required',False),
                ('loss_policy','invalidated_identity_can_reappear_as_valid',True),
                ('loss_policy','missing_registration_allows_admission',True),
                ('recovery','corrupt_or_ambiguous_state','repair_in_place'),
                ('recovery','regeneration_authorizes_tuning_or_final_rerun',True)):
            mutated=copy.deepcopy(current);mutated[section][field]=value
            with self.subTest(field=field),self.assertRaises(AssertionError):v.check_research_integrity(mutated)

    def test_power_survival_cannot_become_a_hidden_P001_gate(self):
        current=v.read_json(v.SYSTEM/'experiments/P001/integrity.v1.json')
        for section,field,value in (('optional_production_profile','required_for_P001',True),
                ('current_environment','full_image_sync_replacement_required',True),
                ('current_environment','additional_physical_storage_qualification_required',True),
                ('acceptance','generation_loss_disqualifies_P001_environment',True)):
            mutated=copy.deepcopy(current);mutated[section][field]=value
            with self.subTest(field=field),self.assertRaises(AssertionError):v.check_research_integrity(mutated)

    def test_integrity_correction_cannot_open_generation_or_skip_checks(self):
        current=v.read_json(v.SYSTEM/'experiments/P001/integrity.v1.json')
        for section,field,value in (('authority','gate2','OPEN'),
                ('authority','dataset_generation_authorized',True),
                ('acknowledgment','required_operation_error_returns_success',True),
                ('acceptance','unsafe_admissions_max',1)):
            mutated=copy.deepcopy(current);mutated[section][field]=value
            with self.subTest(field=field),self.assertRaises(AssertionError):v.check_research_integrity(mutated)


    def test_runtime_custody_v2_bindings_cannot_fallback_or_drift(self):
        import ast
        tree=ast.parse((v.SYSTEM/'src/dataset/recipe.py').read_text())
        hashes=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign)
            and any(isinstance(t,ast.Name) and t.id=='HASHES' for t in n.targets)))
        v.check_runtime_v2_bindings(hashes)
        for name in ('custody.v1.json','custody.v2.json','integrity.v1.json'):
            wrong=copy.deepcopy(hashes);wrong[name]='0'*64
            with self.assertRaises(AssertionError):v.check_runtime_v2_bindings(wrong)
            missing=copy.deepcopy(hashes);del missing[name]
            with self.assertRaises(KeyError):v.check_runtime_v2_bindings(missing)

if __name__=='__main__':unittest.main()
