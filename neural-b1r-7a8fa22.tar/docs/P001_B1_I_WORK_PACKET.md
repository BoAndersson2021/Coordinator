# P001-B1-I — Gate 1 implementation packet

Baseline `8be84508e8fed30d860552d265bf89ef84f23d44`, accepted and merged B1-C. The user explicitly authorized Gate 1: generator primitives, independent A0/A1 labeling, split auditing/provenance, custody launch mechanisms, publication/recovery, synthetic tests, documentation/validators/CI and an implementation PR. Branch: `impl/p001-b1-gate1`.

The [P001 specification](../systems/NeuralField/P001_SPEC.md), [fixture registry](../systems/NeuralField/experiments/P001/public-fixtures.v1.json), [custody contract](../systems/NeuralField/experiments/P001/custody.v1.json), [B1-C contract](P001_B1_CONTRACT.md) and [experiment protocol](EXPERIMENT_PROTOCOL.md) remain governing. Research semantics, model, quality gates, sampling recipe, seeds and quotas must not change.

Gate 1 permits source/schemas, reduced synthetic samples and artifacts in temporary test stores, existing reference checks and synthetic failures. It does not permit privileged host provisioning, real training/validation/final datasets, production publication, final-input exposure, neural implementation/training/inference, benchmarks or merge. Gate 2 is closed even when a caller supplies a flag or purported qualification receipt. Authorize it separately only after independent implementation review and qualified Linux execution evidence.

## Implementation responsibilities

- Generator: PCG64 under pinned NumPy 1.26.4, canonical semantic identities, prescribed tile map and seeds, lexicographic navigation, registered fixture exclusion, reserved challenges, integer/rational rounding and rejection limits.
- Labels: all released synthetic rows must agree across A0/A1 and the existing separately written polygon/Dijkstra route; errors/statuses retain schema/identity laws and disagreements remain inspectable.
- Audit: independently recompute spatial and navigation membership, deduplicate by semantics, check quotas, reserved isolation and status retention; reject corruption and false receipts.
- Provenance: versioned canonical manifests, exact contract/source/dependency hashes and RNG states. Synthetic fixtures identify their baseline plus exact source hashes; CI separately records its exact tested head.
- Custody: distinct Linux identities, private mount/PID namespaces, read-only approved views, cleared groups/capabilities/descriptors and no-new-privileges. Provision nothing automatically. Synthetic qualification uses supplied root-owned resources and the actual launch profile, never a shared-account fallback.
- Publication: private staging and complete verification before no-overwrite atomic commit, durable completion receipt, quarantine/recovery and consumer admission. Synthetic commits grant no production authority.

## Evidence gates

Tests must demonstrate rejection of unauthorized production calls before filesystem writes; deterministic synthetic bytes; registry/split/challenge isolation; independent label failures; corrupt/missing artifacts and provenance; permissions/alias/identity rejection; interrupted staging quarantine; post-rename unacknowledged recovery; fail-closed corrupted committed state; and no-overwrite publication.

Linux CI additionally exercises native renameat2/fsync and real subprocess interruption with synthetic artifacts. This is process-crash evidence on CI's temporary filesystem, not power-loss qualification or production UID isolation. Actual custody tests require the owner-provided or separately authorized Linux host and its existing identities; unavailable resources must remain unqualified. No sealed creation follows a CI pass.

Deliver a dedicated PR with [verification evidence](P001_B1_I_VERIFICATION.md), exact implementation revision, test/synthetic failure receipts, defects, dependency pins and unresolved production environment proof. Update Plan/Handover. Stop after PR submission; await independent review. No merge, Gate 2, P001-B2 or P001-C authorization is granted by this packet.
