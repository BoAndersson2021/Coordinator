# NeuralField research roadmap

Authority: [mission](REPOSITORY_INITIALIZATION_MISSION.md). This is research order, not blanket implementation permission. [P001](../systems/NeuralField/P001_SPEC.md) and the [protocol](EXPERIMENT_PROTOCOL.md) own the first experiment's contracts.

| Stage | Scope | Evidence needed before advancement |
| --- | --- | --- |
| Phase 0 | Thesis, architecture, protocol, exact P001 contracts and repository navigation | All deliverables exist; document/geometry/schema consistency checks pass; independent P001 specification review accepts the contract. Implementation needs separate user authorization. |
| P001 | Fixed 16 × 16 m 2D cover, lattice navigation and ideal shooting queries | Authorized implementation; verified oracle and split isolation; full A/B quality, timing and memory evidence; H1-H4 reported including failures; independent evidence review. Negative results can justify stopping or a new P001 revision. |
| P002 | Controlled doors/destructible cover and snapshot changes | User-authorized new spec defines update/invalidation semantics, stale-model behavior, adaptation cost, training costs, and authoritative geometry handling. P001 findings must justify the experiment; no assumed neural advantage. |
| P003 | Increasing simulated-agent query loads | New spec freezes population/load distributions, batching, queueing, tail latency, throughput, memory sharing and overload behavior. P002 scope may be deferred explicitly if dynamics are irrelevant to a static workload. No silent roadmap reorder. |
| P004 | 3D elevation, floors, obstruction and traversal topology | Accepted contracts for 3D actor/geometry/topology and new oracle, boundary suites and budgets; prior evidence identifies a viable question. No inference from 2D success to 3D correctness. |
| P005 | Native C++ runtime, then possible Unreal integration | Native comparison reproduces qualifying behavior under realistic engine workloads and full deployment costs. Unreal is a subsequent separately authorized gate with engine/version ownership and operational validation. |

Every stage ends in an explicit review decision: advance, revise, pause, or stop. Code/tests alone do not establish domain acceptance. Preserve earlier revisions, source SHAs, weights and negative results. Never change thresholds after testing to qualify for the next stage.

Phase 0 documents are prepared and internally checked; independent review is pending. No P001-P005 implementation, training or measured evidence exists. The current next frontier is **independent review of the complete P001 specification**, followed by an explicit owner decision about P001 implementation.
