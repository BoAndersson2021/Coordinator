# Phase 0 document verification

This record concerns document and contract integrity only. It is not an independent review, oracle test, neural experiment or benchmark result. Governing [mission](REPOSITORY_INITIALIZATION_MISSION.md); complete [P001 specification](../systems/NeuralField/P001_SPEC.md).

## Repeatable read-only route

From the repository root run:

```sh
python3 tools/validate_phase0.py
git diff --check
git status --short --branch
```

The validator requires an already available `jsonschema` package supporting draft 2020-12. No dependency installation is performed by the validator. Its absence reports a validation dependency failure rather than claiming a pass. The Phase 0 author ran it using the existing local interpreter/package.

The validator checks required nonempty files/directories, all local Markdown links and anchors, canonical/parseable JSON and draft schemas, accepted query/response examples and rejected inconsistent examples, geometry/prose table equality, coordinate/actor/anchor constants, preregistration seeds/budgets/model parameter arithmetic, and absence of tactical source files, generated weights or measured results. It does not execute obstacle predicates, pathfinding, raycasts, neural layers or training.

Author cross-check also covered terminology and authority, reference/learned separation, one contract per domain, exact/approximate/advisory classes, invalid versus unreachable navigation, tangency/endpoint laws, sample separation, fair baseline caching, full-cost accounting, negative-result retention and review/implementation gates. No unrelated starting work existed. The original mission remains unchanged.

The initial 2026-10-11 submission execution returned `PASS` for 24 nonempty files, 105 local links, four canonical JSON contracts and 29 accepted/rejected schema cases. Geometry/prose/schema constants, model parameter arithmetic, split budgets, seeds, gates and the documentation-only inventory passed. `git diff --check` passed on the submitted tree. Geometry SHA-256 is `37759af786f658d89eef887add98ce47d95d0c450a877a70a0c3002addb68f1b`; the initial preregistration SHA-256 was `40f5bd3bdf083e135123627966cc5eed1d6f0ffe0c0d55e6d474541d711d3f8a`.

## Independent review correction verification

The [review of `44e80cc`](https://github.com/WRRTREPO/NEURAL/pull/1#issuecomment-6116356414) returned ACCEPT WITH CHANGES. The corrected contract retains the model and quality gates, explicitly rejects universal correctness from sampled tests, freezes measurement code/trace/order/settings before exposure, and allows only one predetermined final campaign. Statistical allocation names four latency contrasts, separating deterministic H1/byte comparisons and descriptive H4 acceptance from inference.

The same read-only route passes 24 files, 105 local links, four JSON contracts, 29 schema cases and new checks of these review requirements. The validator verifies unchanged model shape and quality limits, complete freeze-artifact membership, the single-campaign/new-revision/new-sealed-set law, hypothesis classes, contrast identities and directions, alpha/interval arithmetic and quantile convention, and incomplete/inconclusive reporting. The corrected preregistration SHA-256 is `f2168acf7d80c6c38136417988e5c17608575bfe4c8b2909ae9956616dd72d96`; the geometry hash is unchanged. Documentation-only scope and whitespace checks pass. No tactical computation, training, P001 execution or final-test exposure occurred.

This records internal verification of corrections, not renewed independent acceptance. Merge and implementation remain closed pending review and explicit authorization.

This validator deliberately enforces the Phase 0 inventory. A later authorized implementation must revise or replace that scope check in review; its failures must not be bypassed to smuggle runtime work into Phase 0.

The subsequent explicitly authorized [P001-A packet](P001_A_WORK_PACKET.md) adds `--stage P001-A` to the validator. It preserves the default Phase0 inventory and all contract assertions while admitting only an explicit list of conventional/common/test/CI files. Use the [P001-A route](P001_A_VERIFICATION.md) on that branch; the evidence above describes the accepted Phase 0 tree.

## Acceptance matrix

| Mission gate | Contract evidence |
| --- | --- |
| Explicit falsifiable thesis | [THESIS.md](../THESIS.md), H1-H4 support/failure conditions |
| Independent A/B execution | [Architecture](ARCHITECTURE.md), artifact/import isolation; [P001](../systems/NeuralField/P001_SPEC.md) A variants and B decoder |
| Unambiguous three queries | P001 sections 2-3; accepted request/response schemas |
| Result classes and authority | Architecture class table; zero authority delegated to predictions |
| Fully defined geometry/coordinates | P001 section 2 and geometry.v1.json |
| No train/final contamination | P001 section 5; protocol custody and split audit |
| Comparable end-to-end benchmarks | Protocol timing/memory/lifetime sections and primary trace |
| Explicit neural false positives | P001 section 7; domain/stratum confusion matrices |
| Independent rerun metadata | Protocol manifests, pinned versions, raw artifacts, seeds and hashes |
| Predefined failure criteria | P001 budgets and protocol failed/inconclusive decisions |
| Implementation-ready work packet | P001 sections 4-8, model/loss/export/label/measurement contracts |
| No fabricated runtime evidence | Documentation-only inventory; results contains only its storage policy |

Authored deliverables pass internal integrity checks. Independent P001 specification acceptance remains pending. Operational package/hardware locking and actual artifact hashes await a later implementation gate. Public analytical fixtures and parameter byte arithmetic are proposed checks/estimates, not experimental measurements.
