# P001-B1-D — P001 integrity and deterministic regeneration contract

Status: proposed contract correction for independent review. Baseline: `ddeaa76bd9662cc1483ae7764d96ca78d3213e11`, accepted PR #5 evidence merge. This revision follows the owner's rejection of mandatory acknowledged-write survival at `d404184183e85c2a118939f81b98a390632181f0`. Gate 2, dataset generation, neural work, benchmarking and merge remain closed.

P001 requires complete, correct, isolated and reproducible datasets. Losing work after a VM or host failure is recoverable. Admitting partial/corrupt data, leaking final labels or changing data under a trusted identity is unacceptable. No guaranteed survival of every acknowledged generation, physical host-power test or replacement of Colima disk synchronization is required for P001.

## 1. Explicit custody reconciliation

The accepted [custody.v1.json](../systems/NeuralField/experiments/P001/custody.v1.json) remains byte-identical, including its original `durable_completion_receipt` requirement. The [v2 successor](../systems/NeuralField/experiments/P001/custody.v2.json) names v1 and its exact hash and explicitly supersedes its persistence/receipt interpretation for future P001 runs, subject to this correction's acceptance. It preserves every original isolation, ownership, access, geometry-independent publication and verification requirement. The [integrity contract](../systems/NeuralField/experiments/P001/integrity.v1.json), [experiment protocol](EXPERIMENT_PROTOCOL.md), [P001 specification](../systems/NeuralField/P001_SPEC.md) and [B1 contract](P001_B1_CONTRACT.md) select v2 consistently. Neither version grants execution authority.

The v1 publication precondition `durable_completion_receipt` becomes `synced_verified_completion_receipt`: a canonical complete receipt is written and file/directory fsync results are checked before local publication success. Both rename parents are synchronized. Failed or unsupported required operations return failure; no ignored fsync errors, copying, overwriting or partial admission are allowed. This is an explicit persistence-policy revision, not a claim that host power-loss durability was demonstrated.

V2 removes the universal survival interpretation and adds recorded loss/invalidation/regeneration semantics. Publication lifecycle states and their verification transitions remain unchanged; a `LOST` availability record is separate from an immutable generation's original completion receipt and does not rewrite that receipt. Public records remain restricted to the existing manifest allowlist; extra diagnostics and loss lineage stay custodian-private. Final-input release remains dependent on the separately reviewed final freeze.

Historical Gate 1 code, receipts and provenance still bind custody v1. They are not relabeled v2-qualified. Before any separately authorized real generation, its code/configuration/provenance must explicitly select the reviewed v2 and integrity contract hashes and preserve the closed authority checks until authorization is supplied. This is an ordinary bounded source/provenance alignment dependency, not a new physical-storage qualification project. No runtime or artifact schema is implemented or modified here.

## 2. Mandatory P001 requirements

| Property | Contract |
| --- | --- |
| Determinism | Reproduce query content and verified labels from reviewed source/geometry, fixed recipes/seeds, pinned dependencies and recorded configuration |
| Provenance | Record actual source/configuration/geometry/schema/custody versions and hashes, seeds/RNG state, counts and artifact hashes |
| Geometric correctness | A0/A1 and the independent geometry/graph route must agree; any disagreement blocks publication and labels |
| Isolation | Actual custodian/train/inference identities, restricted mounts/groups/capabilities/descriptors and final-label custody remain mandatory |
| Atomic publication | Private staging; complete verification; complete synced receipt; same-filesystem RENAME_NOREPLACE; checked file/nested-directory/rename-parent fsync |
| Admission | Independently verify the complete committed generation against trusted identity/provenance and all hashes, schemas, labels and split audits before consumption |
| Normal process recovery | Preserve previously complete generations; quarantine unpublished work; revalidate a complete post-rename candidate before admission |
| VM/host failure recovery | Treat missing data as loss; reject partial, changed, corrupt or ambiguous candidates; never trust directory existence or a receipt alone |
| Storage survival | Best available checked local synchronization, without a promise that every successful local commit survives guest/VM/host power failure |

The [accepted synthetic evidence](evidence/P001_B1_P/v1/README.md) supports existing OS isolation, native ext4 atomic operations and process recovery. The [topology record](evidence/P001_B1_D/v1/TOPOLOGY.json) and [source index](evidence/P001_B1_D/v1/SOURCES.json) remain observations, not host-power proofs. The designated native ext4 store stays `/var/lib/neuralfield/P001` on `/dev/vda1`. No migration to virtiofs/overlayfs or consumer-permission change is proposed. Colima's unresolved physical persistence guarantee is not a P001 blocker under this corrected profile.

## 3. Failure and acknowledgment matrix

`ACK` means successful **verified local publication** after all required local writes, verification, receipt and fsync operations. It is not a host-power survival promise. A completion file or rename alone does not acknowledge publication. Recovery independently validates the store irrespective of the last ACK.

| Failure | P001 recovery and acceptance |
| --- | --- |
| F1: process termination before rename | No success; quarantine any remaining staging. Never expose or auto-publish incomplete work |
| F2: process termination after rename before success | If a complete committed generation remains, independently verify and complete required local synchronization before admission; otherwise quarantine/reject or record loss |
| F3: guest kernel crash | Complete independently valid survivors may be admitted; missing generations are recorded as lost; partial/corrupt/ambiguous survivors are rejected |
| F4: abrupt Colima VM termination | Same integrity-first recovery; loss is recoverable, not a P001 failure of promised availability |
| F5: macOS crash/power loss | Same integrity-first recovery, including acknowledged generations; no physical host-power test is required |
| F6: incomplete/corrupted/rolled-back disk persistence | Detect mismatches against trusted expected identities/hashes/provenance; close affected consumption authority immediately; retain diagnostics without silent repair |

Previously acknowledged loss must be reported rather than hidden, but does not fail the research storage profile if the old identity is invalidated and recovery/regeneration is handled correctly. Zero unsafe admissions, final-label leaks or successful publication responses after required sync/verification errors are allowed. Normal process-crash recovery remains a required mechanism; broader VM/host survival is not assumed from those tests.

## 4. Loss, corruption and regeneration

Consumer launch specifies the expected registered generation identity and trusted manifest/provenance binding; it must not discover a self-claimed generation and trust only that candidate's rewritten manifest. Registration can be a custodian-controlled catalog or reviewed experiment metadata. It need not be an independently power-proof witness. If both candidate and trustworthy registration metadata are unavailable, report unknown/lost state and admit nothing until reviewed frozen provenance is recovered; do not interpret an empty store as a valid dataset.

**Recoverable loss:** record the expected old identity, available trusted hashes, cause/observation, affected splits and time in a custodian-private audit. Invalidate/retire that identity. Allocate a fresh generation identity, replay the same frozen scientific inputs, independently verify every label and split/hash/count, and republish atomically under v2. Link the new generation to the loss record privately. Generation/source/contract lineage metadata can change; expected scientific query content and labels cannot be changed to make regeneration pass. Hash the actual new artifact bytes; never copy an old receipt or fabricate hash equality across different identity metadata.

**Unacceptable corruption:** an incomplete, mismatched, aliased, wrongly owned, partially labeled or ambiguously identified survivor is not missing-data success. Stop consumption, preserve available bytes and diagnostics privately, and require reviewed disposition. Do not repair it in place, rewrite its manifest, silently reduce quotas, reuse its identity or automatically publish quarantined work. Fresh regeneration may follow only with trustworthy frozen provenance and the relevant authorization; the corruption remains retained evidence.

An invalidated identity stays invalid if its old directory later reappears after rollback/recovery; it cannot silently return to authority. A complete valid post-rename generation that was never invalidated is recognized as the original generation after independent recovery verification; it need not be regenerated merely because the success response was lost. Missing staging never produces a success receipt.

Regeneration does not change split/exclusion rules or final-label custody. Trainer access remains training/validation only. Final inputs and labels stay sealed, including regenerated copies. If final exposure/evaluation already occurred, preserve exposure history and failed/interrupted trials: regeneration is not permission to retune, reset the final freeze or rerun an interrupted final campaign. The existing new-revision/new-sealed-set rule for post-exposure changes remains unchanged. Any lost evaluation evidence is reported as missing/inconclusive.

## 5. P001 acceptance and next gate

Acceptance requires deterministic content, hashes/provenance, independent reference/label checks, actual isolation, native atomic publication, no partial admission, normal process-crash recovery and fail-closed validation of missing/corrupt/ambiguous recovered state. The [bounded verification plan](P001_B1_D_RECOVERY_PLAN.md) uses existing evidence plus synthetic recovery checks under a later explicit implementation/execution authorization. No new guest/VM/host crash campaign, full-sync patch, SSD power-loss certification, independent failure-domain witness or infrastructure replacement is a prerequisite.

The current Colima environment has accepted evidence for most required mechanisms. This contract does not certify a real dataset or grant Gate 2. Remaining frontier: independent review of the correction, then a bounded separately authorized real-generation/provenance/recovery work packet using v2. Any uncovered integrity defect blocks the affected operation; absent availability guarantees alone do not.

## 6. Optional production-strength profile

A future separately selected production profile may promise acknowledged-write survival through guest/VM/host failure and require full-chain synchronization, failure-domain witnesses/backups, and appropriately authorized disruptive tests. It is **optional, unselected and unqualified** here, never inherited by P001 admission. It requires its own reviewed specification, evidence and authorization. Existing power-loss unknowns are preserved as limits, without further work or an implicit P001 dependency.
