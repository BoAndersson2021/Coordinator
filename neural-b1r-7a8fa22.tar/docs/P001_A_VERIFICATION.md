# P001-A reference verification

Scope: [authorized packet](P001_A_WORK_PACKET.md). Contracts: [P001](../systems/NeuralField/P001_SPEC.md). This evidence concerns the conventional foundation; it is not an A/B experiment, dataset, geometric proof for all possible inputs, or performance claim.

## Reproduction

Python 3.9 or newer with the pinned [reference dependencies](../requirements-reference.txt). The local verification used Python 3.9.6 and jsonschema 4.25.1 already installed. In a clean environment, install that requirements file, then run from repository root:

```sh
python3 -B tools/validate_phase0.py --stage P001-A
python3 -B -m unittest discover -s systems/NeuralField/tests -p 'test_*.py' -v
git diff --check 247e78ce07831eebd8c5c8f9157c12bcdf50279c HEAD
```

The [CI workflow](../.github/workflows/reference.yml) runs pinned actions and dependencies on Python 3.9 and 3.12. Test failures retain inputs, expected/actual values and snapshot version in console evidence. CI uploads logs even on failure; logs are outside the source/results tree. Unit-test durations are not experiment benchmarks.

## Coverage and independent methods

- Public analytical fixtures: all 11 cover/navigation/shooting cases from P001.
- Common handling: both variants; schema/types including boolean-as-number rejection, constants/domain ranges, micrometre quantization, invalid-before-out-of-domain precedence, finite-value rejection, unsupported identity echo, malformed-envelope row records, duplicate-key/invalid JSON, serialization and response invariants. A separate process imports common code without conventional modules.
- Segment topology: closed slab intervals using exact rational parameters, checked against independently implemented polygon-edge cross products and endpoint containment; 7,376 canonical rectangle/segment comparisons, 922 shooting requests, plus explicit zero-length, horizontal/vertical, tangent/corner/collinear and obstacle-ID tie cases.
- Actor/cover: 492 boundary/world-contact/face-tie points; raw polygon separating-axis checks and independently selected face rays rather than expanded-centre collision or reference slab calls.
- Navigation: all 3,969 nodes; all 15,624 directed cardinal edge candidates and symmetry; independent raw swept-footprint polygons; independent graph construction and heap-based Dijkstra distances. Full A0/A1 request-response equivalence on every node, as well as cover/shooting boundary and public fixtures.
- State/failure: immutable snapshot/rectangle/table/reference records, canonical SHA-256 mismatch rejection, A0 has no precomputed table, A2 rejected, and injected reference failures produce `model_failure` plus inspectable diagnostic logs.

The first A0-only run passed 13 tests before A1 was introduced. The final complete suite passed 23 tests; its loops cover the node/edge/segment populations above. Failures discovered in these runs: none. Intentional malformed and injected-error cases pass only when the prescribed rejection is observed. Declared public fixtures are only the 11 named P001 §4 examples enumerated in the [versioned registry](../systems/NeuralField/experiments/P001/public-fixtures.v1.json), including four navigation requests. Reference verification workloads do not automatically exclude their queries from datasets. These include exhaustive nodes/edges and generated geometry checks. Reserved final challenges are defined by P001 §5 and excluded from training/validation. Test execution is not exclusion authority; see the [B1-C contract](P001_B1_CONTRACT.md). This corrects the earlier blanket wording without changing the verification evidence or frozen split recipe.

## Numerical and ownership decisions

The wire path applies the approved binary64 coordinate-grid check; accepted coordinates become integer micrometres. Contact/side predicates use integer arithmetic, and segment hit parameters use exact rational arithmetic throughout rather than uncertain floating-point decisions. No collision epsilon, snapping of tactical outputs, geometry fallback, or oracle sharing with a learned runner exists. See [Python Fraction documentation](https://docs.python.org/3/library/fractions.html) and [jsonschema type-checking documentation](https://python-jsonschema.readthedocs.io/en/stable/validate/) for the library capabilities used.

A0 searches per query and never precomputes graph truth. A1 explicitly constructs immutable legality, adjacency and single-destination distances at initialization; it is not a query cache. Both variants use the same governed collision laws, while the test checker imports no production geometry/query methods. Common code performs only syntax/domain and response-contract handling. JSON-lines execution writes replies/diagnostics, never datasets or result files.

All ten accepted governing contract files were checked byte-for-byte against baseline `247e78ce`: geometry, P001 specification, architecture, experiment protocol, thesis, research roadmap, initialization mission, wire schemas and preregistration remain unchanged. The documentation validator's default Phase0 inventory stays strict; `--stage P001-A` adds only an explicit authorized file list, retaining all contract assertions. Its run passed 36 required files, four canonical JSON contracts and 29 schema cases, plus local-link and scope checks. Transient interpreter/virtual-environment files are excluded, while unknown source/data/result artifacts still fail.

## Acceptance and remaining gate

Local reference and repository checks pass. [CI run 38195873268](https://github.com/WRRTREPO/NEURAL/actions/runs/38195873268) passed at implementation commit `80be9c9048672ac839c734fd8a05e195dea8b8a8` on both Python 3.9 and 3.12, including dependency installation, contract/scope checks, all 23 tests and whitespace validation. Final submitted-head checks are reported by the PR/check run; independent review remains pending. No unresolved contract ambiguity or missing local dependency blocks this implementation. No label-generation, dataset, neural, benchmark, dynamics, engine, merge or later-stage authority follows from these checks.
