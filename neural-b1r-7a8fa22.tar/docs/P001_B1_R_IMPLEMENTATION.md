# P001-B1-R — Custody v2 runtime alignment

Baseline: `0e30cba9818f933e91ede0400dc61230aaf32a86`. Authorized scope: R1–R5 in the accepted [PR #7 work packet](https://github.com/WRRTREPO/NEURAL/pull/7) at `1aff80a58e7e2c9f9a1aa3338bdec6ca47035476`. That draft remains the historical work-packet record. This implementation requires independent review and cannot enable Gate 2.

## Selected context

[Recipe](../systems/NeuralField/src/dataset/recipe.py) pins custody v2, integrity v1 and the unchanged v1 parent. Missing/tampered bindings reject without fallback. Current synthetic artifacts have version `p001-dataset-artifacts.v2`; v1 schemas and [accepted qualification evidence](evidence/P001_B1_P/v1/README.md) are retained unchanged. Exact source, schema, dependency, geometry, fixture and recipe hashes, interpreter version and six PCG64 replay states accompany each bounded 22-row bundle. Independent A0/A1, polygon/graph labels and split checks run before registration, on persisted staging bytes and on recovered admission.

## Trusted authority and serialization

[Storage](../systems/NeuralField/src/dataset/storage.py) places private `.trust/registrations/<id>.json`, `.trust/losses/<id>.json` and an inventory beside, never inside, `generations/<id>`. Canonical registration records bind expected manifest/completion hashes, counts, exact replay provenance and optional private replacement lineage. Completion bytes are calculated before registration, so there is no recursive digest dependency. Candidate manifests cannot register themselves during recovery.

An owned 0600 `.lock` plus `flock(LOCK_EX)` serializes initialization and every publication, recovery, invalidation, regeneration and admission operation across processes. A process-local mutex also serializes threads sharing a store object. Locks are held through independent validation and synchronization. Recovery waits for in-flight registration/publication; another writer cannot reuse its identity. Returned admission is a verification at the operation's serialized point, not an indefinitely valid consumer capability. Consumer integration is still closed.

Catalog records are exclusive-written, fsynced and placed with native `RENAME_NOREPLACE`. The custodian inventory is updated with an exclusive temporary file, checked file/directory fsync, atomic replacement of its previous version and another directory fsync. Replacement applies only to the inventory, never immutable registration, loss or dataset records. Inventory hashes bind the complete record set. Missing records, orphan records, pending transactions, malformed JSON, conflicting lineage or changed bytes close admission. A crash between record placement and inventory commitment is intentionally ambiguous: preserve the private transaction and require authorized trusted-provenance disposition. Do not reconstruct the inventory from candidates or orphan records.

Initialization creates authority only in an empty temporary store. A missing marker, catalog, inventory, lock or private subtree in an existing store cannot be treated as a fresh empty store. All private paths remain current custodian/test-owner owned, same-device, 0700 directories/0600 files; aliases, hardlinks, ACLs, special objects and permissive modes reject. The synthetic path cannot select the live custody root or expand its quotas. This is not a deployment or physical-survival witness.

## Loss and fresh replay

A registered generation absent at recovery is recorded privately as lost; an interrupted staged generation is quarantined and its registered identity retired. Repeated recovery retains the same immutable loss record. An unregistered interrupted stage is quarantined without deriving trust from its contents; its quarantine reserves that identity against reuse. All committed candidates are checked before any successful recovery list is returned. A complete post-rename survivor is verified under its original registration even if the prior success response was lost.

Invalidation binds the original registration, expected manifest/completion hashes and counts. A retired identity cannot be re-registered or admitted; an old directory reappearing closes the entire recovery gate. Missing or corrupted registration/invalidation closes consumption and never invokes generation. Ordinary known losses do not prevent admission of properly registered replacements.

Only explicit `regenerate(retired, fresh)` replays the reduced synthetic pipeline. It requires a trusted loss, a distinct unused identity, exact frozen provenance and manifest agreement, full independent checks and a fresh completion receipt. Changed source/schema/dependency/interpreter/RNG context requires restoration of the original replay environment or separate owner disposition; it cannot be silently relabeled as regeneration. Private lineage binds the replacement to the loss digest. No old completion hash is copied. Recovery never changes final exposure history, tuning authority or the final freeze law.

## Publication and diagnostics

Private staging retains GENERATING → VERIFYING → VERIFIED. Payload, receipt, nested directories, both rename parents, registration and inventory synchronization must succeed. No-overwrite rename publishes only a complete verified generation. Post-rename errors return no successful response; restart must audit the entire store and resynchronize verified survivors. Recovered files and directories are synchronized before local admission. A synchronization error closes authority.

Private quarantine keeps original failure evidence; recovery diagnostics retain category and independent expected/actual details without printing private data. The CLI projects only the custody public allowlist. Production API/CLI commands still unconditionally reject before accessing an output root, regardless of claimed authorization. Physical power-loss survival is neither claimed nor required for P001.

## Verification and limits

Run `python3 -B tools/validate_phase0.py --stage P001-B1-R`, the contract suite, and `python3 -B tools/verify_gate1.py --receipt /tmp/neural-b1r-tests.json`. [New tests](../systems/NeuralField/tests/test_runtime_v2.py) cover active binding, registration expectations, forgery, loss/replay, trust loss, retirement, permissions, independent disagreement, synchronization failures, native process exits and interprocess races. Existing reference verification remains exhaustive over all 3,969 lattice nodes and 15,624 directed edge candidates.

Portable filesystem fault tests identify their simulation backend. Native `renameat2`, actual process exits and `flock` concurrency execute only on Linux; a skip cannot establish the native acceptance gate. Existing OS custody receipts retain their original source and v1 identity. CI temporary-store tests do not establish deployment UID/GID isolation, production qualification or VM/host failure survival. No privileged provisioning, real datasets, final-input exposure, neural candidate, benchmark or merge is included.

Execution results, exact revision and unresolved dependencies are recorded in [Handover](../Handover.md) and the implementation PR. Stop for independent review after submission.
