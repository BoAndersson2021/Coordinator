"""Record final qualification metadata; never export sentinel contents."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import stat
import subprocess
import sys

BASE=Path('/var/lib/neuralfield');Q=BASE/'qualification';OPT=Path('/opt/neuralfield');SOURCE=OPT/'qualification-source'
R=Q/'receipts'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def command(args):return subprocess.check_output(args,text=True).strip()
def load(name):return json.loads((R/name).read_bytes())
def metadata(p):
    i=p.lstat()
    return {'path':str(p),'uid':i.st_uid,'gid':i.st_gid,'mode':format(stat.S_IMODE(i.st_mode),'04o'),'type':'symlink' if p.is_symlink() else 'directory' if p.is_dir() else 'file'}
def save(name,value):
    raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode();p=R/name
    fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    os.chown(p,11001,11001)
    fd=os.open(R,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
    return {'path':str(p),'sha256':sha(raw)}

provision=load('provisioning.json');environment=load('identity-dac-environment.json')
jailed=load('identity-qualification-completeviews.json');tests=load('native-synthetic-test-summary.json')
assert tests['passed'] and tests['results']['reference_and_dataset']['tests_run']==46
gate=load('gate1-native-tests.json')
assert gate['failures']==gate['errors']==gate['skips']==0
assert b'Ran 8 tests' in (R/'contract-tests.log').read_bytes() and b'\nOK\n' in (R/'contract-tests.log').read_bytes()
source_hashes={str(p.relative_to(SOURCE)):sha(p.read_bytes()) for p in SOURCE.rglob('*') if p.is_file()}
assert source_hashes==provision['deployed_source_hashes']
assert len(source_hashes)==67
sys.path.insert(0,str(SOURCE/'systems/NeuralField/src'))
from dataset.custody import read_profile,launcher_hash
profile=read_profile(Q/'profile.json')
assert launcher_hash(OPT/'qualification-runtime')==provision['launcher_sha256']
assert sha((Q/'profile.json').read_bytes())==provision['profile_sha256']
flags=command(['lsattr','-d',str(Q/'profile.json')]);assert 'i' in flags.split()[0]
for role,result in jailed['checks'].items():
    assert result['passed'] and result['groups']==[] and result['cap_eff']==result['cap_bnd']==0 and result['no_new_privs']==1 and result['fd_leak'] is False
    assert 'shared:' not in result['mountinfo']
inventory=[metadata(p) for root in (BASE,OPT) for p in [root]+sorted(root.rglob('*'))]
for p in [SOURCE]+list(SOURCE.rglob('*'))+[OPT/'qualification-venv']+list((OPT/'qualification-venv').rglob('*')):
    i=p.lstat();assert i.st_uid==0
    if not p.is_symlink():assert not i.st_mode&0o022
assert set(p.name for p in (Q/'inference').iterdir())=={'sentinel.txt'}
assert not (Path('/proc/self/mountinfo').read_text().find(str(Q/'jails')+'/probe-')>=0)
filesystem=json.loads(command(['findmnt','--json','--target',str(BASE/'P001'),'--output','TARGET,SOURCE,FSTYPE,UUID,OPTIONS']))['filesystems'][0]
assert filesystem['source']=='/dev/vda1' and filesystem['fstype']=='ext4'
capacity=os.statvfs(BASE/'P001')
host={'hostname':platform.node(),'kernel':platform.release(),'architecture':platform.machine(),'os_release':dict(line.split('=',1) for line in Path('/etc/os-release').read_text().splitlines() if '=' in line),'machine_id_sha256':sha(Path('/etc/machine-id').read_bytes()),'boot_id_sha256':sha(Path('/proc/sys/kernel/random/boot_id').read_bytes()),'cpu_count':os.cpu_count()}
binary_hashes={name:sha(Path(name).read_bytes()) for name in ('/usr/bin/python3','/usr/bin/unshare','/usr/bin/setpriv','/usr/bin/mount')}
artifact=save('final-resource-inventory.json',{'kind':'synthetic_qualification_resource_inventory','source_revision':provision['source_revision'],'inventory':inventory,'sentinel_contents_included':False,'production_qualified':False})
receipt_hashes=[{'path':str(p),'sha256':sha(p.read_bytes()),'mode':format(stat.S_IMODE(p.stat().st_mode),'04o'),'uid':p.stat().st_uid,'gid':p.stat().st_gid} for p in sorted(R.iterdir()) if p.is_file()]
for receipt in receipt_hashes:assert receipt['mode']=='0600' and receipt['uid']==receipt['gid']==11001
paths=[metadata(p) for p in [BASE,BASE/'P001',BASE/'P001/qualification-tests',Q,Q/'receipts',Q/'jails',Q/'profile.json',OPT,SOURCE,OPT/'qualification-runtime',OPT/'qualification-runtime/custody_worker.py',OPT/'qualification-runtime/consumer_probe.py',OPT/'qualification-venv',OPT/'bootstrap']]
paths += [item for item in inventory if item['path'].startswith(str(Q)) and '/receipts/' not in item['path'] and '/jails/' not in item['path'] and item['path'] not in {p['path'] for p in paths}]
requirements={name:{'status':'PROVEN','evidence':evidence} for name,evidence in {
 'native_ext4_store':'findmnt confirms /dev/vda1 and recorded UUID; no authoritative custody store on virtiofs or Docker overlay',
 'dedicated_locked_identities':'actual passwd/group records and executed UID/GID 11001, 11002, 11003; locked passwords, nologin, only separate primary groups',
 'consumer_groups_capabilities_nnp_descriptors':'unchanged jailed launcher; groups empty, effective/bounding caps zero, NoNewPrivs=1, no descriptor leak',
 'private_mount_and_pid_namespaces':'actual unshare/worker/probe executions, isolated proc, no shared propagation in recorded mountinfo',
 'private_sentinel_denials':'actual jailed consumers deny four private resources, traversal, aliases and label alias; actual custodian reads them',
 'approved_training_validation_reads_readonly':'actual training UID DAC checks plus readonly approved jailed view and approved sentinel read/write rejection',
 'inference_training_label_isolation':'actual inference UID denied training-label and validation sentinel paths; actual jailed mount view contains only approved inference sentinel, no training mount or records',
 'trusted_deployment':'67 source files match reviewed archive; root-owned source/venv/runtime; readonly deployed runtime; root-owned mode0600 immutable profile; structural and host admission pass',
 'pinned_dependencies':'isolated venv package versions equal both pinned dependency locks; no system-site packages or system pip installation',
 'atomic_no_overwrite_and_fsync_operations':'existing native Linux synthetic tests passed as nf-custodian on /var/lib/neuralfield/P001 ext4; no-overwrite admission and fsync failure rejection tested',
 'process_crash_recovery':'four actual os._exit(47) injection points WRITE, BEFORE_RENAME, AFTER_RENAME, AFTER_PARENT_FSYNC; incomplete generations quarantined, complete generations independently revalidated',
 'production_boundary_rejection':'existing production APIs and CLI rejection test passes; Gate 2 remains closed',
 'reference_dataset_contract_tests':'46 tests, zero failures/errors/skips; 8 contract tests pass; synthetic test artifacts only'
 }.items()}
requirements['power_loss_durability']={'status':'NOT TESTED','evidence':'No VM/power interruption authorized or performed. Successful fsync and process-crash recovery do not prove hardware, virtualization, or power-loss persistence.'}
requirements['production_generation_publication_final_input_release']={'status':'NOT TESTED','evidence':'Unauthorized and not executed; only opaque synthetic sentinels and bounded synthetic tests were created.'}
report={'report_version':'p001-b1-p-environment-report.v1','mission':'P001-B1-P','verdict':'ACCEPT','verdict_scope':'Bounded provisioning and synthetic qualification passed; independent review pending; no Gate 2 qualification or authority follows.','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_revision':provision['source_revision'],'source_archive_sha256':provision['archive_sha256'],'host':host,'filesystem':filesystem,'capacity_bytes':{'total':capacity.f_blocks*capacity.f_frsize,'available':capacity.f_bavail*capacity.f_frsize},'accounts':environment['accounts'],'profile':profile,'profile_file_sha256':provision['profile_sha256'],'qualification_canonical_profile_sha256':jailed['profile_sha256'],'profile_file_flags':flags,'launcher_sha256':provision['launcher_sha256'],'launcher_binary_hashes':binary_hashes,'dependencies':environment['environment'],'dependency_wheel_hashes':provision['dependency_wheels'],'pip_bootstrap':provision['pip_bootstrap'],'paths_and_permissions':paths,'full_inventory_receipt':artifact,'receipts':receipt_hashes,'requirements':requirements,'test_results':tests['results'],'test_git_provenance_caveat':'The deployed git archive has no .git: existing test receipt source_revision=null/source_state=dirty. Exact reviewed revision is independently bound by the archive hash and all 67 source hashes, not by fabricated Git metadata.','unchanged_probe_scope':'Inside-jail probes use the reviewed sentinel checks unchanged. Training-label/validation-specific DAC reads are supplemental actual-identity checks, combined with the isolated readonly mount view.','failed_checks':[],'remaining_unverified':['Power-loss and VM backing-storage durability','Independent review of these execution receipts','Separate Gate 2 authorization for real datasets/publication'], 'production_qualified':False,'gate2':'CLOSED','neural_and_benchmark':'CLOSED','sentinel_contents_included':False}
final=save('P001-B1-P-report.json',report)
print(json.dumps({'private_report':final,'public_report':report},sort_keys=True,indent=2))
