"""Run unchanged accepted qualification; keep detailed receipts private."""
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

Q=Path('/var/lib/neuralfield/qualification')
SOURCE=Path('/opt/neuralfield/qualification-source')
sys.path.insert(0,str(SOURCE/'systems/NeuralField/src'))
from dataset.codec import canonical,digest
from dataset.custody import qualification

def save(name,value):
 p=Q/'receipts'/name
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f:f.write(canonical(value));f.flush();os.fsync(f.fileno())
 os.chown(p,11001,11001)
 return {'path':str(p),'sha256':digest(p.read_bytes())}

try:
 result=qualification(str(Q/'profile.json'),'b60d63e39fe0601a55bfd67eac0d218054897996')
 artifact=save('identity-qualification.json',result)
 print(json.dumps({'phase':'identity-qualification','passed':True,'receipt':artifact,
                   'roles':{r:{k:v[k] for k in ('uid','gid','groups','cap_eff','cap_bnd','no_new_privs','fd_leak','passed')}
                            for r,v in result['checks'].items()},'production_qualified':False},sort_keys=True,indent=2))
except BaseException as error:
 artifact=save('identity-qualification-failure.json',{'phase':'identity-qualification','passed':False,
                'error_type':type(error).__name__,'error':str(error),'traceback':traceback.format_exc(),'production_qualified':False})
 print(json.dumps({'phase':'identity-qualification','passed':False,'error_type':type(error).__name__,'error':str(error),
                   'receipt':artifact,'production_qualified':False},sort_keys=True,indent=2))
 raise SystemExit(1)
