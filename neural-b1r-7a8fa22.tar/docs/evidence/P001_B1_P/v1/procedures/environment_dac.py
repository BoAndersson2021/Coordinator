"""Supplemental actual-identity DAC checks; no sentinel contents in output."""
import grp
import hashlib
import json
import os
from pathlib import Path
import platform
import pwd
import subprocess
import sys

Q=Path('/var/lib/neuralfield/qualification');SOURCE=Path('/opt/neuralfield/qualification-source')
VENV=Path('/opt/neuralfield/qualification-venv')
sys.path.insert(0,str(SOURCE/'systems/NeuralField/src'))
from dataset.codec import canonical,digest
from dataset.custody import qualification

def save(name,value):
 p=Q/'receipts'/name;fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f:f.write(canonical(value));f.flush();os.fsync(f.fileno())
 os.chown(p,11001,11001);return {'path':str(p),'sha256':digest(p.read_bytes())}

def add(path,raw,gid):
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o640)
 with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 os.chown(path,11001,gid);os.chmod(path,0o640)

profile=json.loads((Q/'profile.json').read_text())
add(Q/'training/training-labels.sentinel',b'synthetic-training-label-surrogate\n',11002)
add(Q/'training/validation.sentinel',b'synthetic-approved\n',11002)
paths=profile['private_paths']+[str(Q/'training/sentinel.txt'),str(Q/'training/training-labels.sentinel'),
       str(Q/'training/validation.sentinel'),str(Q/'inference/sentinel.txt')]
code='''import errno,json,os,sys
from pathlib import Path
status=dict(line.split(':',1) for line in Path('/proc/self/status').read_text().splitlines() if ':' in line)
reads={};writes={}
for name in sys.argv[1:]:
 try:Path(name).read_bytes();reads[name]={'read':True}
 except OSError as error:reads[name]={'read':False,'errno':error.errno}
 try:
  fd=os.open(name,os.O_WRONLY);os.close(fd);writes[name]={'open_write':True}
 except OSError as error:writes[name]={'open_write':False,'errno':error.errno}
print(json.dumps({'uid':os.getuid(),'gid':os.getgid(),'groups':os.getgroups(),'no_new_privs':int(status['NoNewPrivs'].strip()),'cap_eff':int(status['CapEff'].strip(),16),'cap_bnd':int(status['CapBnd'].strip(),16),'reads':reads,'write_access':writes},sort_keys=True))
'''
results={};accounts={}
for role,name,num in (('custodian','nf-custodian',11001),('training','nf-train',11002),('inference','nf-infer',11003)):
 entry=pwd.getpwnam(name)
 accounts[name]={'uid':entry.pw_uid,'gid':entry.pw_gid,'shell':entry.pw_shell,'home':entry.pw_dir,
                 'groups':os.getgrouplist(name,entry.pw_gid),
                 'password_status':subprocess.check_output(['passwd','--status',name],text=True).strip()}
 argv=['/usr/bin/setpriv','--reuid',str(num),'--regid',str(num),'--clear-groups','--bounding-set=-all','--inh-caps=-all',
       '--ambient-caps=-all','--no-new-privs',str(VENV/'bin/python'),'-B','-c',code,*paths]
 r=subprocess.run(argv,stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=20)
 if r.returncode:raise RuntimeError('identity probe failed: '+role+': '+r.stderr)
 result=json.loads(r.stdout)
 assert result['uid']==result['gid']==num and result['groups']==[] and result['cap_eff']==result['cap_bnd']==0 and result['no_new_privs']==1
 for path in profile['private_paths']:assert result['reads'][path]['read']==(role=='custodian')
 for path in paths[4:7]:assert result['reads'][path]['read']==(role in ('custodian','training'))
 assert result['reads'][paths[7]]['read']==(role in ('custodian','inference'))
 if role!='custodian':assert not any(v['open_write'] for v in result['write_access'].values())
 results[role]=result

versions_code='''import importlib.metadata,json,sys;print(json.dumps({'interpreter':sys.executable,'prefix':sys.prefix,'base_prefix':sys.base_prefix,'packages':{n:importlib.metadata.version(n) for n in ('numpy','jsonschema','attrs','referencing','jsonschema-specifications','rpds-py','typing-extensions')}},sort_keys=True))'''
environment=json.loads(subprocess.check_output([str(VENV/'bin/python'),'-B','-c',versions_code],text=True))
expected={'numpy':'1.26.4','jsonschema':'4.25.1','attrs':'25.4.0','referencing':'0.36.2','jsonschema-specifications':'2025.9.1','rpds-py':'0.27.1','typing-extensions':'4.15.0'}
assert environment['packages']==expected and environment['prefix']!=environment['base_prefix']
environment['lock_hashes']={n:digest((SOURCE/n).read_bytes()) for n in ('requirements-reference.txt','requirements-dataset.txt')}
environment['pyvenv_cfg_sha256']=digest((VENV/'pyvenv.cfg').read_bytes())
result={'source_revision':'b60d63e39fe0601a55bfd67eac0d218054897996','kind':'synthetic','host':platform.node(),
        'kernel':platform.release(),'accounts':accounts,'host_dac_checks':results,
        'host_dac_scope':'actual UID/GID/groups/capabilities; supplementary to, not replacing, jailed consumer checks',
        'environment':environment,'production_qualified':False}
artifact=save('identity-dac-environment.json',result)
# Rerun the unchanged jailed probes against the complete approved views.
jailed=qualification(str(Q/'profile.json'),result['source_revision'])
jailed_artifact=save('identity-qualification-completeviews.json',jailed)
assert (Q/'inference').is_dir() and set(p.name for p in (Q/'inference').iterdir())=={'sentinel.txt'}
print(json.dumps({'passed':True,'accounts':accounts,'environment':environment,'receipts':[artifact,jailed_artifact],
                  'inference_training_label_host_read_denied':not results['inference']['reads'][str(Q/'training/training-labels.sentinel')]['read'],
                  'inference_view_contains_no_training_or_private_records':True,
                  'jailed_roles_passed':{r:v['passed'] for r,v in jailed['checks'].items()},'production_qualified':False},sort_keys=True,indent=2))
