"""Explicit native renameat2 collision probe under custodian restrictions."""
import hashlib,json,os,subprocess
from pathlib import Path
Q=Path('/var/lib/neuralfield/qualification');R=Q/'receipts';TMP='/var/lib/neuralfield/P001/qualification-tests'
code='''import errno,json,os,sys,tempfile
from pathlib import Path
sys.path.insert(0,"/opt/neuralfield/qualification-source/systems/NeuralField/src")
from dataset.storage import NativeOps,write_exclusive
assert os.getuid()==os.getgid()==11001 and os.getgroups()==[]
ops=NativeOps()
with tempfile.TemporaryDirectory(prefix="native-nooverwrite-") as tmp:
 root=Path(tmp);a=root/"source";b=root/"published";c=root/"replacement"
 for p in (a,c):p.mkdir(mode=0o700);write_exclusive(p/"synthetic-probe",p.name.encode());ops.sync_dir(p)
 ops.sync_dir(root);ops.rename(a,b);ops.sync_dir(root)
 before=(b/"synthetic-probe").read_bytes()
 try:ops.rename(c,b)
 except OSError as error:assert error.errno==errno.EEXIST
 else:raise AssertionError("native no-overwrite collision accepted")
 assert (b/"synthetic-probe").read_bytes()==before and (c/"synthetic-probe").exists()
 print(json.dumps({"uid":os.getuid(),"gid":os.getgid(),"groups":os.getgroups(),"temporary_root":str(Path(tmp).parent),"native_renameat2":True,"collision_errno":errno.EEXIST,"destination_preserved":True,"replacement_preserved":True,"file_and_directory_fsync":True,"power_loss_durability":"NOT TESTED","production_qualified":False,"passed":True}))
'''
args=['/usr/bin/setpriv','--reuid','11001','--regid','11001','--clear-groups','--bounding-set=-all','--inh-caps=-all','--ambient-caps=-all','--no-new-privs','/usr/bin/env','TMPDIR='+TMP,'/opt/neuralfield/qualification-venv/bin/python','-B','-c',code]
r=subprocess.run(args,stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=30)
def save(name,value):
 raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode();p=R/name
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 os.chown(p,11001,11001)
 fd=os.open(R,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
 return {'path':str(p),'sha256':hashlib.sha256(raw).hexdigest()}
if r.returncode:
 print(json.dumps({'passed':False,'receipt':save('native-nooverwrite-failure.json',{'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'production_qualified':False})}));raise SystemExit(1)
result=json.loads(r.stdout);artifact=save('native-nooverwrite.json',result)
report=json.loads((R/'P001-B1-P-report.json').read_bytes())
report['explicit_native_nooverwrite_probe']={'result':result,'receipt':artifact}
report['requirements']['atomic_no_overwrite_and_fsync_operations']['evidence']+='; supplemental actual nf-custodian native renameat2 collision returned EEXIST and preserved both trees; file and directory fsync passed'
report['receipts']=[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'uid':p.stat().st_uid,'gid':p.stat().st_gid,'mode':format(p.stat().st_mode&0o777,'04o')} for p in sorted(R.iterdir()) if p.is_file()]
final=save('P001-B1-P-report.final.json',report)
print(json.dumps({'native_probe':result,'final_report':final},sort_keys=True,indent=2))
