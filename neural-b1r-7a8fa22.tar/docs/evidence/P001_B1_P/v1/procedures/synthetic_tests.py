"""Run accepted synthetic tests as the actual unprivileged custodian on ext4."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

SOURCE=Path('/opt/neuralfield/qualification-source')
Q=Path('/var/lib/neuralfield/qualification')
TMP=Path('/var/lib/neuralfield/P001/qualification-tests')
VENV=Path('/opt/neuralfield/qualification-venv/bin/python')
RECEIPT=TMP/'gate1-native-tests.json'
assert not RECEIPT.exists()
assert subprocess.check_output(['findmnt','-n','-o','SOURCE,FSTYPE','-T',str(TMP)],text=True).strip().split()==['/dev/vda1','ext4']
prefix=['/usr/bin/setpriv','--reuid','11001','--regid','11001','--clear-groups','--bounding-set=-all','--inh-caps=-all','--ambient-caps=-all','--no-new-privs','/usr/bin/env','TMPDIR='+str(TMP),'PYTHONDONTWRITEBYTECODE=1',str(VENV),'-B']

def save(name,raw):
    path=Q/'receipts'/name
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    os.chown(path,11001,11001)
    return {'path':str(path),'sha256':hashlib.sha256(raw).hexdigest()}

identity_code="import json,os;from pathlib import Path;s=dict(l.split(':',1) for l in Path('/proc/self/status').read_text().splitlines() if ':' in l);print(json.dumps({'uid':os.getuid(),'gid':os.getgid(),'groups':os.getgroups(),'cap_eff':int(s['CapEff'].strip(),16),'cap_bnd':int(s['CapBnd'].strip(),16),'no_new_privs':int(s['NoNewPrivs'].strip())}))"
identity=json.loads(subprocess.check_output(prefix+['-c',identity_code],text=True,cwd=SOURCE))
assert identity=={'uid':11001,'gid':11001,'groups':[],'cap_eff':0,'cap_bnd':0,'no_new_privs':1}
results={};artifacts=[]
for name,args in [('reference_and_dataset',[str(SOURCE/'tools/verify_gate1.py'),'--receipt',str(RECEIPT)]),('contract',['-m','unittest','discover','-s','tools','-p','test_b1_contract.py','-v'])]:
    r=subprocess.run(prefix+args,cwd=SOURCE,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=600)
    artifacts.append(save(name+'-tests.log',r.stdout+b'\n'+r.stderr))
    results[name]={'exit_code':r.returncode,'passed':r.returncode==0}
    if r.returncode:break
if RECEIPT.exists():
    os.chmod(RECEIPT,0o600)
    gate=json.loads(RECEIPT.read_bytes())
    artifacts.append(save('gate1-native-tests.json',RECEIPT.read_bytes()))
    results['reference_and_dataset'].update({k:gate[k] for k in ('tests_run','failures','errors','skips','passed','source_revision','source_state')})
    assert gate['source_revision'] is None  # Deployed git archive is bound separately, never falsify Git provenance.
else:gate=None
report={'kind':'synthetic_native_ext4_test_evidence','source_revision_binding':'b60d63e39fe0601a55bfd67eac0d218054897996','git_archive_scope':'archive has no .git; exact archive and source hashes are recorded in provisioning receipt','identity':identity,'temporary_root':str(TMP),'filesystem':'/dev/vda1 ext4','results':results,'artifacts':artifacts,'production_qualified':False,'power_loss_durability':'NOT TESTED','passed':all(r['passed'] for r in results.values()) and len(results)==2}
artifact=save('native-synthetic-test-summary.json',(json.dumps(report,sort_keys=True,indent=2)+'\n').encode())
print(json.dumps({'report':report,'summary_receipt':artifact},sort_keys=True,indent=2))
raise SystemExit(0 if report['passed'] else 1)
