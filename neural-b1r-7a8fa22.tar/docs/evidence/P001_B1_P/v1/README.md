# P001-B1-P qualification evidence v1

This is the retained evidence from bounded Colima provisioning and synthetic qualification of source revision `b60d63e39fe0601a55bfd67eac0d218054897996`. Independent qualification review is pending. The original report's `ACCEPT` means the operator completed that bounded mission; it is not an independent acceptance or Gate 2 authorization. Power-loss durability remains unresolved.

## Evidence and custody

| File | Evidence |
| --- | --- |
| [REPORT.json](REPORT.json) | Original report, unmodified; host/kernel, native filesystem UUID/options, binary hashes, paths/modes, dependencies and explicit unknowns. |
| [LAUNCH_PROFILE.json](LAUNCH_PROFILE.json) | Exact deployed root-owned, immutable configuration; metadata only. |
| [IDENTITY_NAMESPACE.json](IDENTITY_NAMESPACE.json) | Actual training/inference UID/GIDs, groups, capabilities, `NoNewPrivs`, descriptor checks, denied reads and complete jailed mountinfo. |
| [IDENTITY_DAC_ENVIRONMENT.json](IDENTITY_DAC_ENVIRONMENT.json) | Actual three-identity DAC checks, locked account status, approved/denied reads and dependency versions. |
| [NATIVE_NOOVERWRITE.json](NATIVE_NOOVERWRITE.json) | Actual custodian `renameat2(RENAME_NOREPLACE)` collision: EEXIST, both trees preserved, file/directory fsync successful. |
| [NATIVE_TEST_SUMMARY.json](NATIVE_TEST_SUMMARY.json) | Restricted custodian identity and ext4 test location; test/log hashes and outcomes. |
| [GATE1_NATIVE_TESTS.json](GATE1_NATIVE_TESTS.json) | All 46 named test outcomes, zero failures/errors/skips; exact tested Python source hashes. |
| [REFERENCE_DATASET_TESTS.log](REFERENCE_DATASET_TESTS.log) and [CONTRACT_TESTS.log](CONTRACT_TESTS.log) | Original outcome-only logs: 46 reference/dataset tests and eight contract tests. |
| [DEPLOYMENT_PROVENANCE.json](DEPLOYMENT_PROVENANCE.json) | Allowlisted provisioning metadata, all 67 deployed source hashes, reviewed archive hash, wheel/lock hashes and resource creation list. |
| [SANITIZATION.json](SANITIZATION.json) | Original and exported hashes, retained fields and export exclusions. |
| [MANIFEST.json](MANIFEST.json) | Fixed v1 package inventory and SHA-256 of every payload file. |

The exact report SHA-256 is `062809f3d7261395f5ec53411ed197af405a10e3b437fe0efaaa67008c3fff6a`. The combined deployed worker/probe hash is `8ffe0a2e30867a6163aac7fc7d7d7493a46b5a762d81a8e562ac364ae2b16bdc`; profile hash is `3cbe83144a82c67e19d50bb0f0b9ca32cd3bb81b0b2c0ef73688e8d4a72a82e9`. Exported originals match the hashes already recorded in that report. The provisioning receipt was reduced to explicitly listed metadata, and both its original and exported hashes are recorded. The final resource inventory, private sentinel contents, protected file contents, dataset records, credentials and dependency download/install logs are excluded.

All authoritative originals remain custodian-owned mode 0600 within a mode 0700 receipt directory on `/dev/vda1` ext4. The exporter compared every exported byte stream against the actual private sentinel values in VM memory, without exporting those values. The export itself did not reprovision the VM or rerun qualification. These are operator-collected receipts, not a signed or independently attested host record.

## Verification and limits

Run `python3 -B tools/verify_qualification_evidence.py` from the repository root with the existing pinned reference dependencies and the baseline Git object available. The verifier checks the fixed manifest, schemas, receipt consistency, original receipt hashes, all deployed source hashes against the baseline Git tree, the archive hash, launcher/profile/lock bindings, identity restrictions, mount views, native outcomes and closed authority. It performs no provisioning, qualification, dataset generation or publication. CI validation of these records is not a repeat Linux host qualification.

The [custody contract](../../../../systems/NeuralField/experiments/P001/custody.v1.json) remains unchanged and `specification_only_not_enforced` for production. The synthetic profile was enforced in the tested Colima environment only. Its isolated mounts expose the intended role view read-only. Custodian private reads were executed as UID/GID 11001, rather than substituted with root reads.

The original Gate 1 test runner does not execute the identity launcher, so its receipt correctly retains `actual_uid_isolation=not_executed`. Actual identity evidence is in the two separate identity receipts. The deployed source is a Git archive without `.git`, so that runner also correctly records `source_revision=null` and `source_state=dirty`. No source metadata was repaired: the archive hash and all 67 file hashes independently bind the deployed copy to the stated baseline.

The unchanged jailed probes directly check the approved sentinel and its write denial, four private sentinels, traversal/alias attempts, `/data/final-labels`, host-proc isolation, capabilities and descriptors. Training-label/validation-specific checks are supplemental actual-identity host DAC tests, combined with the recorded isolated mount views. They are not falsely represented as additional inside-jail probe operations. The inference pipe contains only an approved synthetic string, not a final experiment input.

The native process-crash test passes at four `os._exit(47)` points: `WRITE:training/queries.jsonl`, `BEFORE_RENAME`, `AFTER_RENAME`, and `AFTER_PARENT_FSYNC`. The first two must quarantine unpublished generations; the latter two must revalidate and admit only a complete generation. The named pass and assertions in the frozen test source/log are the retained evidence; no separate per-crash completion receipts or synthetic label records were retained for export after temporary test cleanup. Other fault-injection tests explicitly use the existing simulated backend; they are not represented as native filesystem proofs.

Successful native rename/fsync operations and process-crash recovery do not establish VM backing-storage or power-loss durability. No power interruption was performed. Native syscall atomicity, process-crash recovery and power-loss durability remain separate claims.

## Recorded procedures

The operator scripts are retained as inert evidence for inspection: [qualification](procedures/qualification.py), [supplemental DAC/environment checks](procedures/environment_dac.py), [synthetic test execution](procedures/synthetic_tests.py), [report assembly](procedures/final_report.py), and [explicit no-overwrite probe](procedures/native_nooverwrite.py). Their hashes describe the retained procedure files; the earlier execution receipts do not contain a signed attestation of those script hashes. Some procedures create exclusive synthetic resources or receipts and are not repeat-safe. Do not execute them as a consequence of reviewing this package; fresh host execution requires its own authorization.

## Immutability and next gate

Review the package at the delivered PR commit SHA. The verifier pins the manifest hash, which in turn hashes every payload, including this index and the recorded procedures. Git commit addressing preserves that snapshot; future evidence must use a new version directory and retain v1. Hashes establish integrity and binding, not the truth of an untrusted observation.

Gate 2, real training/validation/final dataset creation, production publication, final-input release, neural implementation/training/inference and A/B benchmarking remain closed. The next action is independent review of these actual records against the accepted contract and explicit consideration of the unresolved durability requirement. No repository merge is authorized.
