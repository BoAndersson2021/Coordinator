# P001-B1-I Gate 1 verification

Baseline: `8be84508e8fed30d860552d265bf89ef84f23d44`. Scope: [Gate 1 packet](P001_B1_I_WORK_PACKET.md), [dataset package](../systems/NeuralField/src/dataset/README.md) and [synthetic tests](../systems/NeuralField/tests/test_dataset.py). No real dataset, production publication, final input release, model or experimental benchmark is produced.

## Commands

```sh
python3 -B tools/validate_phase0.py --stage P001-B1-I
python3 -B -m unittest discover -s tools -p 'test_b1_contract.py' -v
python3 -B tools/verify_gate1.py --receipt /tmp/neural-gate1-receipt.json
git diff --check 8be84508e8fed30d860552d265bf89ef84f23d44 HEAD
```

The receipt runner executes existing reference tests and new dataset tests, recording exact source revision, dirty-state/hash, outcomes and skips. It preserves intentionally tested failures as named passing rejection tests and distinguishes native Linux tests from simulation. Temporary stores are cleaned after tests; detailed label-disagreement evidence is asserted inside private quarantine before cleanup. No real labels or sealed query records are included in public receipts.

## Custody and durability limits

No qualified Linux host or preexisting nf-custodian/nf-train/nf-infer identities are available in this macOS session. Privileged provisioning is not authorized. Real namespace/identity denied-read qualification has not been executed; these source paths are reviewable but not production-certified. Portable tests prove control-flow rejection and synthetic recovery using an explicitly identified simulation backend. Linux CI tests native rename/fsync and process interruption, without sudo or account creation. Neither constitutes power-loss qualification of the eventual production filesystem.

The launcher is implemented as an administrator-invoked synthetic probe: validated root-owned profile; preprovided resource paths; unshare mount/PID namespaces; private jailed /proc; read-only runtime/consumer bind mounts; group/capability clearing; UID/GID drop and no-new-privileges. A missing identity/profile, mount failure, capability failure or denied-check failure closes admission. The qualification schema always records production_qualified=false. Gate 2 remains independently closed even if such a receipt exists.

Linux primitive rationale follows the primary manual pages for [renameat2](https://www.man7.org/linux/man-pages/man2/rename.2.html), [directory fsync](https://www.man7.org/linux/man-pages/man2/fsync.2.html), [private mounts](https://www.man7.org/linux/man-pages/man7/mount_namespaces.7.html), and [no-new-privileges](https://www.man7.org/linux/man-pages/man2/PR_SET_NO_NEW_PRIVS.2const.html). No fallback to overwrite/copy publication or weakened process isolation is introduced.

## Delivery evidence

### PR #4 review correction

The independent review of `621c5d776433018696a7aa31a275742b4062e3d2` identified consumer-view ancestry that could reach host admission. Regression tests reproduced the defect before the fix: 22 failing subcases covered both consumer ancestry directions, deeper nesting, jail/consumer nesting and private-root nesting. The validator now checks every pair of configured resource roots for equality or ancestry before code/host checks. No nested-root exception is contracted in v1. Five focused custody tests pass, including positive sibling and lexical-prefix cases and assertions that invalid profiles never call identity checks or subprocess launch.

The correction changes only custody validation, regression tests and verification/handover documentation. Frozen research contracts and unconditional Gate 2 closure are preserved. Updated full-suite receipts and final-head CI are required below; no actual host provisioning or dataset creation is performed.

Verified implementation revision: `35f24d927ed2da6a224ffe5e96c168d4c0017bcd`. Local Python 3.9.6 verification ran 46 tests: 44 passed and two native Linux tests skipped. The eight B1-C contract regression tests pass separately. The staged validator passes 67 explicit files, 175 local links, 14 canonical JSON contracts and 29 schema cases; whitespace and accepted-source preservation checks pass.

The [committed synthetic test receipt](evidence/P001_B1_I_GATE1_LOCAL.json) records that clean implementation revision, all test outcomes, skips and exact source hashes. Its SHA-256 is `b93a449188f8e1508f611dcf8e238ea3fb9908e884750b8ce420adedf53dda33`. It contains no dataset records. The initial draft receipt runner rejected /private/tmp because macOS selected a different default temporary root; the runner now recognizes both standard temporary roots and the CI-provided RUNNER_TEMP while still rejecting repository output paths. This was a test-report path issue, not an oracle disagreement or loosened dataset authority.

Final-head Linux CI must pass both Python 3.9 and 3.12, including the native rename/process-crash cases. Its exact run/head and uploaded public receipts are reported by the PR. Independent review and merge remain pending. Gate 2 additionally requires separately authorized creation and actual-host identity/filesystem qualification; P001-B2 and P001-C remain closed.
