# Neural research architecture

Authority: [mission](REPOSITORY_INITIALIZATION_MISSION.md), [thesis](../THESIS.md), then [protocol](EXPERIMENT_PROTOCOL.md). Concrete P001 semantics are owned by [P001_SPEC.md](../systems/NeuralField/P001_SPEC.md), its [geometry](../systems/NeuralField/experiments/P001/geometry.v1.json), and [schemas](../systems/NeuralField/src/common/README.md).

## Independent execution

The future conventional runner A accepts a versioned snapshot and logical query, evaluates deterministic geometry/lattice algorithms, and emits the response contract. It can generate labels offline. The future neural runner B loads a frozen model plus scenario metadata, validates and encodes the same query, performs only learned inference, and decodes into the same response contract. Neither runner starts the other. Each must run in a fresh process without the other implementation importable.

Measured B must not load label tables, graph distances, ray results, geometry evaluators, exact-coordinate tactical caches, or A modules. Its allowed runtime artifacts are weights, model configuration, schema constants, and a manifest containing snapshot identity and fixed scenario parameters. Geometry identity is a hash, not access to obstacle evaluation. A and B are benchmarked against identical immutable query arrays; the comparator sees A labels only after B results are written and hashed.

Shared `src/common` owns wire schemas, structural validation, finite/domain checks, constant actor/scenario validation, normalization, serialization, and timing interfaces. It cannot test obstacles, compute traversal, intersect rays, reconstruct paths, or correct predictions. Dependencies point from A/B to common; B must never depend on conventional. Offline training may read training/validation labels; final labels and A are unavailable in its execution environment. Training code is a separate process from measured B.

A later hybrid runner must have a different experiment identifier, declare verification/fallback policy, preserve raw predictions, and charge every validation and fallback operation. It is not B in P001.

## Authority and result classes

| Class | P001 example | Evaluation and use |
| --- | --- | --- |
| Exact | Traversability, reachability, visibility, first obstruction identity | A must match strict definitions. B's predictions are scored as exact-class predictions, including false positives; even passing B cannot authorize gameplay. |
| Approximate | Exposure fraction, route-cost estimate, first-hit distance | Compare in stated physical units with P001 budgets. Preserve raw outputs; do not silently snap, relabel, or validate them using A. |
| Advisory | Ranking otherwise legal cover choices | Not a fourth query and not a measured P001 output. Future ranking requires its own definition; it cannot change legality. |

Reference geometry and snapshot are world truth. A's implementation must itself pass analytical fixtures and independent label checks; being called a reference does not make a buggy algorithm authoritative. B's exposed schema has the same logical meaning as A's, but its truth claims are experimental predictions.

## Query and response law

P001 has one cover, one navigation, and one shooting contract. Each request includes `schema_version`, `snapshot_id`, `query_id`, `domain`, and `input`. Each response repeats those identifiers, adds `implementation` (`A` or `B`), `status`, and `output`. Units are metres and dimensionless fractions; no arbitrary score replaces a reference metric. Probabilities/logits belong in optional diagnostic artifacts, not the common result contract.

`ok` means the request was accepted and an output was produced, not that the predicted location is legal. Cover at an obstructed actor location returns false traversability and null metrics. Navigation separates blocked start/destination from valid but disconnected starts; cost is null unless reachable. Shooting accepts target points in solid geometry and reports obstruction. No conventional route or path is required from B.

Status priority is: `invalid_input` for malformed/non-finite requests; `out_of_domain` for a well-typed unsupported scenario/version/coordinate/actor; `model_failure` for unavailable artifacts, non-finite numerical results, or output inconsistency; otherwise `ok`. Non-ok output is null. Structural validation is identical in both runners. Valid coordinates inside obstacles must reach each implementation and cannot be rejected by shared code.

`query_id` is opaque identity and must never be an input feature. Response identity mismatch, missing row, extra row, invalid schema, or model failure is a scored failure, not a discarded example. Unknown snapshots cannot select a convenient model silently. Error responses echo unsupported string domain/snapshot/version identities; successful responses require the accepted P001 identities. Malformed envelope identities use the row-indexed error-record policy in P001 rather than inventing a valid identity.

## Responsibilities and artifacts

| Area | Owner and boundary |
| --- | --- |
| `experiments/P001` | Versioned geometry, preregistration, split recipes, future immutable dataset/model manifests. No measured outputs in configuration files. |
| `src/common` | Schemas and non-tactical plumbing; no geometry truth. |
| `src/conventional` | A variants and oracle; deterministic labels and accounted preprocessing. |
| `src/neural` | Local offline training, export, and isolated B inference, in distinct entrypoints. |
| `tests` | Schema/invariant fixtures, analytic reference cases, isolation and leakage checks. |
| `benchmarks` | Paired workloads, timers, lifecycle and memory measurement. No favorable-only variant selection. |
| `results` | Append-only run directories and raw evidence, including failures, under the protocol. |

Phase 0 contains only contracts and responsibility documents. These directories establish ownership without implementing their future runners.
