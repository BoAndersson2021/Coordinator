# P001-B1-D — Bounded integrity and regeneration verification

This is a specification, not execution permission. [Integrity contract](P001_B1_D_INTEGRITY_CONTRACT.md), [custody v2](../systems/NeuralField/experiments/P001/custody.v2.json), and [machine-readable integrity requirements](../systems/NeuralField/experiments/P001/integrity.v1.json) govern the proposed checks. Gate 2 remains closed. No new dataset, host probe, disk change or failure test is run by this correction.

## Evidence already available

The accepted [v1 evidence package](evidence/P001_B1_P/v1/README.md) contains actual Linux identities, restricted namespaces/capabilities/descriptors, approved/denied reads, native ext4 no-overwrite/fsync results, and normal process-crash recovery outcomes. Those results retain their original source/contract bindings. They do not become real-dataset evidence or power-loss guarantees after this correction.

The [read-only storage topology](evidence/P001_B1_D/v1/TOPOLOGY.json) and [primary source hashes](evidence/P001_B1_D/v1/SOURCES.json) stay unchanged. No further physical storage research, live VZ synchronization-property instrumentation, full-sync replacement or power interruption is required for P001. Repeat custody checks only when relevant deployed identities, launcher/runtime, permissions, mounts or storage mapping change.

## Smallest future recovery checks

Use a separately authorized, disposable reduced synthetic store and the actual reviewed conventional/reference and consumer profiles. Keep source/geometry/seeds/recipes/dependency locks fixed and record expected identity, content hashes/counts and custody contract version. These checks can represent post-VM/host-failure outcomes without actually interrupting the VM/host; they test admission logic, not physical survival probabilities.

| Check | Required result |
| --- | --- |
| Reproduce scientific content twice | Same canonical semantic queries and independently verified labels; metadata differences explained and actual full artifact hashes recorded |
| Registered generation absent | Loss record created; old identity invalidated; no admission/success for the missing generation |
| Loss followed by fresh regeneration | New identity, correct frozen content, complete provenance/independent verification and atomic publication; old identity remains retired |
| Invalidated old directory reappears | No automatic revival, even if its old bytes are internally consistent |
| Complete post-rename survivor without invalidation | Independent complete audit and required local sync before normal admission under its original identity |
| Partial files, truncation, wrong label, changed query or mismatched receipt | Close consumption; retain input/expected/actual/version diagnostics privately; no silent fix or successful publication |
| Changed data with rewritten self-consistent manifest under a trusted identity | Reject against trusted registered hashes/provenance; independent checks must not substitute trust in the candidate's own manifest |
| Missing registration or ambiguous/conflicting committed state | No admission; report unresolved state; recover trusted provenance before any fresh generation |
| Required write/fsync/rename failure or collision | No successful local publication response; no overwrite or partial consumer authority; private failure evidence retained |
| Normal producer interruption | Staging is quarantined; only independently verified complete committed state is admitted |
| Train/final/inference boundary after recovery/regeneration | Actual consumer profiles retain approved reads and all required denied reads; final release remains separately closed |
| Exposure history survives regeneration workflow | No tuning, changed recipe, reset final freeze, adaptive rerun or substitution of missing evaluation evidence |

Zero corrupt/partial admissions, identity reuse after invalidation, label leaks and successful responses after required operation failures are permitted. Dataset disappearance itself is not a failed survival promise. Preserve negative evidence and all available loss/corruption diagnostics. Do not pick new seeds, reduce quotas or resample until favorable results appear.

## Future receipts and integration

Each authorized generation/recovery receipt records source and contract versions/hashes, geometry/snapshot, recipe/seeds/RNG state, dependency locks, trusted expected identity/hash/counts, independent verification and split audits, local synchronization/publication outcomes, access-profile binding and admission decision. Loss records retain the retired identity and available bindings; replacement lineage and detailed failure/exposure diagnostics remain custodian-private. Public fields remain the existing custody allowlist, with no sealed requests/labels or sentinel contents. A receipt cannot contain its own hash.

Gate 1 source currently pins custody v1, uses synthetic-only receipt schemas and rejects real production APIs unconditionally. A later bounded implementation packet must explicitly bind reviewed v2/integrity metadata and implement/verify loss invalidation and fresh-generation lineage before real consumption. The correction does not modify that source, manufacture v2 execution receipts or infer generation permission from a synthetic pass. No new cloud/model service or fault-independent storage system is needed.

Checks should target the existing recovery boundary rather than recreate publication infrastructure. Retain accepted deterministic/geometry/isolation checks. A mismatch blocks the affected labels or consumption path. Synthetic missing/corrupt artifacts are created only in a fresh disposable store under separate authorization; never truncate, delete or alter the live custody store to simulate a host failure.

## Optional stronger profile

Guest/VM/host crashes, physical power testing and full-chain persistence qualification belong only to a separately selected production-strength profile. They require their own approval, isolated targets and backup/rollback boundaries. They are not required to complete or consume independently verified P001 research data. An optional profile must not become a hidden dependency in the P001 launcher, receipt validator or checklist.

Next action is independent contract review, followed by separately bounded Gate 2 authorization and any necessary source/provenance alignment. This PR grants no implementation, generation, final-input exposure, neural work, benchmarking or merge authority.
