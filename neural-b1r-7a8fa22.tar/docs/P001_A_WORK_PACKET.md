# P001-A — Conventional Reference Foundation

Repository: WRRTREPO/NEURAL. System: NeuralField. Baseline: `247e78ce07831eebd8c5c8f9157c12bcdf50279c`. Branch: `impl/p001-a-conventional-reference`.

**Status: explicitly authorized by the user for implementation and PR submission. Merge is not authorized. P001-B/P001-C remain closed.** Phase 0 was accepted in [Review 2](https://github.com/WRRTREPO/NEURAL/pull/1#issuecomment-6116437477) and merged in PR #1. This packet records the subsequent bounded authorization; historical Phase 0 status text does not widen or negate it.

## Objective and authority

Build a deterministic, independently verified conventional reference for cover, navigation and shooting. The merged [P001 specification](../systems/NeuralField/P001_SPEC.md), [canonical geometry](../systems/NeuralField/experiments/P001/geometry.v1.json), [query](../systems/NeuralField/src/common/query.schema.json)/[response](../systems/NeuralField/src/common/response.schema.json) schemas, [architecture](ARCHITECTURE.md) and [experiment protocol](EXPERIMENT_PROTOCOL.md) govern semantics. No convenience change to their laws is authorized. Geometry owns truth; A calculates it and independent tests verify it. Passing this stage cannot authorize label generation.

## Authorized boundary

1. Common structural/type validation, micrometre/domain checks, snapshot/scenario identity, status precedence, response enforcement, finite-value rejection and serialization. Common code must not calculate tactical truth.
2. Immutable canonical geometry; actor-square collision, world bounds, closed contact, exact segment/rectangle intersection, endpoint/tangent/corner/collinear cases and deterministic first-hit ties.
3. Direct A0 cover's 17 rays, 63² cardinal navigation graph/reachability/shortest cost and shooting obstruction. Add A1 precomputed navigation only after A0 independently passes. A0/A1 must agree on all registered unit/reference fixtures.
4. Independent polygon intersection, node/swept-footprint classification, Dijkstra distances, graph symmetry/legal-edge invariants, public analytical cases and common schema/error cases.
5. Dedicated branch and PR, reproducible local tests and CI, Plan/Handover evidence and a returned commit SHA, failure/dependency report and verdict.

## Closed work

No neural architecture/weights/training/inference, experiment datasets (training/validation/final), label-generation pipeline, experimental results, performance comparison/benchmark claims, A2 exact-query caching, dynamics or Unreal integration. In-memory deterministic unit fixtures and their test logs are verification, not experiment datasets or timing evidence.

## Failure and acceptance

Keep oracle disagreements as failing tests with input, expected and actual values plus snapshot identity; CI preserves logs. Never repair answers silently or weaken tolerances. Contract ambiguity closes the affected surface pending clarification. Incorrect labels must not enter a training artifact, and no such artifact is created here.

Acceptance requires common/status and analytical cases to pass; independent segment agreement; exhaustive verification of all 3,969 nodes and legal edge candidates; independent shortest costs and A0/A1 equivalence; reproducibility from commit; immutable geometry with no hidden runtime mutation; inspectable failures; repository validation and CI; and no forbidden implementation/data. [Verification](P001_A_VERIFICATION.md) records implementation evidence, subject to independent PR review.

Stop after PR submission and reporting its checks. Do not merge, begin P001-B or generate datasets. The next gate is independent review of P001-A; later stage authorization is separate.
