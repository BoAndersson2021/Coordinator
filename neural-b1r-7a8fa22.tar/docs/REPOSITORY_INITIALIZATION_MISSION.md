# NEURAL — Repository Initialization Mission

**Repository:** `NEURAL`  
**System:** `NeuralField`  
**Mission:** Establish the research thesis, experimental contracts, and repository foundation for NeuralField.  
**Phase:** 0 — Research Foundation  
**Status:** Authorized for documentation and repository scaffolding only.

---

## 1. Mission

Initialize the `NEURAL` repository as a controlled research project investigating small, specialized neural networks for game-engine spatial computation.

The first system is **NeuralField**.

NeuralField investigates whether small, isolated neural networks can represent and evaluate spatial relationships in tactical game environments more efficiently than conventional runtime algorithms.

The objective is not to prove that neural networks are superior.

The objective is to establish, through reproducible A/B experiments, where neural representations provide measurable advantages, where they fail, and whether they are viable for production game engines.

**Do not implement the neural network or conventional runtime during this mission.**

First establish the research contract.

## 2. Central Thesis

A small, specialized neural network may encode and evaluate spatial relationships within a game level at lower runtime or memory cost than conventional algorithms, while maintaining sufficient correctness for practical gameplay use.

Three initial domains are investigated:

1. **Cover:** Protection, exposure, and directional defensive suitability.
2. **Navigation:** Traversability, connectivity, movement costs, and route suitability.
3. **Shooting lanes:** Geometric visibility, obstruction, and firing opportunities.

The research will investigate whether a shared learned spatial representation can efficiently answer these queries.

No performance, accuracy, compression, or generalization advantage is assumed.

## 3. Mandatory A/B Architecture

Every proof must contain two independent implementations.

### A — Conventional

A deterministic implementation using conventional spatial algorithms.

Examples include geometry queries, raycasts, navigation graphs, pathfinding, and tactical evaluation.

This is the reference implementation and may generate training labels.

### B — Neural

A small trained network or learned spatial representation.

It receives the same logical query and returns the same defined output schema.

It must not invoke the conventional tactical evaluation implementation during measured inference unless the experiment explicitly defines and accounts for a hybrid architecture.

### Comparison Law

Both implementations must share:

- Identical environment geometry and world-state snapshots.
- Identical query semantics and output units.
- Identical test inputs.
- Identical correctness criteria.
- Comparable runtime measurement conditions.
- Explicit memory accounting.

They must remain independently executable.

The conventional implementation is the reference for geometric correctness, but is not automatically the optimal performance baseline. Relevant precomputation, caching, and batching must be represented fairly.

## 4. Research Questions

**R1 — Representation**

Can a small neural network encode the tactical relationships of a fixed game level?

**R2 — Correctness**

How accurately can it reproduce geometric and navigational results, particularly at discontinuities such as walls, corners, narrow passages, and occlusion boundaries?

**R3 — Performance**

Under what workloads, if any, does neural inference outperform conventional computation?

**R4 — Memory**

Can learned representations reduce memory or storage requirements compared with conventional spatial data structures?

**R5 — Dynamics**

How effectively can learned spatial representations accommodate changing doors, destroyed cover, moving actors, and other world-state changes?

**R6 — Scalability**

How do performance and correctness change with level complexity, query volume, and agent population?

## 5. Research Hypotheses

### H1 — Spatial Compression

A small neural representation can approximate tactical fields using less memory than an equivalent conventional representation at comparable accuracy.

### H2 — Query Efficiency

For sufficiently complex spatial queries, neural inference can provide lower amortized runtime cost than conventional evaluation.

### H3 — Shared Representation

One learned spatial representation can provide multiple tactical properties more efficiently than independently evaluating those properties.

### H4 — Spatial Generalization

A trained network can produce useful results at positions and orientations absent from its training samples.

All four hypotheses must remain falsifiable.

The project must preserve negative results rather than tuning experiments solely to produce a neural advantage.

## 6. Proof Roadmap

### P001 — Static 2D Tactical Field

Construct a small, fixed 2D tactical environment.

Investigate cover, navigation, and shooting-lane queries through conventional and neural implementations.

Measure correctness, execution cost, memory use, and spatial error distribution.

No dynamic geometry or Unreal integration.

### P002 — Dynamic Spatial State

Introduce doors, destructible cover, and other controlled state changes.

Measure adaptation, invalidation, and update costs.

### P003 — Multi-Agent Query Load

Measure shared-field performance under increasing numbers of simulated agents.

Include batching, latency, throughput, and worst-case behavior.

### P004 — 3D Spatial Representation

Extend to elevation, multiple floors, vertical obstruction, and more complex traversal topology.

### P005 — Native Engine Integration

Evaluate integration into a native C++ runtime and subsequently Unreal Engine, contingent on earlier results.

The roadmap establishes research order, not authorization to implement all phases.

## 7. P001 Experimental Contract

Prepare a specification for the smallest meaningful experiment.

The initial environment should be a fixed 16 × 16 metre tactical space containing:

- Solid obstacles.
- A narrow passage.
- Cover-producing geometry.
- A fixed shooting origin.
- A fixed navigation destination.

The exact geometry must be specified and versioned.

Define independent query contracts for:

**Cover query**

Inputs: candidate position, threat position or direction, and required actor geometry.

Outputs: explicitly defined protection or exposure metrics.

**Navigation query**

Inputs: start position, destination, and actor traversal parameters.

Outputs: traversability, reachability, and route cost, with separate definitions for invalid and unreachable locations.

**Shooting query**

Inputs: firing position, target position, and relevant firing geometry.

Outputs: geometric line-of-fire visibility and obstruction information.

Do not confuse geometric visibility with tactical desirability.

Do not conflate navigation legality with route preference.

Do not define outputs as arbitrary neural scores without corresponding reference semantics.

The agent must specify:

- Coordinate system and units.
- World boundaries and obstacle geometry.
- Collision and actor dimensions.
- Query schemas.
- Output schemas and tolerances.
- Ground-truth generation.
- Training/validation/test separation.
- Boundary and adversarial test cases.
- Performance measurement procedure.
- Memory measurement procedure.
- Acceptance and rejection criteria.

Do not invent final numerical accuracy or performance thresholds without documenting their rationale. Establish correctness requirements independently of observed neural results.

## 8. Authority and Failure Boundaries

The reference geometry and world-state snapshot are authoritative.

Neural predictions are experimental outputs, not proof of geometric truth.

A neural implementation may approximate connectivity, traversability, or visibility for research purposes. Such predictions must not silently become authoritative movement or firing permissions.

Separate three result classes:

1. **Exact:** Outputs requiring strict correctness.
2. **Approximate:** Outputs permitting bounded numerical error.
3. **Advisory:** Outputs used to rank otherwise legal choices.

Specify how invalid inputs, non-finite outputs, and out-of-domain queries are handled.

A hybrid implementation that verifies neural predictions against conventional geometry is permitted as a later experiment, but must be separately identified and benchmarked with its full verification cost.

## 9. Reproducibility Contract

Every experiment must record:

- Experiment identifier and revision.
- Source revision.
- Geometry and world-state version.
- Query dataset identity and generation seed.
- Network architecture and parameter count.
- Training configuration.
- Weight artifact identity and hash.
- Compiler and runtime configuration.
- Hardware and execution environment.
- Correctness results.
- Latency and throughput results.
- Memory results.
- Failure cases.

Training, validation, and final test datasets must be separated.

Results must be machine-readable.

Benchmark results must distinguish initialization, training, preprocessing, inference, validation, and amortized total cost.

Preserve raw measurements and sufficient metadata to reproduce the reported statistics.

## 10. Repository Structure

Use the existing repository structure where present. Do not overwrite or reorganize unrelated work.

Establish the following logical structure:

```text
NEURAL/
├── README.md
├── THESIS.md
├── docs/
│   ├── ARCHITECTURE.md
│   ├── EXPERIMENT_PROTOCOL.md
│   └── RESEARCH_ROADMAP.md
├── systems/
│   └── NeuralField/
│       ├── README.md
│       ├── P001_SPEC.md
│       ├── src/
│       │   ├── common/
│       │   ├── conventional/
│       │   └── neural/
│       ├── tests/
│       ├── benchmarks/
│       └── experiments/
│           └── P001/
└── results/
```

`NEURAL` is the repository and research umbrella.

`NeuralField` is the first research system.

Future neural systems must be able to coexist within `NEURAL` without inheriting NeuralField-specific assumptions.

## 11. Implementation Restrictions

During Phase 0:

**Authorized:**

- Inspect the existing repository.
- Create or refine documentation.
- Establish directories.
- Define schemas and experiment contracts.
- Identify unresolved technical decisions.
- Prepare an implementation-ready P001 work packet.

**Prohibited:**

- Implementing conventional tactical algorithms.
- Implementing or training neural networks.
- Creating benchmark results.
- Claiming measured performance improvements.
- Integrating Unreal Engine.
- Introducing external model services or cloud dependencies.
- Treating earlier exploratory Python prototypes as verified evidence.
- Expanding into P002–P005 implementation.

Do not create empty placeholder source files merely to populate the proposed structure.

## 12. Required Deliverables

Produce:

1. `README.md` — Repository purpose, system index, and research status.
2. `THESIS.md` — Governing research thesis, hypotheses, and falsification conditions.
3. `docs/ARCHITECTURE.md` — A/B architecture, authority boundaries, and separation of responsibilities.
4. `docs/EXPERIMENT_PROTOCOL.md` — Reproducibility, correctness, benchmarking, and evidence requirements.
5. `docs/RESEARCH_ROADMAP.md` — P001–P005 sequence and advancement gates.
6. `systems/NeuralField/README.md` — System-specific scope and status.
7. `systems/NeuralField/P001_SPEC.md` — Implementation-grade first experiment specification.

All documents must agree on terminology, ownership, and experimental boundaries.

## 13. Acceptance Gates

Phase 0 is complete only when:

- The thesis is explicit and falsifiable.
- Conventional and neural implementations have independent execution boundaries.
- The three tactical query types have unambiguous semantics.
- Exact, approximate, and advisory results are distinguished.
- The P001 geometry and coordinate laws are fully specified.
- Training and final evaluation cannot contaminate each other.
- Benchmark methodology accounts for comparable end-to-end work.
- Neural false positives for traversability and visibility are explicitly measured.
- Reproducibility requirements are sufficient for an independent rerun.
- Failure criteria are defined before implementation.
- The P001 work packet can be executed without further architectural invention.
- No implementation or benchmark evidence has been fabricated.

## 14. Agent Execution Order

1. Inspect repository HEAD, current files, and existing conventions.
2. Report conflicts with the proposed structure before destructive changes.
3. Establish the governing thesis.
4. Define the A/B architecture and authority model.
5. Define the experiment protocol.
6. Specify P001 completely.
7. Cross-check all documents for contradictory contracts.
8. Validate document paths, references, and repository changes.
9. Report completed files, unresolved decisions, and acceptance status.

Do not advance to implementation.

## 15. Final Report

Return:

**Verdict:** ACCEPT, ACCEPT WITH CHANGES, or BLOCKED BY MISSING SOURCE.

Include:

- Repository revision.
- Files created or modified.
- Material architectural decisions.
- Unresolved dependencies.
- Verification performed.
- Phase 0 acceptance result.
- Exact next implementation frontier.

**Stop after Phase 0. Await authorization before implementing P001.**

---

**Governing principle:**

NeuralField is an engineering experiment, not a demonstration.

The conventional implementation establishes the reference. The neural implementation challenges it. Correctness, performance, memory, and reproducibility determine the outcome.
