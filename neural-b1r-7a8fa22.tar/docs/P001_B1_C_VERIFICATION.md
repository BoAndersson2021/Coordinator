# P001-B1-C verification

Baseline: `e77d0489daf3b73a4003358680de50d59c50a67a`. Scope is the [contract correction](P001_B1_CONTRACT.md), static [public registry](../systems/NeuralField/experiments/P001/public-fixtures.v1.json), static [custody specification](../systems/NeuralField/experiments/P001/custody.v1.json), documentation and validator regressions. No dataset, label, neural or benchmark artifact is introduced.

## Reproduction

From repository root with the existing pinned reference dependencies:

```sh
python3 -B tools/validate_phase0.py --stage P001-B1-C
python3 -B -m unittest discover -s tools -p 'test_b1_contract.py' -v
python3 -B -m unittest discover -s systems/NeuralField/tests -p 'test_*.py' -v
git diff --check e77d0489daf3b73a4003358680de50d59c50a67a HEAD
```

The validator checks explicit inventory, local links, canonical JSON, schemas, prior review protections, frozen governing file hashes, unchanged recipe paragraphs, declared registry/table agreement, exhaustive navigation classification and custody/publication invariants. Contract regression tests intentionally mutate registry entries, split/challenge rules and custody/publication requirements; each mutation must be rejected. They do not generate a dataset or prove OS isolation.

## Evidence and limits

Local Python 3.9.6 checks passed: 41 explicit nonempty files, 141 local links, six canonical JSON contracts and 29 schema cases. All 3,969 navigation nodes are classified without labels: four public exclusions, 225 reserved challenges, 2,336 ordinary training nodes, 476 validation nodes and 928 ordinary final nodes. Thus the final navigation assignment includes 1,153 nodes counting challenges; these are recipe counts, not generated datasets.

Eight contract regression tests pass, including intentional rejection of fixture expansion/omission/duplication, added labels, query-ID identity, public-table mismatch, quotas/seeds/tiles/challenge/rounding changes, geometry/query/model/quality prose drift, weakened process isolation and publication bypasses. Existing conventional tests pass: 23 tests, all 3,969 independent shortest-path/A0/A1 comparisons, 15,624 directed edge candidates, 7,376 independent segment cases, 922 shooting requests and 492 actor/cover boundary points.

Two draft check failures were found and corrected before submission: the documentation guard required its canonical exclusion sentence without an intervening parenthesis; a mutation test used a geometry phrase absent from the source and was corrected to mutate the actual world-bound expression. Neither was an oracle disagreement. No tolerance or acceptance gate was relaxed.

Verified correction commit: `dec57521a746b5fb920729b48fa8fe27aa4980c5`. Whitespace checks passed and all eight reference source/test/dependency files remain byte-identical to baseline; governing hashes and protected prose pass. The final receipt commit changes only documentation. Final-head CI runs these checks on Python 3.9 and 3.12; the PR records those results. Author checks do not establish independent contract acceptance.

Custody is specification-only. No dedicated Linux host, identities, permissions, namespaces, filesystem durability or actual consumer denied-read profile has been provisioned or exercised. Production custody qualification and failure-injection implementation remain prerequisites to any future sealed artifact creation. No permission failure or test fixture is presented as measured neural evidence.

Next gate: independent B1-C contract review. No merge, B1-I dataset implementation, neural work or P001-C execution is authorized.
