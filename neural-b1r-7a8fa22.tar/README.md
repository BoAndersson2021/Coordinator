# NEURAL

NEURAL studies small, specialized neural networks through controlled, reproducible engineering experiments. Its first focus is game-engine spatial computation. No accuracy, performance, compression or generalization advantage is assumed.

## Mission and status

The [Repository Initialization Mission](docs/REPOSITORY_INITIALIZATION_MISSION.md) governs this work. Phase 0, P001-A, B1-C, Gate 1, [B1-P synthetic qualification evidence](docs/evidence/P001_B1_P/v1/README.md) and [custody v2 / integrity](docs/P001_B1_D_INTEGRITY_CONTRACT.md) are accepted and merged through `0e30cba9818f933e91ede0400dc61230aaf32a86`. [B1-R runtime alignment](docs/P001_B1_R_IMPLEMENTATION.md) implements trusted registration, loss invalidation and explicit fresh synthetic regeneration under the owner's bounded authorization. Missing trust closes admission. Geometric correctness, isolation and atomic publication remain required; guaranteed host-power survival is optional production work. No real datasets, neural candidate or A/B measurements exist. Gate 2, P001-B2, P001-C and merge remain closed.

## Research documents

- [THESIS.md](THESIS.md): hypotheses, falsification and claim boundaries.
- [Architecture](docs/ARCHITECTURE.md): independent A/B execution and authoritative geometry.
- [Experiment protocol](docs/EXPERIMENT_PROTOCOL.md): correctness, reproducibility, performance, memory and statistics.
- [Research roadmap](docs/RESEARCH_ROADMAP.md): phase order and advancement gates.
- [Phase 0 verification](docs/PHASE0_VERIFICATION.md): checks and their limits.

## System index

- [NeuralField](systems/NeuralField/README.md): cover, navigation and shooting-lane queries in tactical environments. [P001 specification](systems/NeuralField/P001_SPEC.md) defines the fixed 16 × 16 metre first experiment and its complete contracts.

Future systems can coexist under `systems/` with independent contracts; NeuralField assumptions are system-specific. [Results policy](results/README.md) establishes evidence storage without inventing experiment output.

## Agent workflow

Start with [AGENTS.md](AGENTS.md), then read the governing documents and assigned system specification. [Plan.md](Plan.md) records execution and completion; [Handover.md](Handover.md) records committed context and the next gate. The current next action is **independent P001-B1-R implementation review**. Conventional query runners are documented in [NeuralField](systems/NeuralField/README.md).
