# P001-B1-R plan

Baseline: `0e30cba9818f933e91ede0400dc61230aaf32a86`. Owner authorization covers the accepted [PR #7 packet](https://github.com/WRRTREPO/NEURAL/pull/7) and reduced synthetic execution only. [Implementation contract](docs/P001_B1_R_IMPLEMENTATION.md).

| Work | State | Evidence |
| --- | --- | --- |
| R1 — v2/provenance binding | Implemented; verification in progress | Pinned custody v2/integrity hashes, retained v1 parent, versioned current schemas. |
| R2 — immutable registration and serialization | Implemented; verification in progress | Private expectations/catalog, checked atomic inventory, store-local interprocess lock. |
| R3 — loss and retirement | Implemented; verification in progress | Private immutable losses, restart-safe rejection, no candidate-based trust recovery. |
| R4 — recovery/fresh replay | Implemented; verification in progress | Independent complete admission, explicit bounded replacement, exact context and private lineage. |
| R5 — synthetic faults/concurrency | In progress | Portable tests plus native Linux exits and competing processes. |
| Independent review | Pending | Dedicated implementation PR; PR #7 remains the packet record. |
| Gate 2 / neural / benchmarks / merge | Closed | No real datasets, production publication, final exposure or advancement. |
