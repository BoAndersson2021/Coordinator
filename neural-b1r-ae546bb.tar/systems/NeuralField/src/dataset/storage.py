"""Synthetic immutable generations, no-overwrite commit, quarantine and admission."""
from contextlib import contextmanager
import threading
import ctypes
import errno
import os
from pathlib import Path
import re
import stat
import sys
import tempfile

from dataset.artifacts import verify_bundle, schema_check
from dataset.authority import require_gate2
from dataset.codec import canonical, decode, digest


class AdmissionFailure(RuntimeError):
    def __init__(self, category, evidence=None):
        self.evidence=evidence
        super().__init__(category)


class NativeOps:
    name='linux-native' if sys.platform=='linux' else 'unsupported-native'
    def __init__(self):
        if sys.platform!='linux':raise AdmissionFailure('Linux atomic publication unavailable')
    def rename(self, source, destination):
        if sys.platform!='linux':raise AdmissionFailure('Linux renameat2 unavailable; no production fallback')
        libc=ctypes.CDLL(None,use_errno=True)
        try:fn=libc.renameat2
        except AttributeError:raise AdmissionFailure('renameat2 unavailable')
        fn.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint]
        fn.restype=ctypes.c_int
        if fn(-100,os.fsencode(source),-100,os.fsencode(destination),1):
            error=ctypes.get_errno();raise OSError(error,os.strerror(error),str(destination))

    def replace(self, source, destination):
        os.replace(source,destination)

    def sync_file(self, path):
        fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
        try:os.fsync(fd)
        finally:os.close(fd)

    def sync_dir(self, path):
        fd=os.open(path,os.O_RDONLY|getattr(os,'O_DIRECTORY',0)|getattr(os,'O_NOFOLLOW',0))
        try:os.fsync(fd)
        finally:os.close(fd)


def secure_tree(path, uid, device):
    """Reject aliases, special files, writable groups, ownership and filesystem drift."""
    for item in [path]+list(path.rglob('*')):
        info=item.lstat()
        if info.st_uid!=uid or info.st_dev!=device or stat.S_ISLNK(info.st_mode):raise AdmissionFailure('ownership/device/alias')
        if not (stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode)):raise AdmissionFailure('special file')
        if stat.S_ISREG(info.st_mode) and info.st_nlink!=1:raise AdmissionFailure('external hardlink')
        if info.st_mode&0o022:raise AdmissionFailure('group/other write authority')
        if stat.S_ISREG(info.st_mode) and info.st_mode&0o077:raise AdmissionFailure('private file permissions')
        if stat.S_ISDIR(info.st_mode) and info.st_mode&0o077:raise AdmissionFailure('private directory permissions')
        if hasattr(os,'listxattr'):
            attrs=os.listxattr(item)
            if any('acl' in n.lower() for n in attrs):raise AdmissionFailure('unexpected ACL')


def write_exclusive(path, raw):
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
    try:
        with os.fdopen(fd,'wb') as stream:
            stream.write(raw);stream.flush();os.fsync(stream.fileno())
    except BaseException:raise


class SyntheticStore:
    """Temporary, bounded synthetic authority; no production or deployment admission."""
    MARKER={'store_version':'p001-synthetic-store.v2','kind':'synthetic','production_qualified':False}

    def __init__(self, root, recipe, labeler, *, ops=None, hook=None):
        path=Path(root)
        temps=(Path(tempfile.gettempdir()).resolve(),Path('/tmp').resolve())
        if '..' in path.parts or path.is_symlink() or not any(path.resolve().is_relative_to(t) and path.resolve()!=t for t in temps):
            raise AdmissionFailure('synthetic store must be a private temporary child')
        self.root=path.resolve();self.recipe=recipe;self.labeler=labeler
        self.ops=NativeOps() if ops is None else ops;self.hook=(lambda point:None) if hook is None else hook
        self.root.mkdir(mode=0o700,parents=True,exist_ok=True)
        if stat.S_IMODE(self.root.stat().st_mode)!=0o700:raise AdmissionFailure('synthetic root permissions')
        self.uid=os.getuid();self.device=self.root.stat().st_dev
        self.mutex=threading.RLock();self.recovered=False
        from dataset.trust import Catalog
        self.catalog=Catalog(self)
        with self._lock(initial=True):
            marker=self.root/'.synthetic-store.json'
            if not marker.exists():
                if set(p.name for p in self.root.iterdir())!={'.lock'}:raise AdmissionFailure('nonempty unmarked store')
                for name in ('.staging','generations','quarantine','diagnostics'):(self.root/name).mkdir(mode=0o700)
                self.catalog.initialize()
                self._write(marker,canonical(self.MARKER));self.ops.sync_dir(self.root)
            secure_tree(self.root,self.uid,self.device)
            if decode(marker.read_bytes())!=self.MARKER:raise AdmissionFailure('store version/identity')
            self._structure();self.catalog.load()

    @contextmanager
    def _lock(self, initial=False):
        try:import fcntl
        except ImportError:raise AdmissionFailure('interprocess locking unavailable')
        with self.mutex:
            flags=os.O_RDWR|getattr(os,'O_NOFOLLOW',0)
            if initial and not (self.root/'.synthetic-store.json').exists():flags|=os.O_CREAT
            fd=os.open(self.root/'.lock',flags,0o600)
            try:
                info=os.fstat(fd)
                if info.st_uid!=self.uid or info.st_dev!=self.device or not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or stat.S_IMODE(info.st_mode)!=0o600:
                    raise AdmissionFailure('unsafe store lock')
                fcntl.flock(fd,fcntl.LOCK_EX)
                yield
            except BaseException:
                self.recovered=False
                raise
            finally:os.close(fd)

    def _structure(self):
        secure_tree(self.root,self.uid,self.device)
        if set(p.name for p in self.root.iterdir())!={'.synthetic-store.json','.lock','.trust','.staging','generations','quarantine','diagnostics'}:
            raise AdmissionFailure('store closure')
        for name in ('.trust','.staging','generations','quarantine','diagnostics'):
            if not (self.root/name).is_dir():raise AdmissionFailure('missing private store resource')

    def _write(self, path, raw):
        # Both catalog and payload synchronization faults use the same testable primitive.
        write_exclusive(path,raw)
        self.hook('AFTER_FILE_FSYNC:'+str(path.relative_to(self.root)))

    @staticmethod
    def identity(generation):
        if type(generation) is not str or not re.fullmatch(r'synthetic-[a-zA-Z0-9-]{1,64}',generation):raise AdmissionFailure('synthetic generation identity')

    def event(self, stage, state):
        fd=os.open(stage/'events.jsonl',os.O_WRONLY|os.O_APPEND|os.O_CREAT|getattr(os,'O_NOFOLLOW',0),0o600)
        with os.fdopen(fd,'ab') as stream:stream.write(canonical({'state':state,'kind':'synthetic'}));stream.flush();os.fsync(stream.fileno())

    def quarantine(self, stage, reason):
        record={'kind':'synthetic','state':'QUARANTINED','reason':str(reason),'evidence':None}
        if hasattr(reason,'evidence'):record['evidence']=reason.evidence
        schema_check('failure.schema.json',record)
        if not (stage/'failure.json').exists():self._write(stage/'failure.json',canonical(record))
        self.event(stage,'QUARANTINED');secure_tree(stage,self.uid,self.device)
        self.ops.sync_dir(stage)
        self.ops.rename(stage,self.root/'quarantine'/stage.name)
        self.ops.sync_dir(self.root/'.staging');self.ops.sync_dir(self.root/'quarantine')

    def _diagnostic(self, error):
        # Only private diagnostic files retain label-level evidence. Never print it.
        raw=canonical({'category':type(error).__name__,'evidence':getattr(error,'evidence',None)})
        directory=self.root/'diagnostics'
        name=digest(raw)+'.json'
        if not (directory/name).exists():self._write(directory/name,raw)
        self.ops.sync_dir(directory)

    def _read(self, directory):
        secure_tree(directory,self.uid,self.device)
        excluded={'events.jsonl','completion.json'}
        return {str(p.relative_to(directory)):p.read_bytes() for p in directory.rglob('*') if p.is_file() and str(p.relative_to(directory)) not in excluded}

    def _admit(self, generation, records):
        self.identity(generation)
        if generation not in records['registrations'] or generation in records['losses']:raise AdmissionFailure('unregistered or retired generation')
        expected=records['registrations'][generation]
        directory=self.root/'generations'/generation
        artifact=self._read(directory);raw=(directory/'completion.json').read_bytes()
        if digest(artifact['manifest.json'])!=expected['manifest_sha256'] or digest(raw)!=expected['completion_sha256']:
            raise AdmissionFailure('trusted artifact expectation mismatch',{'generation_id':generation,'expected_manifest_sha256':expected['manifest_sha256'],'actual_manifest_sha256':digest(artifact['manifest.json']),'expected_completion_sha256':expected['completion_sha256'],'actual_completion_sha256':digest(raw)})
        receipt=decode(raw);schema_check('completion.v2.schema.json',receipt)
        metadata=decode(artifact['private/provenance.json'])
        if metadata!=expected['provenance']:raise AdmissionFailure('trusted replay context mismatch')
        manifest=verify_bundle(artifact,self.recipe,self.labeler)
        if receipt['generation_id']!=generation or receipt['source_revision']!=metadata['source_revision'] or receipt['manifest_sha256']!=digest(artifact['manifest.json']) or receipt['counts']!=manifest['counts'] or receipt['counts']!=expected['counts']:
            raise AdmissionFailure('completion mismatch')
        events=[decode(line) for line in (directory/'events.jsonl').read_bytes().splitlines(keepends=True)]
        if events!=[{'kind':'synthetic','state':state} for state in ('GENERATING','VERIFYING','VERIFIED')]:raise AdmissionFailure('invalid state history')
        for path in directory.rglob('*'):
            if path.is_file():self.ops.sync_file(path)
        for path in sorted([directory]+[p for p in directory.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):self.ops.sync_dir(path)
        return receipt

    def _recover(self):
        self.recovered=False;self._structure()
        _,records=self.catalog.load()
        committed={p.name:p for p in (self.root/'generations').iterdir()}
        staged={p.name:p for p in (self.root/'.staging').iterdir()}
        if set(committed)&set(staged):raise AdmissionFailure('conflicting staged/committed identities')
        for identity,path in list(committed.items())+list(staged.items()):
            self.identity(identity)
            if not path.is_dir():raise AdmissionFailure('ambiguous generation object')
        # Validate all survivors before returning any authority or performing loss disposition.
        admitted=[]
        for identity in sorted(committed):admitted.append(self._admit(identity,records))
        for identity in sorted(staged):
            self.quarantine(staged[identity],'interrupted unpublished generation')
        for identity in sorted(records['registrations']):
            if identity not in committed and identity not in records['losses']:
                self.catalog.retire(identity,'interrupted_unpublished_generation' if identity in staged else 'registered_generation_missing')
        self.ops.sync_dir(self.root/'.staging');self.ops.sync_dir(self.root/'generations')
        self.recovered=True
        return admitted

    def recover(self):
        with self._lock():
            try:return self._recover()
            except Exception as error:
                self._diagnostic(error)
                raise

    def admit(self, generation):
        with self._lock():
            if not self.recovered:raise AdmissionFailure('recovery/admission gate not completed')
            receipts=self._recover()
            return next((r for r in receipts if r['generation_id']==generation),None) or self._deny()

    @staticmethod
    def _deny():raise AdmissionFailure('generation not admitted')

    def invalidate(self, generation):
        with self._lock():
            self.identity(generation);self.recovered=False;self._structure();self.catalog.load()
            if (self.root/'generations'/generation).exists() or (self.root/'.staging'/generation).exists():
                raise AdmissionFailure('retirement requires absent synthetic generation')
            return self.catalog.retire(generation,'explicit_synthetic_retirement')

    def _publish(self, generation, artifact, replacement=None):
        self.identity(generation)
        self._recover();self.recovered=False
        index,records=self.catalog.load()
        if generation in records['registrations'] or any((self.root/n/generation).exists() for n in ('.staging','generations','quarantine')):raise AdmissionFailure('generation ID already used')
        stage=self.root/'.staging'/generation;dest=self.root/'generations'/generation
        stage.mkdir(mode=0o700);self.ops.sync_dir(self.root/'.staging')
        try:
            self.event(stage,'GENERATING')
            from dataset.artifacts import FILES,VERSION
            if set(artifact)!=set(FILES)|{'manifest.json'}:raise AdmissionFailure('artifact paths')
            # Trusted producer verifies the bounded in-memory bundle before registering
            # expectations, then independently verifies the persisted bytes again.
            manifest=verify_bundle(artifact,self.recipe,self.labeler)
            receipt={'artifact_version':VERSION,'kind':'synthetic',
                     'generation_id':generation,'state':'SYNTHETIC COMMITTED','production_qualified':False,
                     'manifest_sha256':digest(artifact['manifest.json']),'counts':manifest['counts'],
                     'source_revision':manifest['source_revision'],'contract_versions':['p001-custody.v2','p001-integrity.v1'],
                     'verification_pass':True,'custody_pass':False,'backend':self.ops.name}
            schema_check('completion.v2.schema.json',receipt);raw=canonical(receipt)
            registration={'record_version':'p001-synthetic-registration.v1','kind':'synthetic','generation_id':generation,
                          'manifest_sha256':receipt['manifest_sha256'],'completion_sha256':digest(raw),
                          'counts':manifest['counts'],'provenance':decode(artifact['private/provenance.json']),'replacement':replacement}
            if replacement is not None:
                old=records['registrations'][replacement['retired_generation_id']]
                if any(registration[k]!=old[k] for k in ('provenance','manifest_sha256','counts')):raise AdmissionFailure('regeneration changed frozen content')
            self.catalog.add('registrations',generation,registration);self.hook('GENERATING')
            for name,payload in artifact.items():
                path=stage/name;path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
                self._write(path,payload);self.hook('WRITE:'+name)
            self.event(stage,'VERIFYING');self.hook('VERIFYING')
            verify_bundle(self._read(stage),self.recipe,self.labeler)
            self.event(stage,'VERIFIED');self.hook('VERIFIED')
            self._write(stage/'completion.json',raw);self.hook('AFTER_RECEIPT')
            for directory in sorted([stage]+[p for p in stage.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):self.ops.sync_dir(directory)
            secure_tree(stage,self.uid,self.device);self.hook('BEFORE_RENAME')
            self.ops.rename(stage,dest);self.hook('AFTER_RENAME')
            self.ops.sync_dir(self.root/'.staging');self.ops.sync_dir(self.root/'generations');self.hook('AFTER_PARENT_FSYNC')
            receipts=self._recover()
            return next(r for r in receipts if r['generation_id']==generation)
        except Exception as error:
            self.recovered=False
            if stage.exists():self.quarantine(stage,error)
            raise
        except BaseException:
            self.recovered=False
            raise

    def publish(self, generation, artifact):
        with self._lock():
            if not self.recovered:raise AdmissionFailure('recover before publish')
            return self._publish(generation,artifact)

    def regenerate(self, retired, fresh):
        """Explicit reduced replay only; missing trust never triggers generation."""
        with self._lock():
            self.identity(retired);self.identity(fresh);self._recover()
            index,records=self.catalog.load()
            if retired not in records['losses']:raise AdmissionFailure('trusted loss required for regeneration')
            from dataset.pipeline import synthetic_bundle
            context=records['registrations'][retired]['provenance']
            artifact=synthetic_bundle(context['source_revision'],self.recipe,self.labeler)
            replacement={'retired_generation_id':retired,'loss_sha256':index['losses'][retired]}
            self.hook('BEFORE_REPLACEMENT')
            return self._publish(fresh,artifact,replacement)


def production_publish(*, authorization=None, qualification=None):
    require_gate2(authorization=authorization,qualification=qualification)
