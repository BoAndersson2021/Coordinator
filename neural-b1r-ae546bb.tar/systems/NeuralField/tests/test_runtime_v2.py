"""B1-R reduced synthetic trust tests; native exits/locks require Linux, not host qualification."""
import copy
import multiprocessing
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

SRC=Path(__file__).resolve().parents[1]/'src'
sys.path.insert(0,str(SRC))
from dataset.codec import canonical,decode,digest
from dataset.recipe import Recipe,HASHES,contracts,SYSTEM
from dataset.labeling import Labeler,VerificationFailure
from dataset.pipeline import synthetic_bundle
from dataset.storage import SyntheticStore,NativeOps,AdmissionFailure
from dataset.trust import TrustFailure
from test_dataset import SimulatedOps

FAILURE_CHECKS=[]

REVISION='0e30cba9818f933e91ede0400dc61230aaf32a86'


def child_publish(root,bundle,point=None,ready=None,release=None):
    def hook(event):
        if event==point:
            if ready is not None:
                ready.set()
                if not release.wait(30):os._exit(99)
            else:os._exit(47)
    store=SyntheticStore(root,Recipe(),Labeler(),hook=hook);store.recover()
    store.publish('synthetic-old',bundle)


def child_operation(root,operation,queue,bundle=None):
    try:
        store=SyntheticStore(root,Recipe(),Labeler());result=store.recover()
        if operation=='publish':store.publish('synthetic-old',bundle)
        if operation=='invalidate':store.invalidate('synthetic-old')
        queue.put((operation,'pass',len(result)))
    except Exception:queue.put((operation,'rejected',None))


class TrustTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.recipe=Recipe();cls.labeler=Labeler();cls.bundle=synthetic_bundle(REVISION,cls.recipe,cls.labeler)

    def observe(self,point,execution,outcome):
        FAILURE_CHECKS.append({'test':self.id(),'point':point,'execution':execution,'outcome':outcome})

    def store(self,root,ops=None,hook=None):
        store=SyntheticStore(root,self.recipe,self.labeler,ops=ops or SimulatedOps(),hook=hook)
        store.recover();return store

    def test_active_contracts_and_v1_parent_are_pinned(self):
        active=contracts()
        for name in ('custody.v1.json','custody.v2.json','integrity.v1.json'):
            self.assertEqual(digest((SYSTEM/'experiments/P001'/name).read_bytes()),HASHES[name])
        self.assertEqual(active['custody.v2.json']['supersedes']['sha256'],HASHES['custody.v1.json'])
        real=Path.read_bytes
        for target in ('custody.v2.json','integrity.v1.json'):
            def wrong(path):
                if path.name==target:return canonical(active['custody.v1.json'])
                return real(path)
            with patch.object(Path,'read_bytes',wrong):
                with self.assertRaises(ValueError):Recipe()
            def missing(path):
                if path.name==target:raise FileNotFoundError('contract unavailable')
                return real(path)
            with patch.object(Path,'read_bytes',missing):
                with self.assertRaises(FileNotFoundError):Recipe()

    def test_trusted_registration_binds_exact_bytes_before_publication(self):
        with tempfile.TemporaryDirectory() as temp:
            store=self.store(Path(temp)/'store');receipt=store.publish('synthetic-old',self.bundle)
            trusted=decode((store.root/'.trust/registrations/synthetic-old.json').read_bytes())
            self.assertEqual(trusted['manifest_sha256'],digest(self.bundle['manifest.json']))
            self.assertEqual(trusted['completion_sha256'],digest(canonical(receipt)))
            self.assertEqual(trusted['counts'],{'training':6,'validation':6,'final':10})
            for name in ('custody.v2.json','integrity.v1.json'):
                key='systems/NeuralField/experiments/P001/'+name
                self.assertEqual(trusted['provenance']['contract_hashes'][key],HASHES[name])
            self.assertEqual(receipt['contract_versions'],['p001-custody.v2','p001-integrity.v1'])
            self.assertNotIn('registration_sha256',receipt)  # no digest cycle

    def test_unregistered_internally_valid_candidate_never_admitted(self):
        with tempfile.TemporaryDirectory() as temp:
            original=self.store(Path(temp)/'original');original.publish('synthetic-old',self.bundle)
            target=self.store(Path(temp)/'target')
            shutil.copytree(original.root/'generations/synthetic-old',target.root/'generations/synthetic-old')
            with self.assertRaises(AdmissionFailure):target.recover()
            self.assertFalse(target.recovered)
            self.assertEqual(decode((target.root/'.trust/index.json').read_bytes())['registrations'],{})
            self.assertTrue(list((target.root/'diagnostics').iterdir()))

    def test_forged_manifest_receipt_and_version_confusion_rejected(self):
        for mutate in ('manifest','receipt','v1','nested-extra'):
            with self.subTest(mutate=mutate),tempfile.TemporaryDirectory() as temp:
                store=self.store(Path(temp)/'store');store.publish('synthetic-old',self.bundle)
                path=store.root/'generations/synthetic-old'
                if mutate=='manifest':
                    value=decode((path/'manifest.json').read_bytes());value['source_revision']='a'*40
                    (path/'manifest.json').write_bytes(canonical(value))
                    receipt=decode((path/'completion.json').read_bytes());receipt['manifest_sha256']=digest((path/'manifest.json').read_bytes())
                    (path/'completion.json').write_bytes(canonical(receipt))
                elif mutate=='nested-extra':
                    (path/'private/completion.json').write_bytes(b'{}\n');(path/'private/completion.json').chmod(0o600)
                else:
                    value=decode((path/'completion.json').read_bytes())
                    if mutate=='v1':value['artifact_version']='p001-dataset-artifacts.v1'
                    else:value['generation_id']='synthetic-forged'
                    (path/'completion.json').write_bytes(canonical(value))
                with self.assertRaises((AdmissionFailure,VerificationFailure)):store.recover()
                self.assertFalse(store.recovered)

    def test_missing_catalog_never_rebuilt_from_candidate_or_regenerated(self):
        for missing in ('index.json','registrations/synthetic-old.json','losses'):
            with self.subTest(missing=missing),tempfile.TemporaryDirectory() as temp:
                store=self.store(Path(temp)/'store');store.publish('synthetic-old',self.bundle)
                path=store.root/'.trust'/missing
                if path.is_dir():path.rmdir()
                else:path.unlink()
                with patch('dataset.pipeline.synthetic_bundle',side_effect=AssertionError('must not regenerate')):
                    with self.assertRaises(Exception):store.regenerate('synthetic-old','synthetic-new')
                with self.assertRaises(Exception):SyntheticStore(store.root,self.recipe,self.labeler,ops=SimulatedOps())
                self.assertFalse(path.exists())
                self.assertFalse(store.recovered)

    def test_loss_is_idempotent_and_regeneration_has_private_lineage(self):
        with tempfile.TemporaryDirectory() as temp:
            store=self.store(Path(temp)/'store');old=store.publish('synthetic-old',self.bundle)
            saved=Path(temp)/'saved';shutil.move(store.root/'generations/synthetic-old',saved)
            self.assertEqual(store.recover(),[])
            first=(store.root/'.trust/losses/synthetic-old.json').read_bytes()
            self.assertEqual(store.recover(),[])
            self.assertEqual(first,(store.root/'.trust/losses/synthetic-old.json').read_bytes())
            new=store.regenerate('synthetic-old','synthetic-new')
            self.assertNotEqual(old['generation_id'],new['generation_id'])
            self.assertNotEqual(digest(canonical(old)),digest(canonical(new)))
            directory=store.root/'generations/synthetic-new'
            for name,raw in self.bundle.items():self.assertEqual((directory/name).read_bytes(),raw)
            record=decode((store.root/'.trust/registrations/synthetic-new.json').read_bytes())
            self.assertEqual(record['replacement'],{'retired_generation_id':'synthetic-old','loss_sha256':digest(first)})
            self.assertNotIn('replacement',new)
            self.assertEqual([r['generation_id'] for r in store.recover()],['synthetic-new'])
            with self.assertRaises(AdmissionFailure):store.publish('synthetic-old',self.bundle)
            shutil.copytree(saved,store.root/'generations/synthetic-old')
            with self.assertRaises(AdmissionFailure):store.recover()
            with self.assertRaises(AdmissionFailure):store.admit('synthetic-new')

    def test_restart_retirement_missing_loss_and_conflicting_trust_fail_closed(self):
        with tempfile.TemporaryDirectory() as temp:
            store=self.store(Path(temp)/'store');store.publish('synthetic-old',self.bundle)
            shutil.rmtree(store.root/'generations/synthetic-old');store.recover()
            restarted=self.store(store.root)
            with self.assertRaises(AdmissionFailure):restarted.admit('synthetic-old')
            loss=store.root/'.trust/losses/synthetic-old.json';loss.unlink()
            with self.assertRaises(TrustFailure):restarted.recover()
            self.assertFalse(restarted.recovered)
        with tempfile.TemporaryDirectory() as temp:
            store=self.store(Path(temp)/'store');store.publish('synthetic-old',self.bundle)
            record=store.root/'.trust/registrations/synthetic-old.json';record.write_bytes(b'{"x":1,"x":2}\n')
            with self.assertRaises((TrustFailure,ValueError)):store.recover()

    def test_trust_permissions_hardlinks_symlinks_and_traversal_rejected(self):
        for kind in ('permissions','hardlink','symlink','nonfinite'):
            with self.subTest(kind=kind),tempfile.TemporaryDirectory() as temp:
                store=self.store(Path(temp)/'store');store.publish('synthetic-old',self.bundle)
                record=store.root/'.trust/registrations/synthetic-old.json'
                if kind=='permissions':record.chmod(0o644)
                elif kind=='hardlink':os.link(record,Path(temp)/'alias')
                elif kind=='symlink':
                    saved=Path(temp)/'saved';record.rename(saved);record.symlink_to(saved)
                else:record.write_bytes(b'{"x":NaN}\n')
                with self.assertRaises(Exception):store.recover()
            with self.assertRaises(AdmissionFailure):self.store(Path(temp)/'../bad')

    def test_independent_label_disagreement_closes_recovered_authority(self):
        with tempfile.TemporaryDirectory() as temp:
            store=self.store(Path(temp)/'store');store.publish('synthetic-old',self.bundle)
            with patch.object(store.labeler,'verify',side_effect=VerificationFailure('independent-disagreement',{'expected':'safe','actual':'unsafe'})):
                with self.assertRaises(VerificationFailure):store.recover()
            self.assertFalse(store.recovered)
            records=[decode(p.read_bytes()) for p in (store.root/'diagnostics').iterdir()]
            self.assertTrue(any(r['evidence']=={'expected':'safe','actual':'unsafe','stage':'independent-disagreement'} for r in records))

    def test_changed_context_cannot_regenerate_frozen_generation(self):
        with tempfile.TemporaryDirectory() as temp:
            store=self.store(Path(temp)/'store');store.publish('synthetic-old',self.bundle)
            shutil.rmtree(store.root/'generations/synthetic-old');store.recover()
            changed=copy.deepcopy(self.bundle)
            value=decode(changed['private/provenance.json']);value['platform']='different synthetic replay context'
            changed['private/provenance.json']=canonical(value)
            manifest=decode(changed['manifest.json']);manifest['files']['private/provenance.json']={'sha256':digest(changed['private/provenance.json']),'bytes':len(changed['private/provenance.json'])};changed['manifest.json']=canonical(manifest)
            with patch('dataset.pipeline.synthetic_bundle',return_value=changed):
                with self.assertRaises(AdmissionFailure):store.regenerate('synthetic-old','synthetic-new')
            self.assertFalse((store.root/'generations/synthetic-new').exists())

    def test_catalog_rename_and_sync_failure_close_authority(self):
        for point in ('registration-rename','index-replace','catalog-sync','record-file-sync','payload-file-sync','receipt-file-sync'):
            with self.subTest(point=point),tempfile.TemporaryDirectory() as temp:
                ops=SimulatedOps();store=self.store(Path(temp)/'store',ops=ops)
                if point=='registration-rename':target=patch.object(ops,'rename',side_effect=OSError('injected rename failure'))
                elif point=='index-replace':target=patch.object(ops,'replace',side_effect=OSError('injected index failure'))
                elif point=='catalog-sync':
                    original=ops.sync_dir
                    def sync(path):
                        if Path(path).name=='registrations':raise OSError('injected catalog synchronization failure')
                        original(path)
                    target=patch.object(ops,'sync_dir',side_effect=sync)
                else:
                    import dataset.storage as storage
                    original=storage.write_exclusive
                    name={'record-file-sync':'synthetic-old.pending','payload-file-sync':'queries.jsonl','receipt-file-sync':'completion.json'}[point]
                    def fail(path,raw):
                        if Path(path).name==name:
                            with patch('dataset.storage.os.fsync',side_effect=OSError('injected file fsync failure')):original(path,raw)
                        else:original(path,raw)
                    target=patch('dataset.storage.write_exclusive',side_effect=fail)
                with target:
                    with self.assertRaises(OSError):store.publish('synthetic-old',self.bundle)
                self.assertFalse(store.recovered)
                with self.assertRaises(AdmissionFailure):store.admit('synthetic-old')
                self.assertFalse((store.root/'generations/synthetic-old').exists())
                self.observe(point,'simulated_fault','fail_closed')

    @unittest.skipUnless(sys.platform=='linux','native catalog crash verification requires Linux')
    def test_native_exits_at_registration_receipt_rename_and_loss(self):
        ctx=multiprocessing.get_context('fork')
        for point in ('AFTER_REGISTRATION_RECORD','AFTER_REGISTRATION','WRITE:training/queries.jsonl','AFTER_RECEIPT','BEFORE_RENAME','AFTER_RENAME','AFTER_PARENT_FSYNC'):
            with self.subTest(point=point),tempfile.TemporaryDirectory() as temp:
                root=Path(temp)/'store';self.store(root,ops=NativeOps())
                child=ctx.Process(target=child_publish,args=(root,self.bundle,point));child.start();child.join(30)
                self.assertFalse(child.is_alive());self.assertEqual(child.exitcode,47)
                if point=='AFTER_REGISTRATION_RECORD':
                    with self.assertRaises(TrustFailure):SyntheticStore(root,self.recipe,self.labeler)
                else:
                    recovered=self.store(root,ops=NativeOps()).recover()
                    self.assertEqual(len(recovered),int(point in ('AFTER_RENAME','AFTER_PARENT_FSYNC')))
                    if not recovered:self.assertTrue((root/'.trust/losses/synthetic-old.json').is_file())
                self.observe(point,'linux_native','verified_survivor' if point in ('AFTER_RENAME','AFTER_PARENT_FSYNC') else 'fail_closed')
        for point in ('AFTER_LOSS_RECORD','AFTER_INVALIDATION'):
            with self.subTest(point=point),tempfile.TemporaryDirectory() as temp:
                root=Path(temp)/'store';store=self.store(root,ops=NativeOps());store.publish('synthetic-old',self.bundle)
                shutil.rmtree(root/'generations/synthetic-old')
                def recover_exit():
                    def hook(event):
                        if event==point:os._exit(48)
                    SyntheticStore(root,self.recipe,self.labeler,hook=hook).recover()
                child=ctx.Process(target=recover_exit);child.start();child.join(30);self.assertEqual(child.exitcode,48)
                if point=='AFTER_LOSS_RECORD':
                    with self.assertRaises(TrustFailure):SyntheticStore(root,self.recipe,self.labeler)
                else:
                    store=self.store(root,ops=NativeOps());self.assertEqual(store.recover(),[])
                    with self.assertRaises(AdmissionFailure):store.admit('synthetic-old')
                self.observe(point,'linux_native','fail_closed')

    @unittest.skipUnless(sys.platform=='linux','native lock/concurrency verification requires Linux')
    def test_native_publish_recovery_invalidation_and_duplicate_writers_serialize(self):
        ctx=multiprocessing.get_context('fork')
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)/'store';self.store(root,ops=NativeOps())
            ready=ctx.Event();release=ctx.Event();queue=ctx.Queue()
            writer=ctx.Process(target=child_publish,args=(root,self.bundle,'AFTER_REGISTRATION',ready,release));writer.start()
            self.assertTrue(ready.wait(30))
            others=[ctx.Process(target=child_operation,args=(root,op,queue,self.bundle)) for op in ('recover','invalidate','publish')]
            for process in others:process.start()
            # They cannot inspect an in-flight registration or return stale admission.
            with self.assertRaises(__import__('queue').Empty):queue.get(timeout=.3)
            release.set();writer.join(30);self.assertEqual(writer.exitcode,0)
            for process in others:process.join(30);self.assertFalse(process.is_alive());self.assertEqual(process.exitcode,0)
            outcomes={queue.get(timeout=5)[0:2] for _ in others}
            self.assertEqual(outcomes,{('recover','pass'),('invalidate','rejected'),('publish','rejected')})
            store=self.store(root,ops=NativeOps());self.assertEqual(len(store.recover()),1)
            self.assertEqual(list((root/'.trust/losses').iterdir()),[])
            self.assertEqual(len(list((root/'.trust/registrations').iterdir())),1)
            self.observe('competing-publish-recovery-invalidation','linux_native','serialized')

    @unittest.skipUnless(sys.platform=='linux','native replacement crash verification requires Linux')
    def test_native_replacement_interruption_preserves_loss_and_fresh_identity(self):
        ctx=multiprocessing.get_context('fork')
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)/'store';store=self.store(root,ops=NativeOps());store.publish('synthetic-old',self.bundle)
            shutil.rmtree(root/'generations/synthetic-old');store.recover()
            def replace_exit():
                def hook(point):
                    if point=='AFTER_RENAME':os._exit(49)
                instance=SyntheticStore(root,self.recipe,self.labeler,hook=hook);instance.regenerate('synthetic-old','synthetic-new')
            child=ctx.Process(target=replace_exit);child.start();child.join(30);self.assertEqual(child.exitcode,49)
            receipts=self.store(root,ops=NativeOps()).recover()
            self.assertEqual([r['generation_id'] for r in receipts],['synthetic-new'])
            self.assertTrue((root/'.trust/losses/synthetic-old.json').exists())
            self.observe('replacement-after-rename','linux_native','verified_survivor')
